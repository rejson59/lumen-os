import { useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import { settings } from "./os/settings";
import { closePanels, sys, togglePanel } from "./os/system";
import { Boot } from "./os/shell/Boot";
import { LockScreen } from "./os/shell/LockScreen";
import { PowerOff } from "./os/shell/PowerOff";
import { Desktop } from "./os/shell/Desktop";
import { MenuBar } from "./os/shell/MenuBar";
import { Dock } from "./os/shell/Dock";
import { Panels, Toasts } from "./os/shell/Panels";
import { Launchpad } from "./os/shell/Launchpad";
import { Spotlight } from "./os/shell/Spotlight";
import { ContextMenu, DialogHost } from "./os/shell/Overlays";

export default function App() {
  const session = sys.use((s) => s.session);
  const theme = settings.use((s) => s.theme);
  const accent = settings.use((s) => s.accent);
  const brightness = settings.use((s) => s.brightness);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    document.documentElement.style.setProperty("--accent", accent);
  }, [accent]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (sys.get().session !== "desktop") return;
      const mod = e.ctrlKey || e.altKey || e.metaKey;
      if ((mod && e.code === "Space") || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k")) {
        e.preventDefault();
        togglePanel("spotlight");
      } else if (e.key === "Escape") {
        closePanels();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const shell = session === "desktop" || session === "lock";

  return (
    <div
      className="relative h-full w-full overflow-hidden bg-black"
      onContextMenu={(e) => {
        const t = e.target as HTMLElement;
        if (t.tagName !== "INPUT" && t.tagName !== "TEXTAREA") e.preventDefault();
      }}
    >
      {shell && (
        <>
          <Desktop />
          <MenuBar />
          <Dock />
          <Panels />
          <Launchpad />
          <Spotlight />
          <Toasts />
        </>
      )}

      <AnimatePresence>{session === "lock" && <LockScreen key="lock" />}</AnimatePresence>
      <AnimatePresence>{session === "boot" && <Boot key="boot" />}</AnimatePresence>
      {session === "off" && <PowerOff />}

      <ContextMenu />
      <DialogHost />

      {/* jasność ekranu */}
      <div
        className="pointer-events-none absolute inset-0 z-[400] bg-black transition-opacity duration-300"
        style={{ opacity: ((100 - brightness) / 100) * 0.75 }}
      />
    </div>
  );
}
