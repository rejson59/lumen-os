import type { FSNode } from "./fs";
import { openApp } from "./system";

export function openNode(n: FSNode) {
  if (n.kind === "folder") openApp("files", { folderId: n.id });
  else if (n.kind === "image") openApp("photos", { fileId: n.id });
  else openApp("notes", { fileId: n.id });
}
