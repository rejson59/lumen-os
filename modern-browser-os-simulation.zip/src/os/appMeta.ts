import {
  Activity,
  CalendarDays,
  Calculator,
  Clock,
  CloudSun,
  Folder,
  Gamepad2,
  Globe,
  Image as ImageIcon,
  Music2,
  Brush,
  Settings,
  StickyNote,
  Terminal,
  type LucideIcon,
} from "lucide-react";

export type AppId =
  | "files"
  | "browser"
  | "notes"
  | "music"
  | "photos"
  | "paint"
  | "calendar"
  | "weather"
  | "terminal"
  | "settings"
  | "calculator"
  | "clock"
  | "snake"
  | "monitor";

export interface AppMeta {
  id: AppId;
  name: string;
  icon: LucideIcon;
  from: string;
  to: string;
  w: number;
  h: number;
  minW: number;
  minH: number;
  single?: boolean;
  keywords: string;
}

export const APP_META: Record<AppId, AppMeta> = {
  files: { id: "files", name: "Pliki", icon: Folder, from: "#38bdf8", to: "#2563eb", w: 880, h: 560, minW: 520, minH: 340, keywords: "files pliki foldery dokumenty explorer" },
  browser: { id: "browser", name: "Przeglądarka", icon: Globe, from: "#22d3ee", to: "#6366f1", w: 1000, h: 640, minW: 460, minH: 320, keywords: "browser internet web przeglądarka strona wikipedia" },
  notes: { id: "notes", name: "Notatki", icon: StickyNote, from: "#fde047", to: "#f59e0b", w: 820, h: 540, minW: 480, minH: 320, keywords: "notes notatki tekst edytor" },
  music: { id: "music", name: "Muzyka", icon: Music2, from: "#f472b6", to: "#c026d3", w: 760, h: 520, minW: 520, minH: 440, single: true, keywords: "music muzyka odtwarzacz audio" },
  photos: { id: "photos", name: "Zdjęcia", icon: ImageIcon, from: "#fb7185", to: "#fbbf24", w: 880, h: 580, minW: 480, minH: 340, keywords: "photos zdjęcia galeria obrazy" },
  paint: { id: "paint", name: "Szkicownik", icon: Brush, from: "#a78bfa", to: "#ec4899", w: 900, h: 620, minW: 560, minH: 420, keywords: "paint szkicownik rysowanie malowanie" },
  calendar: { id: "calendar", name: "Kalendarz", icon: CalendarDays, from: "#fb7185", to: "#e11d48", w: 860, h: 580, minW: 560, minH: 420, single: true, keywords: "calendar kalendarz wydarzenia" },
  weather: { id: "weather", name: "Pogoda", icon: CloudSun, from: "#67e8f9", to: "#3b82f6", w: 780, h: 580, minW: 520, minH: 440, single: true, keywords: "weather pogoda prognoza" },
  terminal: { id: "terminal", name: "Terminal", icon: Terminal, from: "#374151", to: "#030712", w: 740, h: 480, minW: 400, minH: 260, keywords: "terminal konsola shell cmd" },
  settings: { id: "settings", name: "Ustawienia", icon: Settings, from: "#94a3b8", to: "#475569", w: 840, h: 580, minW: 560, minH: 400, single: true, keywords: "settings ustawienia motyw tapeta wygląd" },
  calculator: { id: "calculator", name: "Kalkulator", icon: Calculator, from: "#fdba74", to: "#ea580c", w: 340, h: 520, minW: 300, minH: 460, single: true, keywords: "calculator kalkulator liczby" },
  clock: { id: "clock", name: "Zegar", icon: Clock, from: "#818cf8", to: "#4338ca", w: 620, h: 540, minW: 440, minH: 420, single: true, keywords: "clock zegar stoper minutnik czas" },
  snake: { id: "snake", name: "Wąż", icon: Gamepad2, from: "#86efac", to: "#059669", w: 520, h: 640, minW: 400, minH: 500, single: true, keywords: "snake wąż gra game" },
  monitor: { id: "monitor", name: "Monitor systemu", icon: Activity, from: "#5eead4", to: "#0f766e", w: 800, h: 560, minW: 520, minH: 380, single: true, keywords: "monitor system procesy cpu pamięć task manager" },
};

export const APP_LIST: AppMeta[] = Object.values(APP_META);

export const DOCK_APPS: AppId[] = [
  "files",
  "browser",
  "notes",
  "music",
  "photos",
  "paint",
  "calendar",
  "weather",
  "terminal",
  "settings",
];
