import { createStore } from "./store";

export interface Settings {
  theme: "dark" | "light";
  accent: string;
  wallpaper: string;
  brightness: number;
  volume: number;
  wifi: boolean;
  bluetooth: boolean;
  dnd: boolean;
  magnify: boolean;
  userName: string;
}

export const settings = createStore<Settings>(
  {
    theme: "dark",
    accent: "#8b5cf6",
    wallpaper: "aurora",
    brightness: 100,
    volume: 60,
    wifi: true,
    bluetooth: true,
    dnd: false,
    magnify: true,
    userName: "Użytkownik",
  },
  "lumen.settings.v1"
);

export const setSettings = (patch: Partial<Settings>) => settings.set(patch);

export const ACCENTS = [
  { name: "Fiolet", color: "#8b5cf6" },
  { name: "Błękit", color: "#3b82f6" },
  { name: "Turkus", color: "#06b6d4" },
  { name: "Szmaragd", color: "#10b981" },
  { name: "Bursztyn", color: "#f59e0b" },
  { name: "Róż", color: "#ec4899" },
  { name: "Koral", color: "#f43f5e" },
];
