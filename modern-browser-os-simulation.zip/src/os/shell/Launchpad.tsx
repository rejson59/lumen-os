import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search } from "lucide-react";
import { APP_LIST } from "../appMeta";
import { closePanels, openApp, sys } from "../system";
import { AppIcon } from "../ui";

export function Launchpad() {
  const open = sys.use((s) => s.panel === "launchpad");
  const [q, setQ] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQ("");
      setTimeout(() => inputRef.current?.focus(), 120);
    }
  }, [open]);

  const apps = APP_LIST.filter((a) => (a.name + " " + a.keywords).toLowerCase().includes(q.toLowerCase()));

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="absolute inset-0 z-[45] flex flex-col items-center bg-black/35 px-6 pt-20 backdrop-blur-2xl"
          initial={{ opacity: 0, scale: 1.08 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 1.06 }}
          transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
          onPointerDown={closePanels}
        >
          <div
            className="glass flex w-full max-w-[320px] items-center gap-2 rounded-xl px-3 py-2 text-white"
            onPointerDown={(e) => e.stopPropagation()}
          >
            <Search size={15} className="opacity-70" />
            <input
              ref={inputRef}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && apps[0]) openApp(apps[0].id);
              }}
              placeholder="Szukaj aplikacji"
              className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/50"
            />
          </div>
          <div
            className="mt-12 grid w-full max-w-[860px] grid-cols-3 gap-x-4 gap-y-10 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7"
          >
            {apps.map((a, i) => (
              <motion.button
                key={a.id}
                initial={{ opacity: 0, y: 30, scale: 0.8 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: 0.04 + i * 0.03, type: "spring", stiffness: 300, damping: 24 }}
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={() => openApp(a.id)}
                className="flex flex-col items-center gap-2.5"
              >
                <AppIcon id={a.id} size={72} />
                <span className="tshadow text-[13px] font-medium text-white">{a.name}</span>
              </motion.button>
            ))}
          </div>
          {apps.length === 0 && <div className="mt-24 text-white/60">Nie znaleziono aplikacji</div>}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
