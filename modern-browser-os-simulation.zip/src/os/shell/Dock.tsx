import { useRef, useState, type ReactNode } from "react";
import { motion, useMotionValue, useSpring, useTransform, type MotionValue } from "framer-motion";
import { LayoutGrid, Trash2, X, Plus } from "lucide-react";
import { APP_META, DOCK_APPS, type AppId } from "../appMeta";
import { settings } from "../settings";
import { closeAllOf, focusWindow, minimizeWindow, openApp, sys, togglePanel } from "../system";
import { showMenu } from "../overlayStore";
import { useViewport } from "../hooks";
import { AppIcon } from "../ui";
import { childrenOf, useNodes, TRASH } from "../fs";
import { cn } from "../../utils/cn";

const BASE = 50;
const MAX = 82;

function DockItem({
  label,
  mouseX,
  magnify,
  running,
  appId,
  onClick,
  onContextMenu,
  children,
}: {
  label: string;
  mouseX: MotionValue<number>;
  magnify: boolean;
  running?: boolean;
  appId?: string;
  onClick: () => void;
  onContextMenu?: (e: React.MouseEvent) => void;
  children: ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [bounce, setBounce] = useState(0);
  const dist = useTransform(mouseX, (v) => {
    const r = ref.current?.getBoundingClientRect();
    return r ? v - r.x - r.width / 2 : 999;
  });
  const raw = useTransform(dist, [-150, -80, 0, 80, 150], magnify ? [BASE, BASE + 12, MAX, BASE + 12, BASE] : [BASE, BASE, BASE, BASE, BASE]);
  const size = useSpring(raw, { mass: 0.1, stiffness: 220, damping: 16 });

  return (
    <div className="group relative flex flex-col items-center" onContextMenu={onContextMenu}>
      <span className="glass-strong pointer-events-none absolute -top-11 whitespace-nowrap rounded-lg px-2.5 py-1 text-xs font-medium opacity-0 shadow-lg transition-opacity duration-150 group-hover:opacity-100">
        {label}
      </span>
      <motion.div
        ref={ref}
        data-dock-app={appId}
        style={{ width: size, height: size }}
        animate={{ y: bounce ? [0, -26, 0, -14, 0, -6, 0] : 0 }}
        transition={{ duration: 0.9, ease: "easeOut" }}
        key={bounce}
        whileTap={{ scale: 0.88 }}
        onClick={() => {
          if (!running) setBounce((b) => b + 1);
          onClick();
        }}
        className="cursor-default"
      >
        {children}
      </motion.div>
      <span
        className={cn(
          "absolute -bottom-2 h-1 w-1 rounded-full bg-fg transition-all duration-300",
          running ? "scale-100 opacity-70" : "scale-0 opacity-0"
        )}
      />
    </div>
  );
}

export function Dock() {
  const mouseX = useMotionValue(Infinity);
  const magnify = settings.use((s) => s.magnify);
  const windows = sys.use((s) => s.windows);
  const activeId = sys.use((s) => s.activeId);
  const panel = sys.use((s) => s.panel);
  const nodes = useNodes();
  const trashCount = childrenOf(nodes, TRASH).length;
  const { w } = useViewport();

  const pinned = w < 720 ? DOCK_APPS.slice(0, 5) : DOCK_APPS;
  const extra = Array.from(new Set(windows.map((x) => x.appId))).filter((a) => !pinned.includes(a));

  const activateApp = (id: AppId) => {
    const ws = windows.filter((x) => x.appId === id);
    if (ws.length === 0) return openApp(id);
    const active = ws.find((x) => x.id === activeId && !x.minimized);
    if (active) return minimizeWindow(active.id);
    const top = [...ws].sort((a, b) => b.z - a.z)[0];
    focusWindow(top.id);
  };

  const appItem = (id: AppId) => (
    <DockItem
      key={id}
      appId={id}
      label={APP_META[id].name}
      mouseX={mouseX}
      magnify={magnify}
      running={windows.some((x) => x.appId === id)}
      onClick={() => activateApp(id)}
      onContextMenu={(e) =>
        showMenu(e, [
          { label: "Otwórz nowe okno", icon: Plus, onClick: () => openApp(id), disabled: !!APP_META[id].single && windows.some((x) => x.appId === id) },
          { label: "Zamknij wszystkie okna", icon: X, onClick: () => closeAllOf(id), disabled: !windows.some((x) => x.appId === id) },
        ])
      }
    >
      <AppIcon id={id} />
    </DockItem>
  );

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-3 z-30 flex justify-center px-2">
      <motion.div
        initial={{ y: 120, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 160, damping: 20, delay: 0.2 }}
        onMouseMove={(e) => mouseX.set(e.clientX)}
        onMouseLeave={() => mouseX.set(Infinity)}
        className="glass pointer-events-auto flex items-end gap-2.5 rounded-[26px] px-3 pb-3 pt-2.5 shadow-[0_20px_60px_-10px_rgba(0,0,0,.5)]"
      >
        <DockItem label="Wszystkie aplikacje" mouseX={mouseX} magnify={magnify} running={panel === "launchpad"} onClick={() => togglePanel("launchpad")}>
          <div
            className="grid h-full w-full place-items-center overflow-hidden"
            style={{
              borderRadius: "26%",
              background: "linear-gradient(150deg,#a78bfa,#6366f1 45%,#06b6d4)",
              boxShadow: "inset 0 1px 0 rgba(255,255,255,.5), 0 6px 18px rgba(0,0,0,.28)",
            }}
          >
            <LayoutGrid className="h-[50%] w-[50%] text-white drop-shadow" />
          </div>
        </DockItem>
        <div className="mb-1 h-10 w-px self-center bg-glass-border" />
        {pinned.map(appItem)}
        {extra.length > 0 && <div className="mb-1 h-10 w-px self-center bg-glass-border" />}
        {extra.map(appItem)}
        <div className="mb-1 h-10 w-px self-center bg-glass-border" />
        <DockItem
          label="Kosz"
          mouseX={mouseX}
          magnify={magnify}
          onClick={() => openApp("files", { folderId: TRASH })}
        >
          <div
            className="relative grid h-full w-full place-items-center overflow-hidden"
            style={{
              borderRadius: "26%",
              background: "linear-gradient(150deg,#cbd5e1,#64748b)",
              boxShadow: "inset 0 1px 0 rgba(255,255,255,.5), 0 6px 18px rgba(0,0,0,.28)",
            }}
          >
            <Trash2 className="h-[50%] w-[50%] text-white drop-shadow" />
            {trashCount > 0 && (
              <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[9px] font-bold text-white">
                {trashCount}
              </span>
            )}
          </div>
        </DockItem>
      </motion.div>
    </div>
  );
}
