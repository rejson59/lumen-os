import {
  Battery,
  BatteryCharging,
  BatteryLow,
  BatteryMedium,
  Bell,
  BellOff,
  Info,
  Lock,
  Maximize2,
  Minus,
  Power,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Volume1,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  X,
  Plus,
  Activity,
  Settings as SettingsIcon,
} from "lucide-react";
import { APP_META } from "../appMeta";
import { settings } from "../settings";
import {
  MENU_H,
  closeAllOf,
  closeWindow,
  lock,
  minimizeWindow,
  openApp,
  restart,
  shutdown,
  sys,
  toggleMaximize,
  togglePanel,
} from "../system";
import { askConfirm } from "../overlayStore";
import { fmtDateShort, fmtTime, useBattery, useNow } from "../hooks";
import { Dropdown, LumenLogo } from "../ui";
import { cn } from "../../utils/cn";

const chip = "flex h-7 items-center gap-1.5 rounded-lg px-2 text-[13px] transition-colors hover:bg-surface-3";

export function MenuBar() {
  const now = useNow(1000);
  const bat = useBattery();
  const wifi = settings.use((s) => s.wifi);
  const volume = settings.use((s) => s.volume);
  const dnd = settings.use((s) => s.dnd);
  const panel = sys.use((s) => s.panel);
  const notices = sys.use((s) => s.notices.length);
  const activeId = sys.use((s) => s.activeId);
  const windows = sys.use((s) => s.windows);
  const active = windows.find((w) => w.id === activeId && !w.minimized);
  const meta = active ? APP_META[active.appId] : null;

  const BatIcon = bat.charging ? BatteryCharging : bat.level > 0.6 ? Battery : bat.level > 0.25 ? BatteryMedium : BatteryLow;
  const VolIcon = volume === 0 ? VolumeX : volume < 50 ? Volume1 : Volume2;

  return (
    <div
      className="glass absolute inset-x-0 top-0 z-50 flex items-center justify-between rounded-none border-x-0 border-t-0 px-2 text-fg"
      style={{ height: MENU_H }}
    >
      <div className="flex items-center gap-0.5">
        <Dropdown
          className={cn(chip, "px-2.5")}
          trigger={() => <LumenLogo size={17} />}
          items={[
            { label: "O Lumen OS", icon: Info, onClick: () => openApp("settings", { section: "about" }) },
            { label: "Ustawienia systemu…", icon: SettingsIcon, onClick: () => openApp("settings") },
            { label: "Monitor systemu", icon: Activity, onClick: () => openApp("monitor") },
            { separator: true },
            { label: "Zablokuj ekran", icon: Lock, onClick: lock },
            {
              label: "Uruchom ponownie…",
              icon: RotateCcw,
              onClick: async () => {
                if (await askConfirm("Uruchomić ponownie?", "Wszystkie otwarte okna zostaną zamknięte.", "Uruchom ponownie")) restart();
              },
            },
            {
              label: "Wyłącz…",
              icon: Power,
              danger: true,
              onClick: async () => {
                if (await askConfirm("Wyłączyć system?", "Wszystkie otwarte okna zostaną zamknięte.", "Wyłącz", true)) shutdown();
              },
            },
          ]}
        />
        <Dropdown
          className={cn(chip, "font-semibold")}
          trigger={() => <span>{meta ? meta.name : "Pulpit"}</span>}
          items={
            meta && active
              ? [
                  { label: `Nowe okno: ${meta.name}`, icon: Plus, onClick: () => openApp(meta.id), disabled: !!meta.single },
                  { separator: true },
                  { label: "Zamknij okno", icon: X, onClick: () => closeWindow(active.id) },
                  { label: `Zamknij wszystkie (${meta.name})`, icon: X, onClick: () => closeAllOf(meta.id) },
                ]
              : [
                  { label: "Otwórz Spotlight", icon: Search, onClick: () => togglePanel("spotlight") },
                  { label: "Wszystkie aplikacje", icon: Info, onClick: () => togglePanel("launchpad") },
                ]
          }
        />
        <Dropdown
          className={cn(chip, "hidden sm:flex")}
          trigger={() => <span>Okno</span>}
          items={[
            { label: "Minimalizuj", icon: Minus, disabled: !active, onClick: () => active && minimizeWindow(active.id) },
            { label: "Maksymalizuj / przywróć", icon: Maximize2, disabled: !active, onClick: () => active && toggleMaximize(active.id) },
            { separator: true },
            { label: "Zamknij okno", icon: X, disabled: !active, onClick: () => active && closeWindow(active.id) },
          ]}
        />
      </div>

      <div className="flex items-center gap-0.5">
        <button className={chip} onClick={() => togglePanel("spotlight")} aria-label="Spotlight">
          <Search size={15} />
        </button>
        <div className="hidden items-center gap-0.5 sm:flex">
          {wifi ? <Wifi size={15} className="mx-1.5" /> : <WifiOff size={15} className="mx-1.5 opacity-60" />}
          <span className={cn(chip, "gap-1 px-1.5")}>
            <BatIcon size={17} className={cn(bat.charging && "text-emerald-400")} />
            <span className="text-xs tabular-nums">{Math.round(bat.level * 100)}%</span>
          </span>
        </div>
        <button
          className={cn(chip, panel === "controlCenter" && "bg-surface-3")}
          onClick={() => togglePanel("controlCenter")}
          aria-label="Centrum sterowania"
        >
          <SlidersHorizontal size={15} />
          <VolIcon size={15} className="hidden sm:block" />
        </button>
        <button
          className={cn(chip, "relative gap-2 font-medium", panel === "notifCenter" && "bg-surface-3")}
          onClick={() => togglePanel("notifCenter")}
        >
          {dnd ? <BellOff size={14} className="opacity-70" /> : <Bell size={14} />}
          {notices > 0 && !dnd && <span className="absolute left-5 top-1 h-2 w-2 rounded-full bg-rose-500 ring-2 ring-[var(--panel)]" />}
          <span className="hidden capitalize sm:inline">{fmtDateShort(now)}</span>
          <span className="tabular-nums">{fmtTime(now)}</span>
        </button>
      </div>
    </div>
  );
}
