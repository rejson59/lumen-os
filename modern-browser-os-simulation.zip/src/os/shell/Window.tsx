import { useRef, type PointerEvent as RPointerEvent } from "react";
import { motion } from "framer-motion";
import { Maximize2, Minus, X } from "lucide-react";
import { APP_META, type AppId } from "../appMeta";
import { APPS } from "../registry";
import {
  MENU_H,
  closeWindow,
  focusWindow,
  maxRect,
  minimizeWindow,
  setWinRect,
  toggleMaximize,
  type Rect,
  type WinState,
} from "../system";
import { cn } from "../../utils/cn";
import { AppIcon } from "../ui";

type Dir = "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";

const HANDLES: { d: Dir; cls: string; cursor: string }[] = [
  { d: "n", cls: "left-3 right-3 -top-1 h-2", cursor: "ns-resize" },
  { d: "s", cls: "left-3 right-3 -bottom-1 h-2", cursor: "ns-resize" },
  { d: "w", cls: "top-3 bottom-3 -left-1 w-2", cursor: "ew-resize" },
  { d: "e", cls: "top-3 bottom-3 -right-1 w-2", cursor: "ew-resize" },
  { d: "nw", cls: "-left-1 -top-1 h-4 w-4", cursor: "nwse-resize" },
  { d: "ne", cls: "-right-1 -top-1 h-4 w-4", cursor: "nesw-resize" },
  { d: "sw", cls: "-left-1 -bottom-1 h-4 w-4", cursor: "nesw-resize" },
  { d: "se", cls: "-right-1 -bottom-1 h-4 w-4", cursor: "nwse-resize" },
];

function dockTarget(appId: AppId, r: Rect) {
  const cx = r.x + r.w / 2;
  const cy = r.y + r.h / 2;
  const el = document.querySelector<HTMLElement>(`[data-dock-app="${appId}"]`);
  if (el) {
    const b = el.getBoundingClientRect();
    return { x: b.left + b.width / 2 - cx, y: b.top + b.height / 2 - cy };
  }
  return { x: window.innerWidth / 2 - cx, y: window.innerHeight - cy };
}

const applyRect = (el: HTMLElement, r: Rect) => {
  el.style.left = r.x + "px";
  el.style.top = r.y + "px";
  el.style.width = r.w + "px";
  el.style.height = r.h + "px";
};

export function Window({ win, active, vw, vh }: { win: WinState; active: boolean; vw: number; vh: number }) {
  const meta = APP_META[win.appId];
  const Comp = APPS[win.appId];
  const ref = useRef<HTMLDivElement>(null);
  const rect: Rect = win.maximized ? maxRect(vw, vh) : { x: win.x, y: win.y, w: win.w, h: win.h };
  const target = win.minimized ? dockTarget(win.appId, rect) : { x: 0, y: 0 };

  const startDrag = (e: RPointerEvent) => {
    if ((e.target as HTMLElement).closest("[data-nodrag]")) return;
    if (e.button !== 0) return;
    const el = ref.current;
    if (!el) return;
    focusWindow(win.id);
    let cur: Rect = { ...rect };
    el.style.transition = "none";
    if (win.maximized) {
      const prev = win.prev ?? { x: win.x, y: win.y, w: meta.w, h: meta.h };
      const ratio = (e.clientX - rect.x) / rect.w;
      const nw = Math.min(prev.w, vw - 16);
      const nh = Math.min(prev.h, vh - MENU_H - 20);
      cur = { x: e.clientX - nw * ratio, y: rect.y, w: nw, h: nh };
      applyRect(el, cur);
      setWinRect(win.id, { ...cur, maximized: false, prev: undefined });
    }
    const sx = e.clientX;
    const sy = e.clientY;
    const ox = cur.x;
    const oy = cur.y;
    document.body.classList.add("dragging");
    const move = (ev: PointerEvent) => {
      cur.x = ox + ev.clientX - sx;
      cur.y = Math.min(window.innerHeight - 60, Math.max(MENU_H, oy + ev.clientY - sy));
      el.style.left = cur.x + "px";
      el.style.top = cur.y + "px";
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      document.body.classList.remove("dragging");
      el.style.transition = "";
      setWinRect(win.id, { x: cur.x, y: cur.y });
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const startResize = (dir: Dir) => (e: RPointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (win.maximized) return;
    const el = ref.current;
    if (!el) return;
    focusWindow(win.id);
    el.style.transition = "none";
    const sx = e.clientX;
    const sy = e.clientY;
    const r0 = { ...rect };
    let r = { ...r0 };
    document.body.classList.add("dragging");
    const move = (ev: PointerEvent) => {
      const dx = ev.clientX - sx;
      const dy = ev.clientY - sy;
      let { x, y, w, h } = r0;
      if (dir.includes("e")) w = Math.max(meta.minW, r0.w + dx);
      if (dir.includes("s")) h = Math.max(meta.minH, r0.h + dy);
      if (dir.includes("w")) {
        w = Math.max(meta.minW, r0.w - dx);
        x = r0.x + (r0.w - w);
      }
      if (dir.includes("n")) {
        h = Math.max(meta.minH, r0.h - dy);
        y = r0.y + (r0.h - h);
        if (y < MENU_H) {
          h -= MENU_H - y;
          y = MENU_H;
        }
      }
      r = { x, y, w, h };
      applyRect(el, r);
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      document.body.classList.remove("dragging");
      el.style.transition = "";
      setWinRect(win.id, r);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  return (
    <div
      ref={ref}
      className="win-anim absolute"
      style={{
        left: rect.x,
        top: rect.y,
        width: rect.w,
        height: rect.h,
        zIndex: win.z,
        pointerEvents: win.minimized ? "none" : "auto",
      }}
      onPointerDownCapture={() => !active && focusWindow(win.id)}
      onContextMenu={(e) => {
        e.stopPropagation();
        const t = e.target as HTMLElement;
        if (t.tagName !== "INPUT" && t.tagName !== "TEXTAREA") e.preventDefault();
      }}
    >
      <motion.div
        className={cn(
          "glass-strong absolute inset-0 flex flex-col overflow-hidden rounded-[18px] transition-shadow duration-300",
          active
            ? "shadow-[0_30px_90px_-12px_rgba(0,0,0,.6),0_0_0_1px_rgba(255,255,255,.04)]"
            : "shadow-[0_14px_40px_-10px_rgba(0,0,0,.4)]"
        )}
        initial={{ opacity: 0, scale: 0.88, y: 28 }}
        animate={
          win.minimized
            ? { opacity: 0, scale: 0.12, x: target.x, y: target.y }
            : { opacity: 1, scale: 1, x: 0, y: 0 }
        }
        exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.18 } }}
        transition={
          win.minimized
            ? { duration: 0.45, ease: [0.4, 0, 0.2, 1] }
            : { type: "spring", stiffness: 320, damping: 30 }
        }
      >
        {/* pasek tytułu */}
        <div
          onPointerDown={startDrag}
          onDoubleClick={(e) => {
            if (!(e.target as HTMLElement).closest("[data-nodrag]")) toggleMaximize(win.id);
          }}
          className="relative flex h-11 shrink-0 items-center px-3.5"
        >
          <div data-nodrag className="group z-10 flex items-center gap-2">
            {[
              { c: "#ff5f57", icon: X, run: () => closeWindow(win.id), label: "Zamknij" },
              { c: "#febc2e", icon: Minus, run: () => minimizeWindow(win.id), label: "Minimalizuj" },
              { c: "#28c840", icon: Maximize2, run: () => toggleMaximize(win.id), label: "Maksymalizuj" },
            ].map((b) => (
              <button
                key={b.label}
                aria-label={b.label}
                onClick={b.run}
                className={cn(
                  "grid h-3.5 w-3.5 place-items-center rounded-full text-black/60 transition-all duration-200 hover:scale-110",
                  !active && "bg-surface-3 group-hover:bg-[var(--c)]"
                )}
                style={{ ["--c" as string]: b.c, background: active ? b.c : undefined }}
              >
                <b.icon size={9} strokeWidth={3.2} className="opacity-0 transition-opacity group-hover:opacity-100" />
              </button>
            ))}
          </div>
          <div
            className={cn(
              "pointer-events-none absolute inset-x-24 flex items-center justify-center gap-2 text-[13px] font-medium transition-opacity",
              active ? "text-fg" : "text-fg-faint"
            )}
          >
            <AppIcon id={win.appId} size={16} className="!rounded-[5px] shadow-none" />
            <span className="truncate">{win.title}</span>
          </div>
        </div>
        <div className="relative min-h-0 flex-1">
          <Comp winId={win.id} props={win.props} active={active} />
        </div>
      </motion.div>

      {!win.maximized &&
        !win.minimized &&
        HANDLES.map((h) => (
          <div
            key={h.d}
            onPointerDown={startResize(h.d)}
            className={cn("absolute z-20", h.cls)}
            style={{ cursor: h.cursor }}
          />
        ))}
    </div>
  );
}
