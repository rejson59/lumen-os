import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ctxMenu, dialogStore, hideMenu } from "../overlayStore";
import { MenuList } from "../ui";

export function ContextMenu() {
  const { open, x, y, items } = ctxMenu.use((s) => s);
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  useLayoutEffect(() => {
    if (!open || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    setPos({
      x: Math.min(x, window.innerWidth - r.width - 8),
      y: Math.min(y, window.innerHeight - r.height - 8),
    });
  }, [open, x, y, items]);

  useEffect(() => {
    if (!open) return;
    const close = (e: Event) => {
      if (ref.current && e.target instanceof Node && ref.current.contains(e.target)) return;
      hideMenu();
    };
    const key = (e: KeyboardEvent) => e.key === "Escape" && hideMenu();
    window.addEventListener("pointerdown", close, true);
    window.addEventListener("blur", hideMenu);
    window.addEventListener("keydown", key);
    window.addEventListener("wheel", hideMenu, { passive: true });
    return () => {
      window.removeEventListener("pointerdown", close, true);
      window.removeEventListener("blur", hideMenu);
      window.removeEventListener("keydown", key);
      window.removeEventListener("wheel", hideMenu);
    };
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          ref={ref}
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.12 }}
          style={{ left: pos.x || x, top: pos.y || y, transformOrigin: "top left" }}
          className="fixed z-[300]"
          onContextMenu={(e) => e.preventDefault()}
        >
          <MenuList items={items} onDone={hideMenu} />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function DialogHost() {
  const cur = dialogStore.use((s) => s.current);
  const [val, setVal] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (cur?.kind === "prompt") {
      setVal(cur.value ?? "");
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 60);
    }
  }, [cur]);

  const finish = (v: string | boolean | null) => {
    cur?.resolve(v);
    dialogStore.set({ current: null });
  };

  useEffect(() => {
    if (!cur) return;
    const k = (e: KeyboardEvent) => {
      if (e.key === "Escape") finish(cur.kind === "prompt" ? null : false);
      if (e.key === "Enter" && cur.kind === "confirm") finish(true);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  return (
    <AnimatePresence>
      {cur && (
        <motion.div
          className="fixed inset-0 z-[250] grid place-items-center bg-black/35 backdrop-blur-[3px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onPointerDown={() => finish(cur.kind === "prompt" ? null : false)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 420, damping: 30 }}
            onPointerDown={(e) => e.stopPropagation()}
            className="glass-strong w-[360px] max-w-[92vw] rounded-2xl p-5 shadow-2xl"
          >
            <div className="text-[15px] font-semibold">{cur.title}</div>
            {cur.message && <div className="mt-1.5 text-[13px] leading-snug text-fg-dim">{cur.message}</div>}
            {cur.kind === "prompt" && (
              <input
                ref={inputRef}
                value={val}
                onChange={(e) => setVal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && val.trim()) finish(val.trim());
                }}
                className="mt-3 w-full rounded-xl border border-glass-border bg-surface-2 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-accent"
              />
            )}
            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={() => finish(cur.kind === "prompt" ? null : false)}
                className="rounded-xl bg-surface-2 px-4 py-1.5 text-[13px] font-medium transition hover:bg-surface-3"
              >
                Anuluj
              </button>
              <button
                onClick={() => finish(cur.kind === "prompt" ? val.trim() || null : true)}
                className={`rounded-xl px-4 py-1.5 text-[13px] font-medium text-white transition hover:brightness-110 ${
                  cur.danger ? "bg-rose-500" : "bg-accent-grad"
                }`}
              >
                {cur.okLabel ?? "OK"}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
