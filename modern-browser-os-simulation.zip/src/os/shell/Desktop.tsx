import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { FilePlus, FolderPlus, Image as ImageIcon, Lock, Settings as SettingsIcon, Trash2, FolderOpen, Pencil } from "lucide-react";
import { Wallpaper } from "./Wallpaper";
import { Window } from "./Window";
import { settings, setSettings } from "../settings";
import { sys, openApp, lock } from "../system";
import { WALLPAPERS } from "../wallpapers";
import { askText, showMenu } from "../overlayStore";
import { createNode, childrenOf, inferKind, renameNode, trashNode, useNodes, type FSNode } from "../fs";
import { NodeIcon } from "../NodeIcon";
import { openNode } from "../fileActions";
import { fmtDateLong, fmtTime, useNow, useViewport } from "../hooks";
import { cn } from "../../utils/cn";

function DesktopIcon({ node, selected, onSelect }: { node: FSNode; selected: boolean; onSelect: () => void }) {
  return (
    <button
      onPointerDown={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      onDoubleClick={() => openNode(node)}
      onContextMenu={(e) => {
        onSelect();
        showMenu(e, [
          { label: "Otwórz", icon: FolderOpen, onClick: () => openNode(node) },
          {
            label: "Zmień nazwę",
            icon: Pencil,
            onClick: async () => {
              const n = await askText("Zmień nazwę", node.name);
              if (n) renameNode(node.id, n);
            },
          },
          { separator: true },
          { label: "Przenieś do kosza", icon: Trash2, danger: true, onClick: () => trashNode(node.id) },
        ]);
      }}
      className={cn(
        "group flex h-[96px] w-[88px] flex-col items-center gap-1 rounded-xl px-1 py-1.5 transition-colors",
        selected ? "bg-white/20 ring-1 ring-white/30" : "hover:bg-white/10"
      )}
    >
      <div className="grid h-[56px] place-items-center transition-transform duration-200 group-active:scale-95">
        <NodeIcon node={node} size={50} />
      </div>
      <span className="tshadow line-clamp-2 break-words text-center text-[12px] font-medium leading-[1.15] text-white">
        {node.name}
      </span>
    </button>
  );
}

function ClockWidget() {
  const now = useNow(1000);
  const name = settings.use((s) => s.userName);
  const h = now.getHours();
  const greet = h < 5 ? "Dobrej nocy" : h < 12 ? "Dzień dobry" : h < 18 ? "Miłego popołudnia" : "Dobry wieczór";
  return (
    <div className="glass pointer-events-none absolute right-5 top-14 hidden w-[230px] rounded-3xl p-5 shadow-xl lg:block">
      <div className="text-[11px] font-medium uppercase tracking-widest text-fg-dim">{greet}, {name}</div>
      <div className="mt-1 text-[54px] font-extralight leading-none tracking-tight">{fmtTime(now)}</div>
      <div className="mt-2 text-sm capitalize text-fg-dim">{fmtDateLong(now)}</div>
      <div className="mt-4 h-1 overflow-hidden rounded-full bg-surface-3">
        <div
          className="h-full rounded-full bg-accent-grad transition-[width] duration-1000 ease-linear"
          style={{ width: `${((now.getSeconds() + 1) / 60) * 100}%` }}
        />
      </div>
    </div>
  );
}

export function Desktop() {
  const wallpaper = settings.use((s) => s.wallpaper);
  const nodes = useNodes();
  const items = childrenOf(nodes, "desktop");
  const windows = sys.use((s) => s.windows);
  const activeId = sys.use((s) => s.activeId);
  const vp = useViewport();
  const [sel, setSel] = useState<string | null>(null);

  const bgMenu = (e: React.MouseEvent) =>
    showMenu(e, [
      {
        label: "Nowa notatka",
        icon: FilePlus,
        onClick: async () => {
          const n = await askText("Nowa notatka", "Nowa notatka.txt");
          if (!n) return;
          const kind = inferKind(n);
          const id = createNode("desktop", n, kind, "");
          if (kind === "text") openApp("notes", { fileId: id });
        },
      },
      {
        label: "Nowy folder",
        icon: FolderPlus,
        onClick: async () => {
          const n = await askText("Nowy folder", "Nowy folder");
          if (n) createNode("desktop", n, "folder");
        },
      },
      { separator: true },
      {
        label: "Zmień tapetę",
        icon: ImageIcon,
        onClick: () => {
          const i = WALLPAPERS.findIndex((w) => w.id === wallpaper);
          setSettings({ wallpaper: WALLPAPERS[(i + 1) % WALLPAPERS.length].id });
        },
      },
      { label: "Ustawienia", icon: SettingsIcon, onClick: () => openApp("settings") },
      { separator: true },
      { label: "Zablokuj ekran", icon: Lock, onClick: lock },
    ]);

  return (
    <div className="absolute inset-0 overflow-hidden" onContextMenu={bgMenu} onPointerDown={() => setSel(null)}>
      <Wallpaper id={wallpaper} />

      <div className="absolute bottom-28 left-3 top-12 grid grid-flow-col grid-rows-[repeat(auto-fill,100px)] content-start gap-x-1 gap-y-0.5">
        <AnimatePresence>
          {items.map((n, i) => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ delay: i * 0.04, type: "spring", stiffness: 300, damping: 24 }}
            >
              <DesktopIcon node={n} selected={sel === n.id} onSelect={() => setSel(n.id)} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <ClockWidget />

      <div className="pointer-events-none absolute inset-0 z-10">
        <AnimatePresence>
          {windows.map((w) => (
            <Window key={w.id} win={w} active={w.id === activeId} vw={vp.w} vh={vp.h} />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
