import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Bell,
  BellOff,
  Bluetooth,
  ChevronLeft,
  ChevronRight,
  Lock,
  Moon,
  Power,
  Sun,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  X,
  type LucideIcon,
} from "lucide-react";
import { settings, setSettings, ACCENTS } from "../settings";
import { sys, closePanels, lock, shutdown, clearNotices, dismissToast, openApp } from "../system";
import { APP_META } from "../appMeta";
import { AppIcon, Slider } from "../ui";
import { MONTHS, WEEKDAYS, monthMatrix, sameDay } from "../calendarUtil";
import { fmtDateLong, fmtTime, useNow } from "../hooks";
import { askConfirm } from "../overlayStore";
import { cn } from "../../utils/cn";

function Tile({
  icon: Icon,
  label,
  sub,
  on,
  onClick,
}: {
  icon: LucideIcon;
  label: string;
  sub: string;
  on: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 rounded-2xl bg-surface-2 p-3 text-left transition hover:bg-surface-3 active:scale-[0.97]"
    >
      <span
        className={cn(
          "grid h-9 w-9 shrink-0 place-items-center rounded-full transition-colors duration-300",
          on ? "bg-accent-grad text-white shadow-lg" : "bg-surface-3 text-fg-dim"
        )}
      >
        <Icon size={17} />
      </span>
      <span className="min-w-0">
        <span className="block truncate text-[13px] font-semibold">{label}</span>
        <span className="block truncate text-[11px] text-fg-dim">{sub}</span>
      </span>
    </button>
  );
}

function ControlCenter() {
  const s = settings.use((x) => x);
  return (
    <motion.div
      initial={{ opacity: 0, y: -10, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -8, scale: 0.97 }}
      transition={{ type: "spring", stiffness: 420, damping: 32 }}
      style={{ transformOrigin: "top right" }}
      className="glass-strong absolute right-2 top-[42px] z-50 w-[340px] max-w-[96vw] rounded-3xl p-4 shadow-[0_30px_80px_-10px_rgba(0,0,0,.6)]"
    >
      <div className="grid grid-cols-2 gap-2.5">
        <Tile icon={s.wifi ? Wifi : WifiOff} label="Wi‑Fi" sub={s.wifi ? "Lumen-5G" : "Wyłączone"} on={s.wifi} onClick={() => setSettings({ wifi: !s.wifi })} />
        <Tile icon={Bluetooth} label="Bluetooth" sub={s.bluetooth ? "Włączony" : "Wyłączony"} on={s.bluetooth} onClick={() => setSettings({ bluetooth: !s.bluetooth })} />
        <Tile icon={s.dnd ? BellOff : Bell} label="Nie przeszkadzać" sub={s.dnd ? "Włączone" : "Wyłączone"} on={s.dnd} onClick={() => setSettings({ dnd: !s.dnd })} />
        <Tile
          icon={s.theme === "dark" ? Moon : Sun}
          label="Motyw"
          sub={s.theme === "dark" ? "Ciemny" : "Jasny"}
          on={s.theme === "dark"}
          onClick={() => setSettings({ theme: s.theme === "dark" ? "light" : "dark" })}
        />
      </div>

      <div className="mt-3 space-y-3 rounded-2xl bg-surface-2 p-3.5">
        <div>
          <div className="mb-2 flex items-center justify-between text-xs font-medium text-fg-dim">
            <span>Jasność</span>
            <span className="tabular-nums">{s.brightness}%</span>
          </div>
          <div className="flex items-center gap-3">
            <Sun size={15} className="text-fg-dim" />
            <Slider value={s.brightness} min={25} onChange={(v) => setSettings({ brightness: v })} />
          </div>
        </div>
        <div>
          <div className="mb-2 flex items-center justify-between text-xs font-medium text-fg-dim">
            <span>Głośność</span>
            <span className="tabular-nums">{s.volume}%</span>
          </div>
          <div className="flex items-center gap-3">
            {s.volume === 0 ? <VolumeX size={15} className="text-fg-dim" /> : <Volume2 size={15} className="text-fg-dim" />}
            <Slider value={s.volume} onChange={(v) => setSettings({ volume: v })} />
          </div>
        </div>
      </div>

      <div className="mt-3 rounded-2xl bg-surface-2 p-3.5">
        <div className="mb-2.5 text-xs font-medium text-fg-dim">Kolor akcentu</div>
        <div className="flex justify-between">
          {ACCENTS.map((a) => (
            <button
              key={a.color}
              title={a.name}
              onClick={() => setSettings({ accent: a.color })}
              className="relative h-7 w-7 rounded-full transition-transform hover:scale-110 active:scale-90"
              style={{ background: a.color }}
            >
              {s.accent === a.color && <span className="absolute inset-[-4px] rounded-full border-2" style={{ borderColor: a.color }} />}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-3 flex gap-2.5">
        <button
          onClick={lock}
          className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-surface-2 py-2.5 text-[13px] font-medium transition hover:bg-surface-3 active:scale-[0.97]"
        >
          <Lock size={15} /> Zablokuj
        </button>
        <button
          onClick={async () => {
            if (await askConfirm("Wyłączyć system?", "Wszystkie otwarte okna zostaną zamknięte.", "Wyłącz", true)) shutdown();
          }}
          className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-rose-500/20 py-2.5 text-[13px] font-medium text-rose-400 transition hover:bg-rose-500/30 active:scale-[0.97]"
        >
          <Power size={15} /> Wyłącz
        </button>
      </div>
    </motion.div>
  );
}

function MiniCalendar() {
  const now = useNow(60000);
  const [off, setOff] = useState(0);
  const base = new Date(now.getFullYear(), now.getMonth() + off, 1);
  const cells = monthMatrix(base.getFullYear(), base.getMonth());
  return (
    <div className="rounded-2xl bg-surface-2 p-3.5">
      <div className="mb-2 flex items-center justify-between">
        <div className="text-sm font-semibold">
          {MONTHS[base.getMonth()]} {base.getFullYear()}
        </div>
        <div className="flex gap-1">
          <button onClick={() => setOff((o) => o - 1)} className="rounded-md p-1 hover:bg-surface-3">
            <ChevronLeft size={15} />
          </button>
          <button onClick={() => setOff((o) => o + 1)} className="rounded-md p-1 hover:bg-surface-3">
            <ChevronRight size={15} />
          </button>
        </div>
      </div>
      <div className="grid grid-cols-7 gap-y-0.5 text-center text-[11px]">
        {WEEKDAYS.map((d) => (
          <div key={d} className="py-1 font-medium text-fg-faint">
            {d}
          </div>
        ))}
        {cells.map((c, i) => (
          <div
            key={i}
            className={cn(
              "mx-auto grid h-7 w-7 place-items-center rounded-full tabular-nums",
              !c.inMonth && "text-fg-faint",
              sameDay(c.date, now) && "bg-accent-grad font-semibold text-white shadow"
            )}
          >
            {c.date.getDate()}
          </div>
        ))}
      </div>
    </div>
  );
}

function NotifCenter() {
  const now = useNow(1000);
  const notices = sys.use((s) => s.notices);
  return (
    <motion.div
      initial={{ opacity: 0, x: 40 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 30 }}
      transition={{ type: "spring", stiffness: 380, damping: 34 }}
      className="glass-strong absolute bottom-3 right-2 top-[42px] z-50 flex w-[370px] max-w-[96vw] flex-col gap-3 overflow-y-auto rounded-3xl p-4 shadow-[0_30px_80px_-10px_rgba(0,0,0,.6)]"
    >
      <div className="px-1">
        <div className="text-4xl font-extralight tracking-tight">{fmtTime(now, true)}</div>
        <div className="text-sm capitalize text-fg-dim">{fmtDateLong(now)}</div>
      </div>
      <MiniCalendar />
      <div className="flex items-center justify-between px-1 pt-1">
        <div className="text-xs font-semibold uppercase tracking-wider text-fg-faint">Powiadomienia</div>
        {notices.length > 0 && (
          <button onClick={clearNotices} className="rounded-md px-2 py-0.5 text-xs text-fg-dim hover:bg-surface-3">
            Wyczyść
          </button>
        )}
      </div>
      {notices.length === 0 ? (
        <div className="grid flex-1 place-items-center rounded-2xl border border-dashed border-glass-border py-8 text-center text-sm text-fg-faint">
          <div>
            <Bell className="mx-auto mb-2 opacity-60" size={22} />
            Brak nowych powiadomień
          </div>
        </div>
      ) : (
        <AnimatePresence initial={false}>
          {notices.map((n) => (
            <motion.button
              layout
              key={n.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, x: 60 }}
              onClick={() => {
                if (n.appId) openApp(n.appId);
              }}
              className="flex items-start gap-3 rounded-2xl bg-surface-2 p-3 text-left transition hover:bg-surface-3"
            >
              {n.appId ? <AppIcon id={n.appId} size={34} /> : <div className="h-[34px] w-[34px] rounded-[9px] bg-accent-grad" />}
              <div className="min-w-0 flex-1">
                <div className="flex justify-between gap-2">
                  <span className="truncate text-[13px] font-semibold">{n.title}</span>
                  <span className="shrink-0 text-[11px] text-fg-faint">{fmtTime(new Date(n.time))}</span>
                </div>
                <div className="text-xs leading-snug text-fg-dim">{n.body}</div>
              </div>
            </motion.button>
          ))}
        </AnimatePresence>
      )}
    </motion.div>
  );
}

export function Panels() {
  const panel = sys.use((s) => s.panel);
  const open = panel === "controlCenter" || panel === "notifCenter";
  return (
    <>
      {open && <div className="absolute inset-0 z-40" onPointerDown={closePanels} />}
      <AnimatePresence mode="wait">
        {panel === "controlCenter" && <ControlCenter key="cc" />}
        {panel === "notifCenter" && <NotifCenter key="nc" />}
      </AnimatePresence>
    </>
  );
}

export function Toasts() {
  const toasts = sys.use((s) => s.toasts);
  return (
    <div className="pointer-events-none absolute right-3 top-12 z-[60] flex w-[340px] max-w-[94vw] flex-col gap-2">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, x: 80, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 80, scale: 0.9 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            className="glass-strong pointer-events-auto flex items-start gap-3 rounded-2xl p-3 shadow-[0_20px_50px_-10px_rgba(0,0,0,.55)]"
            onClick={() => {
              if (t.appId) openApp(t.appId);
              dismissToast(t.id);
            }}
          >
            {t.appId ? <AppIcon id={t.appId} size={38} /> : <div className="h-[38px] w-[38px] shrink-0 rounded-[10px] bg-accent-grad" />}
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-[13px] font-semibold">{t.title}</span>
                <span className="text-[10px] uppercase tracking-wider text-fg-faint">{t.appId ? APP_META[t.appId].name : "System"}</span>
              </div>
              <div className="text-xs leading-snug text-fg-dim">{t.body}</div>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                dismissToast(t.id);
              }}
              className="rounded-md p-0.5 text-fg-faint hover:bg-surface-3 hover:text-fg"
            >
              <X size={14} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
