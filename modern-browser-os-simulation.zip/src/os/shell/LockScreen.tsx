import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Lock } from "lucide-react";
import { Wallpaper } from "./Wallpaper";
import { settings } from "../settings";
import { notify, setSession, sys } from "../system";
import { fmtDateLong, fmtTime, useNow } from "../hooks";

let welcomedBoot = 0;

export function LockScreen() {
  const now = useNow(1000);
  const wallpaper = settings.use((s) => s.wallpaper);
  const name = settings.use((s) => s.userName);
  const [pw, setPw] = useState("");
  const [shake, setShake] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const [showForm, setShowForm] = useState(false);

  const unlock = () => {
    setSession("desktop");
    const boot = sys.get().bootedAt;
    if (welcomedBoot !== boot) {
      welcomedBoot = boot;
      setTimeout(
        () =>
          notify({
            title: `Witaj, ${settings.get().userName}!`,
            body: "Lumen OS jest gotowy. Naciśnij Ctrl + Spacja, aby otworzyć Spotlight.",
          }),
        1400
      );
    }
  };

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key.length === 1 || e.key === "Enter" || e.key === "ArrowUp") {
        if (!showForm) {
          setShowForm(true);
          setTimeout(() => inputRef.current?.focus(), 50);
        }
      }
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [showForm]);

  useEffect(() => {
    if (showForm) setTimeout(() => inputRef.current?.focus(), 80);
  }, [showForm]);

  return (
    <motion.div
      className="absolute inset-0 z-[100] flex flex-col items-center overflow-hidden text-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ y: "-100%", opacity: 0.6, transition: { duration: 0.75, ease: [0.7, 0, 0.2, 1] } }}
      transition={{ duration: 0.8 }}
      onClick={() => !showForm && setShowForm(true)}
    >
      <Wallpaper id={wallpaper} />
      <div className="absolute inset-0 bg-black/25 backdrop-blur-[6px]" />

      <motion.div
        className="relative mt-[11vh] text-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.8 }}
      >
        <div className="tshadow text-lg font-medium capitalize tracking-wide text-white/90">{fmtDateLong(now)}</div>
        <div className="tshadow text-[clamp(84px,16vw,168px)] font-extralight leading-none tracking-tight">{fmtTime(now)}</div>
      </motion.div>

      <div className="relative mt-auto flex flex-col items-center pb-[9vh]">
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 200, damping: 16 }}
          className="relative grid h-24 w-24 place-items-center rounded-full bg-accent-grad text-4xl font-semibold shadow-[0_10px_40px_rgba(0,0,0,.4)] ring-4 ring-white/25"
        >
          {name.charAt(0).toUpperCase()}
        </motion.div>
        <div className="tshadow mt-4 text-xl font-medium">{name}</div>

        <div className="mt-5 h-12">
          {showForm ? (
            <motion.form
              key={shake}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0, x: shake ? [0, -10, 10, -6, 6, 0] : 0 }}
              transition={{ duration: shake ? 0.4 : 0.3 }}
              onClick={(e) => e.stopPropagation()}
              onSubmit={(e) => {
                e.preventDefault();
                unlock();
              }}
              className="flex w-64 items-center gap-2 rounded-full border border-white/25 bg-white/15 py-1.5 pl-4 pr-1.5 backdrop-blur-xl"
            >
              <Lock size={14} className="opacity-70" />
              <input
                ref={inputRef}
                type="password"
                value={pw}
                onChange={(e) => {
                  setPw(e.target.value);
                  if (shake) setShake(0);
                }}
                placeholder="Dowolne hasło lub Enter"
                className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/55"
              />
              <button
                type="submit"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/25 transition hover:bg-white/40"
                aria-label="Odblokuj"
              >
                <ArrowRight size={16} />
              </button>
            </motion.form>
          ) : (
            <motion.div
              animate={{ opacity: [0.5, 1, 0.5], y: [0, -3, 0] }}
              transition={{ duration: 2.4, repeat: Infinity }}
              className="tshadow pt-2 text-sm text-white/85"
            >
              Kliknij lub naciśnij dowolny klawisz, aby odblokować
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
