import { AnimatePresence, motion } from "framer-motion";
import { getWallpaper } from "../wallpapers";
import { cn } from "../../utils/cn";

export function Wallpaper({
  id,
  still = false,
  blur = 70,
  className,
  vignette = true,
}: {
  id: string;
  still?: boolean;
  blur?: number;
  className?: string;
  vignette?: boolean;
}) {
  const wp = getWallpaper(id);
  return (
    <div className={cn("absolute inset-0 overflow-hidden", className)} style={{ background: wp.base }}>
      <AnimatePresence initial={false}>
        <motion.div
          key={wp.id}
          className="absolute inset-0 overflow-hidden"
          style={{ background: wp.base }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.1, ease: "easeInOut" }}
        >
          {wp.blobs.map((b, i) => (
            <div
              key={i}
              className="blob"
              style={{
                width: `${b.s}%`,
                left: `${b.x - b.s / 2}%`,
                top: `${b.y - b.s / 2}%`,
                background: b.c,
                filter: `blur(${blur}px)`,
                animation: still ? "none" : `float-${b.a} ${b.d}s ease-in-out infinite`,
              }}
            />
          ))}
          {vignette && (
            <div
              className="absolute inset-0"
              style={{ background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,.28) 100%)" }}
            />
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
