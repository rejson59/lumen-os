import { useEffect } from "react";
import { motion } from "framer-motion";
import { Power } from "lucide-react";
import { restart } from "../system";

export function PowerOff() {
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") restart();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);
  return (
    <motion.div
      className="absolute inset-0 z-[200] flex flex-col items-center justify-center bg-black"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <button
        onClick={restart}
        className="group relative grid h-20 w-20 place-items-center rounded-full border border-white/15 text-white/70 transition hover:border-white/40 hover:text-white"
        aria-label="Włącz system"
      >
        <span className="pulse-glow absolute inset-0 rounded-full bg-violet-500/20 blur-xl" />
        <Power size={28} className="relative" />
      </button>
      <div className="mt-6 text-sm text-white/40">System wyłączony — kliknij, aby włączyć</div>
    </motion.div>
  );
}
