import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Calculator, CornerDownLeft, Globe, Lock, Moon, Power, Search, Sun } from "lucide-react";
import { APP_LIST } from "../appMeta";
import { closePanels, lock, openApp, shutdown, sys } from "../system";
import { settings, setSettings } from "../settings";
import { useNodes, inTrash } from "../fs";
import { openNode } from "../fileActions";
import { NodeIcon } from "../NodeIcon";
import { AppIcon } from "../ui";
import { cn } from "../../utils/cn";

interface Result {
  id: string;
  group: string;
  title: string;
  sub?: string;
  icon: ReactNode;
  run: () => void;
}

function safeCalc(q: string): string | null {
  const t = q.replace(/,/g, ".").replace(/×/g, "*").replace(/÷/g, "/").replace(/\^/g, "**").trim();
  if (!/[0-9]/.test(t) || !/[+\-*/%]/.test(t)) return null;
  if (!/^[0-9+\-*/%().\s*]+$/.test(t)) return null;
  try {
    const v = Function(`"use strict"; return (${t})`)();
    if (typeof v !== "number" || !Number.isFinite(v)) return null;
    return String(parseFloat(v.toPrecision(12)));
  } catch {
    return null;
  }
}

export function Spotlight() {
  const open = sys.use((s) => s.panel === "spotlight");
  const nodes = useNodes();
  const theme = settings.use((s) => s.theme);
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQ("");
      setIdx(0);
      setTimeout(() => inputRef.current?.focus(), 80);
    }
  }, [open]);

  const results = useMemo<Result[]>(() => {
    const query = q.trim().toLowerCase();
    const out: Result[] = [];
    const calc = safeCalc(q);
    if (calc !== null)
      out.push({
        id: "calc",
        group: "Kalkulator",
        title: `${q.trim()} = ${calc}`,
        sub: "Otwórz w Kalkulatorze",
        icon: <Calculator size={20} className="text-orange-400" />,
        run: () => openApp("calculator"),
      });

    APP_LIST.filter((a) => !query || (a.name + " " + a.keywords).toLowerCase().includes(query))
      .slice(0, query ? 6 : 8)
      .forEach((a) =>
        out.push({ id: "app-" + a.id, group: "Aplikacje", title: a.name, sub: "Aplikacja", icon: <AppIcon id={a.id} size={30} />, run: () => openApp(a.id) })
      );

    if (query) {
      Object.values(nodes)
        .filter((n) => n.id !== "root" && n.name.toLowerCase().includes(query) && !inTrash(nodes, n))
        .slice(0, 5)
        .forEach((n) =>
          out.push({
            id: "f-" + n.id,
            group: "Pliki",
            title: n.name,
            sub: n.kind === "folder" ? "Folder" : n.kind === "image" ? "Obraz" : "Dokument tekstowy",
            icon: <div className="grid h-[30px] w-[30px] place-items-center"><NodeIcon node={n} size={26} /></div>,
            run: () => openNode(n),
          })
        );
    }

    const actions: Result[] = [
      { id: "a-theme", group: "Akcje", title: theme === "dark" ? "Przełącz na motyw jasny" : "Przełącz na motyw ciemny", icon: theme === "dark" ? <Sun size={18} /> : <Moon size={18} />, run: () => setSettings({ theme: theme === "dark" ? "light" : "dark" }) },
      { id: "a-lock", group: "Akcje", title: "Zablokuj ekran", icon: <Lock size={18} />, run: lock },
      { id: "a-off", group: "Akcje", title: "Wyłącz system", icon: <Power size={18} className="text-rose-400" />, run: shutdown },
    ];
    actions
      .filter((a) => !query || a.title.toLowerCase().includes(query))
      .slice(0, query ? 3 : 2)
      .forEach((a) => out.push(a));

    if (query)
      out.push({
        id: "web",
        group: "Internet",
        title: `Szukaj „${q.trim()}” w sieci`,
        sub: "Otwórz w Przeglądarce",
        icon: <Globe size={20} className="text-sky-400" />,
        run: () => openApp("browser", { url: q.trim(), nonce: Date.now() }),
      });
    return out;
  }, [q, nodes, theme]);

  useEffect(() => setIdx(0), [q]);

  const run = (r?: Result) => {
    if (!r) return;
    closePanels();
    r.run();
  };

  let lastGroup = "";

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="absolute inset-0 z-[55] flex justify-center bg-black/25 px-4 pt-[14vh] backdrop-blur-[3px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onPointerDown={closePanels}
        >
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 420, damping: 32 }}
            onPointerDown={(e) => e.stopPropagation()}
            className="glass-strong h-fit w-full max-w-[620px] overflow-hidden rounded-3xl shadow-[0_40px_100px_-10px_rgba(0,0,0,.65)]"
          >
            <div className="flex items-center gap-3 px-5 py-4">
              <Search size={20} className="text-accent" />
              <input
                ref={inputRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    setIdx((i) => Math.min(results.length - 1, i + 1));
                  } else if (e.key === "ArrowUp") {
                    e.preventDefault();
                    setIdx((i) => Math.max(0, i - 1));
                  } else if (e.key === "Enter") run(results[idx]);
                }}
                placeholder="Spotlight — szukaj aplikacji, plików, wpisz działanie…"
                className="w-full bg-transparent text-lg font-light outline-none placeholder:text-fg-faint"
              />
              <kbd className="rounded-md bg-surface-3 px-1.5 py-0.5 text-[10px] text-fg-dim">ESC</kbd>
            </div>
            <div className="max-h-[52vh] overflow-y-auto border-t border-glass-border p-2">
              {results.map((r, i) => {
                const header = r.group !== lastGroup;
                lastGroup = r.group;
                return (
                  <div key={r.id}>
                    {header && <div className="px-3 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-wider text-fg-faint">{r.group}</div>}
                    <button
                      onMouseMove={() => setIdx(i)}
                      onClick={() => run(r)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition-colors",
                        i === idx ? "bg-accent text-white" : ""
                      )}
                    >
                      <span className="grid w-[30px] place-items-center">{r.icon}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium">{r.title}</span>
                        {r.sub && <span className={cn("block truncate text-xs", i === idx ? "text-white/70" : "text-fg-dim")}>{r.sub}</span>}
                      </span>
                      {i === idx && <CornerDownLeft size={14} className="opacity-80" />}
                    </button>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
