import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { setSession } from "../system";
import { LumenLogo } from "../ui";

const STEPS = ["Uruchamianie jądra…", "Ładowanie interfejsu…", "Przygotowywanie kolorów…", "Prawie gotowe…"];

export function Boot() {
  const [p, setP] = useState(0);

  useEffect(() => {
    const start = performance.now();
    let raf = 0;
    let to: ReturnType<typeof setTimeout> | undefined;
    const tick = (t: number) => {
      const k = Math.min(1, (t - start) / 3200);
      setP(k);
      if (k < 1) raf = requestAnimationFrame(tick);
      else to = setTimeout(() => setSession("lock"), 380);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      if (to) clearTimeout(to);
    };
  }, []);

  const eased = 1 - Math.pow(1 - p, 2.2);

  return (
    <motion.div
      className="absolute inset-0 z-[200] flex flex-col items-center justify-center overflow-hidden bg-black"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.7 }}
    >
      <div
        className="pulse-glow absolute h-[520px] w-[520px] rounded-full opacity-60 blur-[90px]"
        style={{ background: "conic-gradient(from 0deg,#8b5cf6,#06b6d4,#34d399,#f43f5e,#8b5cf6)" }}
      />
      <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 120, damping: 14 }}>
        <LumenLogo size={96} spin />
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 10, letterSpacing: "0.1em" }}
        animate={{ opacity: 1, y: 0, letterSpacing: "0.4em" }}
        transition={{ delay: 0.4, duration: 1.2 }}
        className="relative mt-8 text-2xl font-extralight uppercase text-white"
      >
        Lumen
      </motion.div>
      <div className="relative mt-10 h-1 w-52 overflow-hidden rounded-full bg-white/10">
        <div
          className="h-full rounded-full"
          style={{
            width: `${eased * 100}%`,
            background: "linear-gradient(90deg,#8b5cf6,#06b6d4,#34d399)",
            boxShadow: "0 0 14px rgba(139,92,246,.8)",
          }}
        />
      </div>
      <div className="relative mt-4 h-4 text-xs text-white/50">{STEPS[Math.min(STEPS.length - 1, Math.floor(p * STEPS.length))]}</div>
    </motion.div>
  );
}
