import type { LucideIcon } from "lucide-react";
import { createStore } from "./store";

export interface CtxItem {
  label?: string;
  icon?: LucideIcon;
  hint?: string;
  onClick?: () => void;
  danger?: boolean;
  separator?: boolean;
  disabled?: boolean;
}

interface CtxState {
  open: boolean;
  x: number;
  y: number;
  items: CtxItem[];
}

export const ctxMenu = createStore<CtxState>({ open: false, x: 0, y: 0, items: [] });

export function showMenu(
  e: { clientX: number; clientY: number; preventDefault: () => void; stopPropagation: () => void },
  items: CtxItem[]
) {
  e.preventDefault();
  e.stopPropagation();
  ctxMenu.set({ open: true, x: e.clientX, y: e.clientY, items });
}

export function hideMenu() {
  if (ctxMenu.get().open) ctxMenu.set({ open: false });
}

/* ---------- dialogi ---------- */

export interface DialogReq {
  kind: "prompt" | "confirm";
  title: string;
  message?: string;
  value?: string;
  okLabel?: string;
  danger?: boolean;
  resolve: (v: string | boolean | null) => void;
}

export const dialogStore = createStore<{ current: DialogReq | null }>({ current: null });

export function askText(title: string, value = "", message?: string): Promise<string | null> {
  return new Promise((resolve) => {
    dialogStore.set({
      current: { kind: "prompt", title, value, message, resolve: (v) => resolve(v as string | null) },
    });
  });
}

export function askConfirm(title: string, message: string, okLabel = "OK", danger = false): Promise<boolean> {
  return new Promise((resolve) => {
    dialogStore.set({
      current: { kind: "confirm", title, message, okLabel, danger, resolve: (v) => resolve(Boolean(v)) },
    });
  });
}
