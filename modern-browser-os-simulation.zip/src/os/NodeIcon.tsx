import { cn } from "../utils/cn";
import type { FSNode } from "./fs";

const FOLDER_COLORS: Record<string, [string, string]> = {
  desktop: ["#c4b5fd", "#7c3aed"],
  docs: ["#7dd3fc", "#2563eb"],
  pics: ["#fda4af", "#e11d48"],
  music: ["#f0abfc", "#c026d3"],
  downloads: ["#6ee7b7", "#059669"],
  trash: ["#cbd5e1", "#64748b"],
  root: ["#fcd34d", "#f59e0b"],
};
const DEFAULT_FOLDER: [string, string] = ["#67e8f9", "#0ea5e9"];

export function ImageView({ content, className }: { content?: string; className?: string }) {
  if (!content) return <div className={cn("h-full w-full bg-surface-2", className)} />;
  if (content.startsWith("gradient:"))
    return <div className={cn("h-full w-full", className)} style={{ background: content.slice(9) }} />;
  return <img src={content} alt="" draggable={false} className={cn("h-full w-full object-cover", className)} />;
}

export function FolderGlyph({ size = 56, id }: { size?: number; id?: string }) {
  const [a, b] = (id && FOLDER_COLORS[id]) || DEFAULT_FOLDER;
  const gid = `fg-${a.slice(1)}-${b.slice(1)}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" className="drop-shadow-[0_6px_10px_rgba(0,0,0,.3)]">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={a} />
          <stop offset="1" stopColor={b} />
        </linearGradient>
      </defs>
      <path d="M5 15a4 4 0 0 1 4-4h15l6 6h25a4 4 0 0 1 4 4v8H5z" fill={b} opacity=".8" />
      <rect x="4" y="22" width="56" height="34" rx="5" fill={`url(#${gid})`} />
      <rect x="4" y="22" width="56" height="2.2" rx="1" fill="#fff" opacity=".4" />
    </svg>
  );
}

export function FileGlyph({ size = 56, ext }: { size?: number; ext: string }) {
  return (
    <div className="relative drop-shadow-[0_6px_10px_rgba(0,0,0,.3)]" style={{ width: size * 0.78, height: size }}>
      <div className="absolute inset-0 rounded-lg bg-gradient-to-b from-white to-slate-200" />
      <div className="absolute right-0 top-0 h-[22%] w-[28%] rounded-bl-lg rounded-tr-lg bg-slate-300" />
      <div className="absolute left-[16%] right-[16%] top-[34%] space-y-[7%]">
        {[1, 0.8, 0.9, 0.55].map((w, i) => (
          <div key={i} className="h-[2.5px] rounded-full bg-slate-400/70" style={{ width: `${w * 100}%` }} />
        ))}
      </div>
      <div className="absolute bottom-[6%] left-[10%] rounded bg-accent px-1 text-[8px] font-bold uppercase leading-[12px] text-white">
        {ext.replace(".", "") || "txt"}
      </div>
    </div>
  );
}

export function NodeIcon({ node, size = 56 }: { node: FSNode; size?: number }) {
  if (node.kind === "folder") return <FolderGlyph size={size} id={node.id} />;
  if (node.kind === "image")
    return (
      <div
        className="overflow-hidden rounded-lg ring-1 ring-white/40 shadow-[0_6px_14px_rgba(0,0,0,.35)]"
        style={{ width: size * 1.05, height: size * 0.78 }}
      >
        <ImageView content={node.content} />
      </div>
    );
  const i = node.name.lastIndexOf(".");
  return <FileGlyph size={size} ext={i > 0 ? node.name.slice(i) : ".txt"} />;
}
