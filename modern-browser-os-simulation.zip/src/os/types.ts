export interface AppProps {
  winId: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  props: Record<string, any>;
  active: boolean;
}
