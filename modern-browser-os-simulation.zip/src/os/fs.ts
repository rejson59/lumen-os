import { createStore } from "./store";

export type NodeKind = "folder" | "text" | "image";

export interface FSNode {
  id: string;
  name: string;
  kind: NodeKind;
  parent: string | null;
  content?: string;
  created: number;
  modified: number;
  trashedFrom?: string;
}

export const ROOT = "root";
export const TRASH = "trash";

const now = Date.now();
let seedTick = 0;

function mk(id: string, name: string, kind: NodeKind, parent: string | null, content?: string): FSNode {
  const t = now - 1000 * 60 * 60 * (24 + seedTick++ * 7);
  return { id, name, kind, parent, content, created: t, modified: t };
}

export const PHOTO_SEED: [string, string][] = [
  [
    "Zorza polarna.jpg",
    "radial-gradient(at 15% 20%, #34d399 0, transparent 55%), radial-gradient(at 85% 15%, #6366f1 0, transparent 55%), radial-gradient(at 50% 95%, #22d3ee 0, transparent 60%), #0b1033",
  ],
  [
    "Zachód słońca.jpg",
    "radial-gradient(at 20% 85%, #fb923c 0, transparent 55%), radial-gradient(at 80% 70%, #ec4899 0, transparent 55%), radial-gradient(at 50% 5%, #7c3aed 0, transparent 60%), #1e1b4b",
  ],
  [
    "Laguna.jpg",
    "radial-gradient(at 10% 10%, #22d3ee 0, transparent 50%), radial-gradient(at 90% 30%, #3b82f6 0, transparent 55%), radial-gradient(at 40% 100%, #34d399 0, transparent 55%), #052e3a",
  ],
  [
    "Neonowe miasto.jpg",
    "radial-gradient(at 25% 25%, #ff00c8 0, transparent 50%), radial-gradient(at 80% 80%, #00fff0 0, transparent 50%), radial-gradient(at 75% 10%, #7000ff 0, transparent 55%), #0a0216",
  ],
  [
    "Wata cukrowa.jpg",
    "radial-gradient(at 20% 20%, #ff9ac1 0, transparent 55%), radial-gradient(at 85% 25%, #a78bfa 0, transparent 55%), radial-gradient(at 60% 95%, #7dd3fc 0, transparent 55%), #fde7f3",
  ],
  [
    "Leśna mgła.jpg",
    "radial-gradient(at 80% 15%, #a3e635 0, transparent 50%), radial-gradient(at 15% 80%, #10b981 0, transparent 55%), radial-gradient(at 70% 90%, #0ea5e9 0, transparent 55%), #062a22",
  ],
  [
    "Lawa.jpg",
    "radial-gradient(at 50% 100%, #facc15 0, transparent 50%), radial-gradient(at 15% 60%, #ef4444 0, transparent 55%), radial-gradient(at 85% 40%, #f97316 0, transparent 55%), #1c0a0a",
  ],
  [
    "Galaktyka.jpg",
    "radial-gradient(at 30% 40%, #a855f7 0, transparent 50%), radial-gradient(at 75% 65%, #3b82f6 0, transparent 50%), radial-gradient(at 55% 15%, #f472b6 0, transparent 45%), #05030f",
  ],
];

function seed(): Record<string, FSNode> {
  const list: FSNode[] = [
    { id: ROOT, name: "~", kind: "folder", parent: null, created: now, modified: now },
    mk("desktop", "Pulpit", "folder", ROOT),
    mk("docs", "Dokumenty", "folder", ROOT),
    mk("pics", "Obrazy", "folder", ROOT),
    mk("music", "Muzyka", "folder", ROOT),
    mk("downloads", "Pobrane", "folder", ROOT),
    mk(TRASH, "Kosz", "folder", ROOT),
    mk(
      "f-welcome",
      "Witaj w Lumen OS.txt",
      "text",
      "desktop",
      "Witaj w Lumen OS ✨\n\nTo w pełni działający system operacyjny uruchomiony w Twojej przeglądarce.\n\nCo możesz zrobić?\n• Przeciągaj, zmieniaj rozmiar i minimalizuj okna\n• Naciśnij Ctrl + Spacja (lub Alt + Spacja), aby otworzyć Spotlight\n• Kliknij ikonę siatki w docku, aby zobaczyć wszystkie aplikacje\n• Otwórz Centrum sterowania w prawym górnym rogu\n• Zmień motyw, kolor akcentu i tapetę w Ustawieniach\n• Pobaw się w Terminalu — wpisz „help”\n\nMiłej zabawy!"
    ),
    mk(
      "f-ideas",
      "Pomysły.txt",
      "text",
      "docs",
      "Pomysły na weekend\n\n1. Spacer nad jeziorem o wschodzie słońca\n2. Zrobić playlistę na długą podróż\n3. Narysować coś kolorowego w Szkicowniku\n4. Wypróbować nowy przepis na pad thai"
    ),
    mk(
      "f-shopping",
      "Lista zakupów.txt",
      "text",
      "docs",
      "• Awokado\n• Pomarańcze\n• Chleb na zakwasie\n• Oliwa z oliwek\n• Kawa ziarnista\n• Świeża bazylia"
    ),
    mk(
      "f-plan",
      "Plan projektu.md",
      "text",
      "docs",
      "# Plan projektu\n\n## Etap 1 — Szkic\nZebrać inspiracje, określić paletę kolorów i styl.\n\n## Etap 2 — Prototyp\nZbudować interaktywny prototyp i przetestować go z użytkownikami.\n\n## Etap 3 — Premiera\nWypuścić wersję 1.0 i świętować 🎉"
    ),
    mk("f-music-readme", "Jak działa muzyka.txt", "text", "music", "Aplikacja Muzyka generuje ambientową muzykę na żywo za pomocą Web Audio API.\nKażdy utwór to inna progresja akordów — nic nie jest nagraniem!"),
  ];
  PHOTO_SEED.forEach(([name, css], i) => list.push(mk(`img-${i}`, name, "image", "pics", "gradient:" + css)));
  return Object.fromEntries(list.map((n) => [n.id, n]));
}

export const fsStore = createStore<{ nodes: Record<string, FSNode> }>({ nodes: seed() }, "lumen.fs.v1");

export const useNodes = () => fsStore.use((s) => s.nodes);

export type Nodes = Record<string, FSNode>;

export function childrenOf(nodes: Nodes, parent: string): FSNode[] {
  return Object.values(nodes)
    .filter((n) => n.parent === parent)
    .sort((a, b) => {
      if ((a.kind === "folder") !== (b.kind === "folder")) return a.kind === "folder" ? -1 : 1;
      return a.name.localeCompare(b.name, "pl");
    });
}

export function pathNodes(nodes: Nodes, id: string): FSNode[] {
  const out: FSNode[] = [];
  let cur: FSNode | undefined = nodes[id];
  let guard = 0;
  while (cur && guard++ < 50) {
    out.unshift(cur);
    cur = cur.parent ? nodes[cur.parent] : undefined;
  }
  return out;
}

export function pathString(nodes: Nodes, id: string): string {
  const p = pathNodes(nodes, id);
  return "~" + p.slice(1).map((n) => "/" + n.name).join("");
}

export function inTrash(nodes: Nodes, n: FSNode): boolean {
  return pathNodes(nodes, n.id).some((x) => x.id === TRASH);
}

export function inferKind(name: string): NodeKind {
  const l = name.toLowerCase();
  if (/\.(png|jpe?g|gif|webp)$/.test(l)) return "image";
  return "text";
}

export function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i > 0 ? name.slice(i) : "";
}

export function uniqueName(nodes: Nodes, parent: string, name: string): string {
  const siblings = new Set(Object.values(nodes).filter((n) => n.parent === parent).map((n) => n.name.toLowerCase()));
  if (!siblings.has(name.toLowerCase())) return name;
  const ext = extOf(name);
  const base = ext ? name.slice(0, -ext.length) : name;
  let i = 2;
  while (siblings.has(`${base} (${i})${ext}`.toLowerCase())) i++;
  return `${base} (${i})${ext}`;
}

let idCounter = 0;
export function createNode(parent: string, name: string, kind: NodeKind, content = ""): string {
  const nodes = fsStore.get().nodes;
  const id = `n-${Date.now().toString(36)}-${idCounter++}`;
  const t = Date.now();
  const node: FSNode = {
    id,
    name: uniqueName(nodes, parent, name.trim() || "Bez nazwy"),
    kind,
    parent,
    content: kind === "folder" ? undefined : content,
    created: t,
    modified: t,
  };
  fsStore.set({ nodes: { ...nodes, [id]: node } });
  return id;
}

export function renameNode(id: string, name: string) {
  const nodes = fsStore.get().nodes;
  const n = nodes[id];
  if (!n || !name.trim() || n.id === ROOT) return;
  const unique = n.name === name ? name : uniqueName(nodes, n.parent ?? ROOT, name.trim());
  fsStore.set({ nodes: { ...nodes, [id]: { ...n, name: unique, modified: Date.now() } } });
}

export function writeNode(id: string, content: string) {
  const nodes = fsStore.get().nodes;
  const n = nodes[id];
  if (!n) return;
  fsStore.set({ nodes: { ...nodes, [id]: { ...n, content, modified: Date.now() } } });
}

const PROTECTED = new Set([ROOT, "desktop", "docs", "pics", "music", "downloads", TRASH]);
export const isProtected = (id: string) => PROTECTED.has(id);

export function trashNode(id: string) {
  const nodes = fsStore.get().nodes;
  const n = nodes[id];
  if (!n || PROTECTED.has(id)) return;
  fsStore.set({
    nodes: { ...nodes, [id]: { ...n, parent: TRASH, trashedFrom: n.parent ?? ROOT, name: uniqueName(nodes, TRASH, n.name) } },
  });
}

export function restoreNode(id: string) {
  const nodes = fsStore.get().nodes;
  const n = nodes[id];
  if (!n) return;
  const target = n.trashedFrom && nodes[n.trashedFrom] ? n.trashedFrom : ROOT;
  fsStore.set({
    nodes: { ...nodes, [id]: { ...n, parent: target, trashedFrom: undefined, name: uniqueName(nodes, target, n.name) } },
  });
}

export function deleteNode(id: string) {
  const nodes = { ...fsStore.get().nodes };
  if (PROTECTED.has(id)) return;
  const kill = (nid: string) => {
    Object.values(nodes)
      .filter((n) => n.parent === nid)
      .forEach((c) => kill(c.id));
    delete nodes[nid];
  };
  kill(id);
  fsStore.set({ nodes });
}

export function emptyTrash() {
  childrenOf(fsStore.get().nodes, TRASH).forEach((n) => deleteNode(n.id));
}

/** Rozwiązuje ścieżkę (np. "../Dokumenty/plik.txt") względem katalogu cwd. */
export function resolvePath(nodes: Nodes, cwd: string, path: string): string | null {
  let cur = cwd;
  let p = path.trim();
  if (p === "" ) return cur;
  if (p.startsWith("~") || p.startsWith("/")) {
    cur = ROOT;
    p = p.replace(/^~/, "");
  }
  for (const part of p.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") {
      cur = nodes[cur]?.parent ?? ROOT;
      continue;
    }
    const next = Object.values(nodes).find((n) => n.parent === cur && n.name.toLowerCase() === part.toLowerCase());
    if (!next) return null;
    cur = next.id;
  }
  return cur;
}

export function fsBytes(nodes: Nodes): number {
  return Object.values(nodes).reduce((a, n) => a + (n.content?.length ?? 0) + n.name.length + 64, 0);
}

export function formatBytes(b: number): string {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}
