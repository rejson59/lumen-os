import { createStore } from "./store";
import { APP_META, type AppId } from "./appMeta";
import { settings } from "./settings";

export const MENU_H = 36;
export const DOCK_SPACE = 100;

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface WinState extends Rect {
  id: string;
  appId: AppId;
  title: string;
  z: number;
  minimized: boolean;
  maximized: boolean;
  prev?: Rect;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  props: Record<string, any>;
}

export interface Notice {
  id: string;
  title: string;
  body: string;
  appId?: AppId;
  time: number;
}

export type Session = "boot" | "lock" | "desktop" | "off";
export type Panel = "controlCenter" | "notifCenter" | "spotlight" | "launchpad";

interface SysState {
  session: Session;
  windows: WinState[];
  zTop: number;
  activeId: string | null;
  panel: Panel | null;
  notices: Notice[];
  toasts: Notice[];
  bootedAt: number;
}

export const sys = createStore<SysState>({
  session: "boot",
  windows: [],
  zTop: 10,
  activeId: null,
  panel: null,
  notices: [],
  toasts: [],
  bootedAt: Date.now(),
});

let uid = 0;

export const maxRect = (vw: number, vh: number): Rect => ({
  x: 8,
  y: MENU_H + 6,
  w: vw - 16,
  h: vh - MENU_H - 6 - DOCK_SPACE + 10,
});

const topVisible = (ws: WinState[]) =>
  ws
    .filter((w) => !w.minimized)
    .sort((a, b) => b.z - a.z)[0]?.id ?? null;

export function openApp(appId: AppId, props: Record<string, unknown> = {}) {
  const meta = APP_META[appId];
  const s = sys.get();
  if (meta.single) {
    const ex = s.windows.find((w) => w.appId === appId);
    if (ex) {
      sys.set((st) => ({
        windows: st.windows.map((w) => (w.id === ex.id ? { ...w, props: { ...w.props, ...props } } : w)),
        panel: null,
      }));
      focusWindow(ex.id);
      return ex.id;
    }
  }
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const availH = vh - MENU_H - DOCK_SPACE + 20;
  const w = Math.min(meta.w, vw - 16);
  const h = Math.min(meta.h, availH);
  const off = (s.windows.length % 6) * 30;
  const x = Math.max(8, Math.min(vw - w - 8, (vw - w) / 2 + off - 75));
  const y = Math.max(MENU_H + 6, MENU_H + (availH - h) / 2 + off - 45);
  const id = "w" + ++uid;
  const z = s.zTop + 1;
  const win: WinState = {
    id,
    appId,
    title: meta.name,
    x,
    y,
    w,
    h,
    z,
    minimized: false,
    maximized: vw < 700,
    props,
  };
  sys.set({ windows: [...s.windows, win], zTop: z, activeId: id, panel: null });
  return id;
}

export function focusWindow(id: string) {
  sys.set((s) => {
    const w = s.windows.find((x) => x.id === id);
    if (!w) return {};
    if (s.activeId === id && !w.minimized) return {};
    const z = s.zTop + 1;
    return {
      zTop: z,
      activeId: id,
      windows: s.windows.map((x) => (x.id === id ? { ...x, z, minimized: false } : x)),
    };
  });
}

export function closeWindow(id: string) {
  sys.set((s) => {
    const windows = s.windows.filter((w) => w.id !== id);
    return { windows, activeId: s.activeId === id ? topVisible(windows) : s.activeId };
  });
}

export function closeAllOf(appId: AppId) {
  sys.set((s) => {
    const windows = s.windows.filter((w) => w.appId !== appId);
    const active = windows.find((w) => w.id === s.activeId) ? s.activeId : topVisible(windows);
    return { windows, activeId: active };
  });
}

export function minimizeWindow(id: string) {
  sys.set((s) => {
    const windows = s.windows.map((w) => (w.id === id ? { ...w, minimized: true } : w));
    return { windows, activeId: s.activeId === id ? topVisible(windows) : s.activeId };
  });
}

export function toggleMaximize(id: string) {
  sys.set((s) => ({
    windows: s.windows.map((w) => {
      if (w.id !== id) return w;
      if (w.maximized) {
        const p = w.prev ?? { x: w.x, y: w.y, w: w.w, h: w.h };
        return { ...w, ...p, maximized: false, prev: undefined };
      }
      return { ...w, maximized: true, prev: { x: w.x, y: w.y, w: w.w, h: w.h } };
    }),
  }));
  focusWindow(id);
}

export function setWinRect(id: string, patch: Partial<Omit<WinState, "id">>) {
  sys.set((s) => ({
    windows: s.windows.map((w) => (w.id === id ? { ...w, ...patch } : w)),
  }));
}

export function setWinTitle(id: string, title: string) {
  sys.set((s) => {
    const w = s.windows.find((x) => x.id === id);
    if (!w || w.title === title) return {};
    return { windows: s.windows.map((x) => (x.id === id ? { ...x, title } : x)) };
  });
}

/* ---------- panele ---------- */

export function togglePanel(p: Panel) {
  sys.set((s) => ({ panel: s.panel === p ? null : p }));
}
export function closePanels() {
  if (sys.get().panel) sys.set({ panel: null });
}

/* ---------- powiadomienia ---------- */

export function notify(n: Omit<Notice, "id" | "time">) {
  const notice: Notice = { ...n, id: "n" + ++uid, time: Date.now() };
  const dnd = settings.get().dnd;
  sys.set((s) => ({
    notices: [notice, ...s.notices].slice(0, 30),
    toasts: dnd ? s.toasts : [...s.toasts, notice].slice(-3),
  }));
  if (!dnd) setTimeout(() => dismissToast(notice.id), 5500);
}

export function dismissToast(id: string) {
  sys.set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));
}

export function clearNotices() {
  sys.set({ notices: [], toasts: [] });
}

/* ---------- sesja ---------- */

export const setSession = (session: Session) => sys.set({ session, panel: null });
export const lock = () => setSession("lock");
export const shutdown = () => sys.set({ session: "off", windows: [], activeId: null, panel: null, toasts: [] });
export const restart = () =>
  sys.set({ session: "boot", windows: [], activeId: null, panel: null, toasts: [], bootedAt: Date.now() });
