import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Cloud, CloudFog, CloudLightning, CloudMoon, CloudRain, CloudSnow, CloudSun, Droplets, Moon, RefreshCw, Sun, Thermometer, Wind, WifiOff } from "lucide-react";
import type { AppProps } from "../types";
import { cn } from "../../utils/cn";

const CITIES = [
  { name: "Warszawa", lat: 52.23, lon: 21.01 },
  { name: "Kraków", lat: 50.06, lon: 19.94 },
  { name: "Gdańsk", lat: 54.35, lon: 18.65 },
  { name: "Wrocław", lat: 51.11, lon: 17.04 },
  { name: "Zakopane", lat: 49.3, lon: 19.95 },
  { name: "Tokio", lat: 35.68, lon: 139.69 },
  { name: "Reykjavik", lat: 64.15, lon: -21.94 },
];

interface Wx {
  offline?: boolean;
  current: { temperature_2m: number; apparent_temperature: number; relative_humidity_2m: number; weather_code: number; wind_speed_10m: number; is_day: number };
  hourly: { time: string[]; temperature_2m: number[]; weather_code: number[] };
  daily: { time: string[]; weather_code: number[]; temperature_2m_max: number[]; temperature_2m_min: number[] };
}

type Kind = "clear" | "partly" | "cloud" | "fog" | "rain" | "snow" | "storm";

function cond(code: number): { label: string; kind: Kind } {
  if (code === 0) return { label: "Bezchmurnie", kind: "clear" };
  if (code === 1) return { label: "Prawie bezchmurnie", kind: "clear" };
  if (code === 2) return { label: "Częściowe zachmurzenie", kind: "partly" };
  if (code === 3) return { label: "Pochmurno", kind: "cloud" };
  if (code === 45 || code === 48) return { label: "Mgła", kind: "fog" };
  if (code >= 51 && code <= 57) return { label: "Mżawka", kind: "rain" };
  if (code >= 61 && code <= 67) return { label: "Deszcz", kind: "rain" };
  if (code >= 71 && code <= 77) return { label: "Śnieg", kind: "snow" };
  if (code >= 80 && code <= 82) return { label: "Przelotne opady", kind: "rain" };
  if (code === 85 || code === 86) return { label: "Przelotny śnieg", kind: "snow" };
  if (code >= 95) return { label: "Burza", kind: "storm" };
  return { label: "Zmienna pogoda", kind: "partly" };
}

const BG: Record<Kind, [string, string]> = {
  clear: ["#38bdf8", "#2563eb"],
  partly: ["#60a5fa", "#64748b"],
  cloud: ["#94a3b8", "#475569"],
  fog: ["#cbd5e1", "#64748b"],
  rain: ["#475569", "#1e293b"],
  snow: ["#bae6fd", "#475569"],
  storm: ["#4c1d95", "#0f172a"],
};

function WxIcon({ kind, day = true, size = 48, anim = false }: { kind: Kind; day?: boolean; size?: number; anim?: boolean }) {
  const p = { size, strokeWidth: 1.5 };
  switch (kind) {
    case "clear":
      return day ? <Sun {...p} className={cn("text-amber-300 drop-shadow-[0_0_18px_rgba(252,211,77,.8)]", anim && "spin-slow")} /> : <Moon {...p} className={cn("text-indigo-100 drop-shadow-[0_0_14px_rgba(199,210,254,.7)]", anim && "bob")} />;
    case "partly":
      return day ? <CloudSun {...p} className={cn("text-amber-200", anim && "bob")} /> : <CloudMoon {...p} className={cn("text-indigo-100", anim && "bob")} />;
    case "cloud":
      return <Cloud {...p} className={cn("text-slate-100", anim && "drift")} />;
    case "fog":
      return <CloudFog {...p} className={cn("text-slate-100", anim && "drift")} />;
    case "rain":
      return <CloudRain {...p} className={cn("text-sky-200", anim && "bob")} />;
    case "snow":
      return <CloudSnow {...p} className={cn("text-white", anim && "bob")} />;
    case "storm":
      return <CloudLightning {...p} className={cn("text-yellow-200", anim && "bob")} />;
  }
}

function Particles({ kind }: { kind: Kind }) {
  const items = useMemo(
    () => Array.from({ length: kind === "snow" ? 40 : 55 }, () => ({ left: Math.random() * 100, delay: Math.random() * 3, dur: (kind === "snow" ? 4 : 0.9) + Math.random() * (kind === "snow" ? 4 : 0.8), size: 2 + Math.random() * 3 })),
    [kind]
  );
  if (kind !== "rain" && kind !== "snow" && kind !== "storm") return null;
  const snow = kind === "snow";
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {items.map((d, i) => (
        <span
          key={i}
          className="absolute top-0 block"
          style={{
            left: `${d.left}%`,
            width: snow ? d.size : 1.5,
            height: snow ? d.size : 14 + d.size * 2,
            borderRadius: 9999,
            background: snow ? "#fff" : "linear-gradient(to bottom, transparent, rgba(186,230,253,.9))",
            animation: `${snow ? "snow-fall" : "rain-fall"} ${d.dur}s linear ${d.delay}s infinite`,
          }}
        />
      ))}
      {kind === "storm" && <div className="absolute inset-0 bg-white" style={{ animation: "flash 6s infinite", opacity: 0 }} />}
    </div>
  );
}

function fakeWx(seed: number): Wx {
  const now = new Date();
  const base = 14 + (seed % 5) * 2;
  const hourly = { time: [] as string[], temperature_2m: [] as number[], weather_code: [] as number[] };
  for (let i = 0; i < 48; i++) {
    const t = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() + i);
    hourly.time.push(t.toISOString());
    hourly.temperature_2m.push(Math.round(base + 6 * Math.sin(((t.getHours() - 9) / 24) * Math.PI * 2)));
    hourly.weather_code.push([0, 1, 2, 3, 61, 2, 0][(Math.floor(i / 6) + seed) % 7]);
  }
  const daily = { time: [] as string[], weather_code: [] as number[], temperature_2m_max: [] as number[], temperature_2m_min: [] as number[] };
  for (let i = 0; i < 7; i++) {
    const t = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
    daily.time.push(t.toISOString());
    daily.weather_code.push([1, 2, 3, 61, 0, 2, 80][(i + seed) % 7]);
    daily.temperature_2m_max.push(base + 4 + ((i * 3 + seed) % 5));
    daily.temperature_2m_min.push(base - 5 + ((i * 2 + seed) % 3));
  }
  const h = now.getHours();
  return {
    offline: true,
    current: { temperature_2m: base + 2, apparent_temperature: base + 1, relative_humidity_2m: 58, weather_code: hourly.weather_code[0], wind_speed_10m: 12, is_day: h >= 6 && h < 20 ? 1 : 0 },
    hourly,
    daily,
  };
}

const cache = new Map<number, Wx>();

export function WeatherApp(_: AppProps) {
  void _;
  const [ci, setCi] = useState(0);
  const [data, setData] = useState<Wx | null>(cache.get(0) ?? null);
  const [loading, setLoading] = useState(!cache.has(0));
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    const cached = nonce === 0 ? cache.get(ci) : undefined;
    if (cached) {
      setData(cached);
      setLoading(false);
      return;
    }
    let dead = false;
    setLoading(true);
    const c = CITIES[ci];
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day&hourly=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=7`;
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 7000);
    fetch(url, { signal: ctrl.signal })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("http"))))
      .then((j: Wx) => {
        if (dead) return;
        cache.set(ci, j);
        setData(j);
      })
      .catch(() => {
        if (dead) return;
        const f = fakeWx(ci);
        cache.set(ci, f);
        setData(f);
      })
      .finally(() => {
        clearTimeout(timeout);
        if (!dead) setLoading(false);
      });
    return () => {
      dead = true;
      clearTimeout(timeout);
      ctrl.abort();
    };
  }, [ci, nonce]);

  const cur = data ? cond(data.current.weather_code) : null;
  const day = data ? data.current.is_day === 1 : true;
  const [from, to] = cur ? (cur.kind === "clear" && !day ? ["#312e81", "#0f172a"] : BG[cur.kind]) : ["#38bdf8", "#2563eb"];

  // następne 24 godziny od bieżącej
  const hours = useMemo(() => {
    if (!data) return [];
    const now = Date.now() - 3600_000;
    const start = Math.max(0, data.hourly.time.findIndex((t) => new Date(t).getTime() > now));
    return data.hourly.time.slice(start, start + 24).map((t, i) => ({
      t,
      temp: data.hourly.temperature_2m[start + i],
      code: data.hourly.weather_code[start + i],
    }));
  }, [data]);

  const wkMin = data ? Math.min(...data.daily.temperature_2m_min) : 0;
  const wkMax = data ? Math.max(...data.daily.temperature_2m_max) : 1;

  return (
    <div className="relative h-full w-full overflow-hidden text-white">
      <AnimatePresence initial={false}>
        <motion.div
          key={`${from}-${to}`}
          className="absolute inset-0"
          style={{ background: `linear-gradient(160deg, ${from}, ${to})` }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
        />
      </AnimatePresence>
      {cur && <Particles kind={cur.kind} />}
      <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-white/20 blur-[80px]" />

      <div className="relative flex h-full flex-col overflow-y-auto p-5">
        <div className="flex items-center gap-2">
          <div className="flex flex-1 gap-1.5 overflow-x-auto pb-1">
            {CITIES.map((c, i) => (
              <button
                key={c.name}
                onClick={() => setCi(i)}
                className={cn("shrink-0 rounded-full px-3.5 py-1.5 text-xs font-medium backdrop-blur transition", i === ci ? "bg-white text-slate-900 shadow" : "bg-white/15 hover:bg-white/25")}
              >
                {c.name}
              </button>
            ))}
          </div>
          <button onClick={() => setNonce((n) => n + 1)} className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/15 backdrop-blur transition hover:bg-white/25" title="Odśwież">
            <RefreshCw size={14} className={cn(loading && "animate-spin")} />
          </button>
        </div>

        {data && cur ? (
          <motion.div key={ci} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="mt-4 flex flex-1 flex-col">
            <div className="flex items-center justify-between gap-4">
              <div>
                <div className="text-lg font-medium">{CITIES[ci].name}</div>
                <div className="text-[84px] font-thin leading-none tracking-tighter">{Math.round(data.current.temperature_2m)}°</div>
                <div className="mt-1 text-lg">{cur.label}</div>
                <div className="text-sm text-white/75">
                  Maks. {Math.round(data.daily.temperature_2m_max[0])}° · Min. {Math.round(data.daily.temperature_2m_min[0])}°
                </div>
              </div>
              <div className="pr-4">
                <WxIcon kind={cur.kind} day={day} size={120} anim />
              </div>
            </div>

            {data.offline && (
              <div className="mt-3 flex w-fit items-center gap-1.5 rounded-full bg-black/25 px-3 py-1 text-xs backdrop-blur">
                <WifiOff size={12} /> Tryb offline — dane przykładowe
              </div>
            )}

            <div className="mt-4 grid grid-cols-3 gap-2.5">
              {[
                [Thermometer, "Odczuwalna", `${Math.round(data.current.apparent_temperature)}°`],
                [Droplets, "Wilgotność", `${Math.round(data.current.relative_humidity_2m)}%`],
                [Wind, "Wiatr", `${Math.round(data.current.wind_speed_10m)} km/h`],
              ].map(([Icon, label, val]) => {
                const I = Icon as typeof Wind;
                return (
                  <div key={label as string} className="rounded-2xl bg-white/15 p-3 backdrop-blur-md">
                    <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-white/70">
                      <I size={12} /> {label as string}
                    </div>
                    <div className="mt-1 text-2xl font-light">{val as string}</div>
                  </div>
                );
              })}
            </div>

            <div className="mt-3 rounded-2xl bg-white/15 p-3 backdrop-blur-md">
              <div className="mb-2 text-[11px] uppercase tracking-wider text-white/70">Prognoza godzinowa</div>
              <div className="flex gap-4 overflow-x-auto pb-1">
                {hours.map((h, i) => {
                  const d = new Date(h.t);
                  const hr = d.getHours();
                  return (
                    <div key={h.t} className="flex shrink-0 flex-col items-center gap-1.5">
                      <span className="text-xs text-white/80">{i === 0 ? "Teraz" : `${String(hr).padStart(2, "0")}:00`}</span>
                      <WxIcon kind={cond(h.code).kind} day={hr >= 6 && hr < 20} size={26} />
                      <span className="text-sm font-medium">{Math.round(h.temp)}°</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-3 rounded-2xl bg-white/15 p-3 backdrop-blur-md">
              <div className="mb-1 text-[11px] uppercase tracking-wider text-white/70">Prognoza 7-dniowa</div>
              {data.daily.time.map((t, i) => {
                const lo = data.daily.temperature_2m_min[i];
                const hi = data.daily.temperature_2m_max[i];
                const range = Math.max(1, wkMax - wkMin);
                return (
                  <div key={t} className="flex items-center gap-3 border-t border-white/10 py-1.5 first:border-0">
                    <span className="w-20 text-sm capitalize">{i === 0 ? "Dziś" : new Date(t).toLocaleDateString("pl-PL", { weekday: "long" })}</span>
                    <WxIcon kind={cond(data.daily.weather_code[i]).kind} size={22} />
                    <span className="w-8 text-right text-sm text-white/70">{Math.round(lo)}°</span>
                    <div className="relative h-1.5 flex-1 rounded-full bg-black/20">
                      <div
                        className="absolute h-full rounded-full bg-gradient-to-r from-sky-300 via-emerald-300 to-amber-300"
                        style={{ left: `${((lo - wkMin) / range) * 100}%`, width: `${Math.max(8, ((hi - lo) / range) * 100)}%` }}
                      />
                    </div>
                    <span className="w-8 text-sm">{Math.round(hi)}°</span>
                  </div>
                );
              })}
            </div>
          </motion.div>
        ) : (
          <div className="grid flex-1 place-items-center">
            <div className="flex flex-col items-center gap-3 text-white/80">
              <RefreshCw className="animate-spin" />
              Pobieranie prognozy…
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
