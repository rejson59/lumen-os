import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Image as ImageIcon, Trash2, X } from "lucide-react";
import type { AppProps } from "../types";
import { inTrash, trashNode, useNodes } from "../fs";
import { ImageView } from "../NodeIcon";
import { cn } from "../../utils/cn";

export function PhotosApp({ props, active }: AppProps) {
  const nodes = useNodes();
  const photos = useMemo(
    () =>
      Object.values(nodes)
        .filter((n) => n.kind === "image" && !inTrash(nodes, n))
        .sort((a, b) => b.created - a.created),
    [nodes]
  );
  const [openId, setOpenId] = useState<string | null>(props.fileId ?? null);

  useEffect(() => {
    if (props.fileId) setOpenId(props.fileId);
  }, [props.fileId]);

  const idx = photos.findIndex((p) => p.id === openId);
  const cur = idx >= 0 ? photos[idx] : null;

  const step = (d: number) => {
    if (!photos.length) return;
    setOpenId(photos[(idx + d + photos.length) % photos.length].id);
  };

  useEffect(() => {
    if (!active || !cur) return;
    const k = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") step(1);
      else if (e.key === "ArrowLeft") step(-1);
      else if (e.key === "Escape") setOpenId(null);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  return (
    <div className="relative h-full w-full overflow-hidden">
      <div className="h-full overflow-y-auto p-5">
        <div className="mb-4 flex items-end justify-between">
          <div>
            <div className="text-2xl font-semibold tracking-tight">Zdjęcia</div>
            <div className="text-xs text-fg-dim">{photos.length} elementów · zapisz rysunek ze Szkicownika, aby pojawił się tutaj</div>
          </div>
        </div>
        {photos.length === 0 ? (
          <div className="grid h-64 place-items-center text-center text-fg-faint">
            <div>
              <ImageIcon size={40} className="mx-auto mb-2 opacity-50" />
              Brak zdjęć
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-[repeat(auto-fill,minmax(170px,1fr))] gap-3">
            {photos.map((p, i) => (
              <motion.button
                key={p.id}
                initial={{ opacity: 0, y: 20, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: Math.min(i * 0.04, 0.5), type: "spring", stiffness: 260, damping: 24 }}
                whileHover={{ y: -4 }}
                onClick={() => setOpenId(p.id)}
                className="group text-left"
              >
                <motion.div layoutId={`ph-${p.id}`} className="aspect-[4/3] overflow-hidden rounded-2xl shadow-lg ring-1 ring-white/15">
                  <ImageView content={p.content} className="transition-transform duration-500 group-hover:scale-110" />
                </motion.div>
                <div className="mt-1.5 truncate px-1 text-xs text-fg-dim">{p.name.replace(/\.[^.]+$/, "")}</div>
              </motion.button>
            ))}
          </div>
        )}
      </div>

      <AnimatePresence>
        {cur && (
          <motion.div
            key="viewer"
            className="absolute inset-0 z-10 flex flex-col bg-black/75 backdrop-blur-2xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpenId(null)}
          >
            <div className="flex items-center justify-between px-5 py-3 text-white" onClick={(e) => e.stopPropagation()}>
              <div className="min-w-0">
                <div className="truncate text-sm font-medium">{cur.name}</div>
                <div className="text-xs text-white/60">
                  {idx + 1} z {photos.length}
                </div>
              </div>
              <div className="flex gap-1">
                <button
                  onClick={() => {
                    const next = photos[(idx + 1) % photos.length];
                    trashNode(cur.id);
                    setOpenId(photos.length > 1 ? next.id : null);
                  }}
                  className="grid h-9 w-9 place-items-center rounded-full transition hover:bg-white/15"
                  title="Przenieś do kosza"
                >
                  <Trash2 size={17} />
                </button>
                <button onClick={() => setOpenId(null)} className="grid h-9 w-9 place-items-center rounded-full transition hover:bg-white/15">
                  <X size={18} />
                </button>
              </div>
            </div>
            <div className="relative flex min-h-0 flex-1 items-center justify-center px-16 pb-8">
              <motion.div
                key={cur.id}
                layoutId={`ph-${cur.id}`}
                onClick={(e) => e.stopPropagation()}
                className={cn("aspect-[16/10] max-h-full max-w-full overflow-hidden rounded-2xl shadow-2xl ring-1 ring-white/20")}
                style={{ height: "100%" }}
              >
                <ImageView content={cur.content} className="!object-contain" />
              </motion.div>
              {photos.length > 1 &&
                ([[-1, ChevronLeft, "left-3"], [1, ChevronRight, "right-3"]] as const).map(([d, Icon, pos]) => (
                  <button
                    key={d}
                    onClick={(e) => {
                      e.stopPropagation();
                      step(d);
                    }}
                    className={cn("absolute top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white backdrop-blur transition hover:bg-white/25 active:scale-90", pos)}
                  >
                    <Icon size={22} />
                  </button>
                ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
