import { useEffect, useRef, useState } from "react";
import { Brush, Eraser, Save, Sparkles, SprayCan, Trash2, Undo2, type LucideIcon } from "lucide-react";
import type { AppProps } from "../types";
import { Slider } from "../ui";
import { createNode } from "../fs";
import { notify } from "../system";
import { cn } from "../../utils/cn";

const W = 1200;
const H = 760;

type Tool = "brush" | "rainbow" | "spray" | "eraser";

const TOOLS: { id: Tool; icon: LucideIcon; label: string }[] = [
  { id: "brush", icon: Brush, label: "Pędzel" },
  { id: "rainbow", icon: Sparkles, label: "Tęcza" },
  { id: "spray", icon: SprayCan, label: "Spray" },
  { id: "eraser", icon: Eraser, label: "Gumka" },
];

const PALETTE = ["#111827", "#ef4444", "#f97316", "#facc15", "#22c55e", "#06b6d4", "#3b82f6", "#8b5cf6", "#ec4899", "#ffffff"];

export function PaintApp(_: AppProps) {
  void _;
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [fit, setFit] = useState({ w: 600, h: 380 });
  const [tool, setTool] = useState<Tool>("brush");
  const [color, setColor] = useState("#8b5cf6");
  const [size, setSize] = useState(10);
  const [undoCount, setUndoCount] = useState(0);
  const drawing = useRef(false);
  const last = useRef({ x: 0, y: 0 });
  const hue = useRef(0);
  const snaps = useRef<ImageData[]>([]);

  useEffect(() => {
    const c = canvasRef.current!;
    const g = c.getContext("2d")!;
    g.fillStyle = "#ffffff";
    g.fillRect(0, 0, W, H);
  }, []);

  useEffect(() => {
    const el = wrapRef.current!;
    const ro = new ResizeObserver(() => {
      const cw = el.clientWidth - 32;
      const ch = el.clientHeight - 32;
      const s = Math.max(0.1, Math.min(cw / W, ch / H));
      setFit({ w: Math.round(W * s), h: Math.round(H * s) });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const pos = (e: React.PointerEvent) => {
    const c = canvasRef.current!;
    const r = c.getBoundingClientRect();
    return { x: ((e.clientX - r.left) * W) / r.width, y: ((e.clientY - r.top) * H) / r.height };
  };

  const pushSnap = () => {
    const g = canvasRef.current!.getContext("2d")!;
    snaps.current.push(g.getImageData(0, 0, W, H));
    if (snaps.current.length > 25) snaps.current.shift();
    setUndoCount(snaps.current.length);
  };

  const stroke = (from: { x: number; y: number }, to: { x: number; y: number }) => {
    const g = canvasRef.current!.getContext("2d")!;
    g.lineCap = "round";
    g.lineJoin = "round";
    if (tool === "spray") {
      const dist = Math.hypot(to.x - from.x, to.y - from.y);
      const steps = Math.max(1, Math.floor(dist / 6));
      g.fillStyle = color;
      for (let s = 0; s < steps; s++) {
        const t = s / steps;
        const cx = from.x + (to.x - from.x) * t;
        const cy = from.y + (to.y - from.y) * t;
        for (let i = 0; i < 14; i++) {
          const a = Math.random() * Math.PI * 2;
          const r = Math.random() * size * 1.8;
          g.fillRect(cx + Math.cos(a) * r, cy + Math.sin(a) * r, 1.8, 1.8);
        }
      }
      return;
    }
    if (tool === "rainbow") {
      hue.current = (hue.current + 3) % 360;
      g.strokeStyle = `hsl(${hue.current} 90% 58%)`;
    } else g.strokeStyle = tool === "eraser" ? "#ffffff" : color;
    g.lineWidth = tool === "eraser" ? size * 2 : size;
    g.beginPath();
    g.moveTo(from.x, from.y);
    g.lineTo(to.x + 0.01, to.y + 0.01);
    g.stroke();
  };

  const down = (e: React.PointerEvent) => {
    if (e.button !== 0) return;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    pushSnap();
    drawing.current = true;
    const p = pos(e);
    last.current = p;
    stroke(p, p);
  };
  const move = (e: React.PointerEvent) => {
    if (!drawing.current) return;
    const p = pos(e);
    stroke(last.current, p);
    last.current = p;
  };
  const up = () => {
    drawing.current = false;
  };

  const undo = () => {
    const s = snaps.current.pop();
    if (!s) return;
    canvasRef.current!.getContext("2d")!.putImageData(s, 0, 0);
    setUndoCount(snaps.current.length);
  };
  const clear = () => {
    pushSnap();
    const g = canvasRef.current!.getContext("2d")!;
    g.fillStyle = "#ffffff";
    g.fillRect(0, 0, W, H);
  };
  const save = () => {
    const url = canvasRef.current!.toDataURL("image/jpeg", 0.82);
    const d = new Date();
    const name = `Rysunek ${d.toLocaleDateString("pl-PL")} ${d.toLocaleTimeString("pl-PL", { hour: "2-digit", minute: "2-digit" }).replace(":", ".")}.jpg`;
    createNode("pics", name, "image", url);
    notify({ title: "Rysunek zapisany", body: `„${name}” czeka w folderze Obrazy i aplikacji Zdjęcia.`, appId: "photos" });
  };

  const ghost = "grid h-8 w-8 place-items-center rounded-lg text-fg-dim transition hover:bg-surface-3 hover:text-fg disabled:opacity-30 disabled:hover:bg-transparent";

  return (
    <div className="flex h-full w-full flex-col">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-glass-border px-3 py-2">
        <div className="flex rounded-xl bg-surface-2 p-0.5">
          {TOOLS.map((t) => (
            <button
              key={t.id}
              title={t.label}
              onClick={() => setTool(t.id)}
              className={cn("grid h-8 w-9 place-items-center rounded-[10px] transition", tool === t.id ? "bg-accent-grad text-white shadow" : "text-fg-dim hover:text-fg")}
            >
              <t.icon size={16} />
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          {PALETTE.map((c) => (
            <button
              key={c}
              onClick={() => {
                setColor(c);
                if (tool === "eraser" || tool === "rainbow") setTool("brush");
              }}
              className={cn("h-6 w-6 rounded-full ring-1 ring-black/20 transition-transform hover:scale-110", color === c && tool !== "rainbow" && tool !== "eraser" && "scale-110 ring-2 ring-offset-2 ring-offset-transparent ring-accent")}
              style={{ background: c }}
            />
          ))}
          <label className="relative grid h-6 w-6 cursor-pointer place-items-center overflow-hidden rounded-full ring-1 ring-black/20" style={{ background: "conic-gradient(red,yellow,lime,aqua,blue,magenta,red)" }}>
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="absolute inset-0 cursor-pointer opacity-0" />
          </label>
        </div>
        <div className="flex w-36 items-center gap-2">
          <span className="grid h-6 w-6 place-items-center">
            <span className="rounded-full bg-fg" style={{ width: Math.max(3, size / 3 + 2), height: Math.max(3, size / 3 + 2) }} />
          </span>
          <Slider value={size} min={2} max={60} onChange={setSize} />
        </div>
        <div className="ml-auto flex items-center gap-1">
          <button className={ghost} onClick={undo} disabled={undoCount === 0} title="Cofnij"><Undo2 size={16} /></button>
          <button className={ghost} onClick={clear} title="Wyczyść"><Trash2 size={16} /></button>
          <button onClick={save} className="ml-1 flex items-center gap-1.5 rounded-xl bg-accent-grad px-3 py-1.5 text-xs font-medium text-white shadow transition hover:brightness-110 active:scale-95">
            <Save size={14} /> Zapisz
          </button>
        </div>
      </div>
      <div ref={wrapRef} className="grid min-h-0 flex-1 place-items-center overflow-hidden bg-surface p-4">
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          onPointerDown={down}
          onPointerMove={move}
          onPointerUp={up}
          onPointerCancel={up}
          className="touch-none rounded-xl bg-white shadow-[0_20px_50px_-10px_rgba(0,0,0,.5)]"
          style={{ width: fit.w, height: fit.h, cursor: "crosshair" }}
        />
      </div>
    </div>
  );
}
