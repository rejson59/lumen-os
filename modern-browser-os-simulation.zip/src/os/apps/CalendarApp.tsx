import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Plus, X } from "lucide-react";
import type { AppProps } from "../types";
import { createStore } from "../store";
import { MONTHS, WEEKDAYS, dayKey, monthMatrix, sameDay } from "../calendarUtil";
import { cn } from "../../utils/cn";

interface Ev {
  id: string;
  title: string;
  time: string;
  color: string;
}

const COLORS = ["#8b5cf6", "#06b6d4", "#10b981", "#f59e0b", "#ec4899", "#f43f5e"];

function seedEvents(): Record<string, Ev[]> {
  const d = (off: number) => {
    const t = new Date();
    t.setDate(t.getDate() + off);
    return dayKey(t);
  };
  return {
    [d(0)]: [{ id: "s1", title: "Spotkanie zespołu", time: "10:00", color: "#8b5cf6" }, { id: "s2", title: "Joga o zachodzie słońca", time: "18:30", color: "#10b981" }],
    [d(1)]: [{ id: "s3", title: "Lunch z Anią", time: "13:30", color: "#f59e0b" }],
    [d(3)]: [{ id: "s4", title: "Premiera projektu 🎉", time: "09:00", color: "#ec4899" }],
    [d(6)]: [{ id: "s5", title: "Wycieczka w góry", time: "07:00", color: "#06b6d4" }],
  };
}

const calStore = createStore<{ events: Record<string, Ev[]> }>({ events: seedEvents() }, "lumen.calendar.v1");

export function CalendarApp(_: AppProps) {
  void _;
  const events = calStore.use((s) => s.events);
  const today = new Date();
  const [view, setView] = useState({ y: today.getFullYear(), m: today.getMonth() });
  const [sel, setSel] = useState(today);
  const [title, setTitle] = useState("");
  const [time, setTime] = useState("12:00");
  const [color, setColor] = useState(COLORS[0]);
  const [dir, setDir] = useState(1);

  const cells = monthMatrix(view.y, view.m);
  const selKey = dayKey(sel);
  const list = [...(events[selKey] ?? [])].sort((a, b) => a.time.localeCompare(b.time));

  const shift = (d: number) => {
    setDir(d);
    const t = new Date(view.y, view.m + d, 1);
    setView({ y: t.getFullYear(), m: t.getMonth() });
  };

  const add = () => {
    const t = title.trim();
    if (!t) return;
    const ev: Ev = { id: "e" + Date.now(), title: t, time, color };
    calStore.set((s) => ({ events: { ...s.events, [selKey]: [...(s.events[selKey] ?? []), ev] } }));
    setTitle("");
  };
  const remove = (id: string) =>
    calStore.set((s) => ({ events: { ...s.events, [selKey]: (s.events[selKey] ?? []).filter((e) => e.id !== id) } }));

  return (
    <div className="flex h-full w-full">
      <div className="flex min-w-0 flex-1 flex-col p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="relative h-9 min-w-[220px] overflow-hidden">
            <AnimatePresence mode="popLayout" custom={dir} initial={false}>
              <motion.div
                key={`${view.y}-${view.m}`}
                custom={dir}
                initial={{ y: dir * 24, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: dir * -24, opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="text-3xl font-semibold tracking-tight"
              >
                {MONTHS[view.m]} <span className="font-light text-fg-dim">{view.y}</span>
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => shift(-1)} className="grid h-8 w-8 place-items-center rounded-lg hover:bg-surface-3"><ChevronLeft size={18} /></button>
            <button
              onClick={() => {
                setView({ y: today.getFullYear(), m: today.getMonth() });
                setSel(today);
              }}
              className="rounded-lg bg-surface-2 px-3 py-1 text-xs font-medium hover:bg-surface-3"
            >
              Dziś
            </button>
            <button onClick={() => shift(1)} className="grid h-8 w-8 place-items-center rounded-lg hover:bg-surface-3"><ChevronRight size={18} /></button>
          </div>
        </div>
        <div className="grid grid-cols-7 pb-1 text-center text-[11px] font-semibold uppercase tracking-wider text-fg-faint">
          {WEEKDAYS.map((d) => (
            <div key={d}>{d}</div>
          ))}
        </div>
        <div className="grid min-h-0 flex-1 grid-cols-7 grid-rows-6 gap-1">
          {cells.map((c, i) => {
            const k = dayKey(c.date);
            const evs = events[k] ?? [];
            const isToday = sameDay(c.date, today);
            const isSel = k === selKey;
            return (
              <button
                key={i}
                onClick={() => {
                  setSel(c.date);
                  if (!c.inMonth) setView({ y: c.date.getFullYear(), m: c.date.getMonth() });
                }}
                className={cn(
                  "relative flex flex-col items-start overflow-hidden rounded-xl p-1.5 text-left transition-all duration-200",
                  c.inMonth ? "bg-surface hover:bg-surface-2" : "opacity-40 hover:opacity-70",
                  isSel && "ring-2 ring-accent"
                )}
              >
                <span
                  className={cn(
                    "grid h-6 w-6 place-items-center rounded-full text-xs tabular-nums",
                    isToday && "bg-accent-grad font-semibold text-white shadow"
                  )}
                >
                  {c.date.getDate()}
                </span>
                <div className="mt-0.5 flex w-full flex-col gap-0.5">
                  {evs.slice(0, 2).map((e) => (
                    <span key={e.id} className="hidden w-full truncate rounded px-1 text-[10px] leading-4 text-white sm:block" style={{ background: e.color }}>
                      {e.title}
                    </span>
                  ))}
                  {evs.length > 0 && (
                    <span className="flex gap-0.5 sm:hidden">
                      {evs.slice(0, 3).map((e) => (
                        <span key={e.id} className="h-1.5 w-1.5 rounded-full" style={{ background: e.color }} />
                      ))}
                    </span>
                  )}
                  {evs.length > 2 && <span className="hidden text-[10px] text-fg-dim sm:block">+{evs.length - 2} więcej</span>}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <aside className="flex w-[250px] shrink-0 flex-col border-l border-glass-border bg-surface p-5">
        <div className="text-xs font-semibold uppercase tracking-wider text-accent">
          {sel.toLocaleDateString("pl-PL", { weekday: "long" })}
        </div>
        <div className="text-3xl font-semibold capitalize tracking-tight">
          {sel.toLocaleDateString("pl-PL", { day: "numeric", month: "long" })}
        </div>
        <div className="mt-4 min-h-0 flex-1 space-y-2 overflow-y-auto">
          <AnimatePresence initial={false}>
            {list.map((e) => (
              <motion.div
                layout
                key={e.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20, height: 0 }}
                className="group flex items-center gap-3 rounded-xl bg-surface-2 py-2 pl-2 pr-1.5"
              >
                <span className="h-9 w-1 shrink-0 rounded-full" style={{ background: e.color }} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13px] font-medium">{e.title}</div>
                  <div className="text-xs tabular-nums text-fg-dim">{e.time}</div>
                </div>
                <button onClick={() => remove(e.id)} className="grid h-6 w-6 place-items-center rounded-md text-fg-faint opacity-0 transition hover:bg-rose-500/20 hover:text-rose-400 group-hover:opacity-100">
                  <X size={13} />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
          {list.length === 0 && <div className="py-6 text-center text-xs text-fg-faint">Brak wydarzeń tego dnia</div>}
        </div>
        <form
          className="mt-3 space-y-2 border-t border-glass-border pt-3"
          onSubmit={(e) => {
            e.preventDefault();
            add();
          }}
        >
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Nowe wydarzenie"
            className="w-full rounded-xl border border-glass-border bg-surface-2 px-3 py-2 text-[13px] outline-none focus:ring-2 focus:ring-accent"
          />
          <div className="flex items-center gap-2">
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-[90px] rounded-xl border border-glass-border bg-surface-2 px-2 py-1.5 text-[13px] outline-none focus:ring-2 focus:ring-accent"
            />
            <div className="flex flex-1 justify-between">
              {COLORS.map((c) => (
                <button
                  type="button"
                  key={c}
                  onClick={() => setColor(c)}
                  className={cn("h-4 w-4 rounded-full transition-transform", color === c && "scale-125 ring-2 ring-fg/60 ring-offset-1 ring-offset-transparent")}
                  style={{ background: c }}
                />
              ))}
            </div>
          </div>
          <button type="submit" className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-accent-grad py-2 text-[13px] font-medium text-white shadow transition hover:brightness-110 active:scale-[0.98]">
            <Plus size={15} /> Dodaj
          </button>
        </form>
      </aside>
    </div>
  );
}
