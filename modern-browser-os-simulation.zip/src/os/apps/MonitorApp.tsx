import { useEffect, useRef, useState } from "react";
import { Cpu, HardDrive, MemoryStick, Network, X } from "lucide-react";
import type { AppProps } from "../types";
import { APP_META } from "../appMeta";
import { closeWindow, sys } from "../system";
import { AppIcon } from "../ui";
import { fsBytes, formatBytes, useNodes } from "../fs";
import { isPlaying } from "../audio";

const POINTS = 48;

function Spark({ data, color, id }: { data: number[]; color: string; id: string }) {
  const w = 240;
  const h = 64;
  const pts = data.map((v, i) => [(i / (POINTS - 1)) * w, h - (Math.min(100, v) / 100) * (h - 4) - 2]);
  const line = pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-16 w-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity="0.45" />
          <stop offset="1" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${line} L${w},${h} L0,${h} Z`} fill={`url(#${id})`} />
      <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

const SYSTEM_PROCS = [
  { name: "lumen-kernel", cpu: 1.2, mem: 96 },
  { name: "compositor", cpu: 2.4, mem: 142 },
  { name: "window-server", cpu: 0.9, mem: 78 },
  { name: "dock", cpu: 0.3, mem: 34 },
];

export function MonitorApp(_: AppProps) {
  void _;
  const nodes = useNodes();
  const windows = sys.use((s) => s.windows);
  const [cpu, setCpu] = useState<number[]>(() => Array(POINTS).fill(10));
  const [mem, setMem] = useState<number[]>(() => Array(POINTS).fill(30));
  const [net, setNet] = useState({ up: 12, down: 240 });
  const procs = useRef<Record<string, { cpu: number; mem: number }>>({});
  const [, force] = useState(0);
  const wins = useRef(windows);
  wins.current = windows;

  useEffect(() => {
    const t = setInterval(() => {
      const n = wins.current.length;
      const target = 6 + n * 5 + (isPlaying() ? 9 : 0);
      setCpu((a) => [...a.slice(1), Math.max(2, Math.min(98, a[a.length - 1] * 0.6 + target * 0.4 + (Math.random() - 0.5) * 14))]);
      setMem((a) => [...a.slice(1), Math.min(95, 24 + n * 3.5 + Math.sin(Date.now() / 6000) * 2 + Math.random())]);
      setNet({ up: Math.round(4 + Math.random() * 40), down: Math.round(60 + Math.random() * 600) });
      wins.current.forEach((w) => {
        const p = procs.current[w.id] ?? { cpu: 2 + Math.random() * 4, mem: 80 + Math.random() * 160 };
        procs.current[w.id] = {
          cpu: Math.max(0.1, p.cpu * 0.7 + (w.minimized ? 0.2 : 3 + Math.random() * 6) * 0.3),
          mem: p.mem + (Math.random() - 0.5) * 2,
        };
      });
      force((x) => x + 1);
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const disk = fsBytes(nodes);
  const diskPct = Math.min(100, (disk / (5 * 1024 * 1024)) * 100);
  const cpuNow = cpu[cpu.length - 1];
  const memNow = mem[mem.length - 1];

  const rows = [
    ...windows.map((w) => ({
      key: w.id,
      pid: w.id,
      name: w.title,
      app: w.appId,
      cpu: procs.current[w.id]?.cpu ?? 1,
      mem: procs.current[w.id]?.mem ?? 100,
      state: w.minimized ? "uśpiony" : "aktywny",
      kill: () => closeWindow(w.id),
    })),
    ...SYSTEM_PROCS.map((p, i) => ({
      key: p.name,
      pid: `s${i}`,
      name: p.name,
      app: null,
      cpu: p.cpu + (Math.random() - 0.5) * 0.3,
      mem: p.mem,
      state: "system",
      kill: null,
    })),
  ].sort((a, b) => b.cpu - a.cpu);

  const cards = [
    { icon: Cpu, label: "Procesor", value: `${cpuNow.toFixed(0)}%`, data: cpu, color: "#8b5cf6", id: "g-cpu" },
    { icon: MemoryStick, label: "Pamięć", value: `${memNow.toFixed(0)}%`, data: mem, color: "#06b6d4", id: "g-mem" },
  ];

  return (
    <div className="h-full overflow-y-auto p-5">
      <div className="grid grid-cols-2 gap-3">
        {cards.map((c) => (
          <div key={c.label} className="overflow-hidden rounded-2xl bg-surface p-4 ring-1 ring-glass-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-medium text-fg-dim">
                <c.icon size={14} style={{ color: c.color }} /> {c.label}
              </div>
              <div className="text-2xl font-light tabular-nums">{c.value}</div>
            </div>
            <div className="-mx-4 -mb-4 mt-2">
              <Spark data={c.data} color={c.color} id={c.id} />
            </div>
          </div>
        ))}
        <div className="rounded-2xl bg-surface p-4 ring-1 ring-glass-border">
          <div className="flex items-center justify-between text-xs font-medium text-fg-dim">
            <span className="flex items-center gap-2"><HardDrive size={14} className="text-amber-400" /> Wirtualny dysk</span>
            <span className="tabular-nums">{formatBytes(disk)} / 5 MB</span>
          </div>
          <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-surface-3">
            <div className="h-full rounded-full bg-gradient-to-r from-amber-400 to-rose-500 transition-all duration-700" style={{ width: `${Math.max(2, diskPct)}%` }} />
          </div>
          <div className="mt-2 text-xs text-fg-dim">{diskPct.toFixed(1)}% zajęte · pliki zapisują się lokalnie</div>
        </div>
        <div className="rounded-2xl bg-surface p-4 ring-1 ring-glass-border">
          <div className="flex items-center gap-2 text-xs font-medium text-fg-dim">
            <Network size={14} className="text-emerald-400" /> Sieć
          </div>
          <div className="mt-3 flex justify-between">
            <div>
              <div className="text-[10px] uppercase tracking-wider text-fg-faint">Wysyłanie</div>
              <div className="text-xl font-light tabular-nums">{net.up} <span className="text-xs text-fg-dim">KB/s</span></div>
            </div>
            <div className="text-right">
              <div className="text-[10px] uppercase tracking-wider text-fg-faint">Pobieranie</div>
              <div className="text-xl font-light tabular-nums">{net.down} <span className="text-xs text-fg-dim">KB/s</span></div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 overflow-hidden rounded-2xl bg-surface ring-1 ring-glass-border">
        <div className="grid grid-cols-[1fr_70px_80px_90px_40px] gap-2 border-b border-glass-border px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-fg-faint">
          <span>Proces</span>
          <span className="text-right">CPU</span>
          <span className="text-right">Pamięć</span>
          <span>Stan</span>
          <span />
        </div>
        {rows.map((r) => (
          <div key={r.key} className="grid grid-cols-[1fr_70px_80px_90px_40px] items-center gap-2 px-4 py-1.5 text-[13px] transition-colors hover:bg-surface-2">
            <span className="flex min-w-0 items-center gap-2.5">
              {r.app ? <AppIcon id={r.app} size={22} /> : <span className="grid h-[22px] w-[22px] place-items-center rounded-md bg-surface-3"><Cpu size={12} className="text-fg-dim" /></span>}
              <span className="truncate">{r.name}</span>
              <span className="text-[11px] text-fg-faint">{r.app ? `${APP_META[r.app].name} · ` : ""}{r.pid}</span>
            </span>
            <span className="text-right tabular-nums">{r.cpu.toFixed(1)}%</span>
            <span className="text-right tabular-nums">{r.mem.toFixed(0)} MB</span>
            <span className={r.state === "aktywny" ? "text-emerald-400" : "text-fg-dim"}>{r.state}</span>
            {r.kill ? (
              <button onClick={r.kill} className="grid h-6 w-6 place-items-center rounded-md text-fg-faint transition hover:bg-rose-500/20 hover:text-rose-400" title="Zakończ proces">
                <X size={14} />
              </button>
            ) : (
              <span />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
