import { useEffect, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import { Bluetooth, Check, Info, Monitor, Palette, Signal, User, Volume2, Wifi, Lock as LockIcon, type LucideIcon } from "lucide-react";
import type { AppProps } from "../types";
import { ACCENTS, setSettings, settings } from "../settings";
import { WALLPAPERS } from "../wallpapers";
import { Wallpaper } from "../shell/Wallpaper";
import { Slider, Toggle, LumenLogo, SectionTitle } from "../ui";
import { fsBytes, formatBytes, useNodes } from "../fs";
import { askConfirm } from "../overlayStore";
import { lock, sys } from "../system";
import { cn } from "../../utils/cn";

type Section = "appearance" | "display" | "network" | "account" | "about";

const SECTIONS: { id: Section; label: string; icon: LucideIcon; color: string }[] = [
  { id: "appearance", label: "Wygląd", icon: Palette, color: "#8b5cf6" },
  { id: "display", label: "Ekran i dźwięk", icon: Monitor, color: "#3b82f6" },
  { id: "network", label: "Sieć", icon: Wifi, color: "#06b6d4" },
  { id: "account", label: "Konto", icon: User, color: "#f59e0b" },
  { id: "about", label: "O systemie", icon: Info, color: "#64748b" },
];

function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("rounded-2xl bg-surface p-4 ring-1 ring-glass-border", className)}>{children}</div>;
}

function Row({ title, desc, children }: { title: string; desc?: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2.5">
      <div className="min-w-0">
        <div className="text-[13px] font-medium">{title}</div>
        {desc && <div className="text-xs text-fg-dim">{desc}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function ThemeCard({ mode, active }: { mode: "dark" | "light"; active: boolean }) {
  const dark = mode === "dark";
  return (
    <button onClick={() => setSettings({ theme: mode })} className="group text-center">
      <div
        className={cn(
          "relative h-24 w-40 overflow-hidden rounded-xl ring-2 transition-all",
          active ? "ring-accent" : "ring-transparent group-hover:ring-surface-3"
        )}
        style={{ background: dark ? "#16132a" : "#e9e7f5" }}
      >
        <div className="absolute left-3 top-3 h-14 w-24 rounded-lg" style={{ background: dark ? "rgba(255,255,255,.1)" : "#fff" }}>
          <div className="m-2 flex gap-1">
            {["#ff5f57", "#febc2e", "#28c840"].map((c) => (
              <span key={c} className="h-1.5 w-1.5 rounded-full" style={{ background: c }} />
            ))}
          </div>
          <div className="mx-2 h-1.5 w-12 rounded-full bg-accent" />
          <div className="mx-2 mt-1.5 h-1.5 w-16 rounded-full" style={{ background: dark ? "rgba(255,255,255,.2)" : "#d4d4e8" }} />
        </div>
        <div className="absolute bottom-1.5 left-1/2 h-2.5 w-20 -translate-x-1/2 rounded-full" style={{ background: dark ? "rgba(255,255,255,.18)" : "rgba(0,0,0,.12)" }} />
        {active && (
          <span className="absolute right-1.5 top-1.5 grid h-5 w-5 place-items-center rounded-full bg-accent text-white">
            <Check size={12} />
          </span>
        )}
      </div>
      <div className="mt-1.5 text-xs font-medium">{dark ? "Ciemny" : "Jasny"}</div>
    </button>
  );
}

function Appearance() {
  const s = settings.use((x) => x);
  return (
    <div className="space-y-6">
      <div>
        <SectionTitle>Motyw</SectionTitle>
        <div className="flex gap-4">
          <ThemeCard mode="dark" active={s.theme === "dark"} />
          <ThemeCard mode="light" active={s.theme === "light"} />
        </div>
      </div>
      <div>
        <SectionTitle>Kolor akcentu</SectionTitle>
        <Card className="flex flex-wrap gap-4">
          {ACCENTS.map((a) => (
            <button key={a.color} onClick={() => setSettings({ accent: a.color })} className="flex flex-col items-center gap-1.5">
              <span className="relative grid h-9 w-9 place-items-center rounded-full transition-transform hover:scale-110 active:scale-90" style={{ background: a.color }}>
                {s.accent === a.color && (
                  <motion.span layoutId="accent-ring" className="absolute -inset-1 rounded-full border-2" style={{ borderColor: a.color }} />
                )}
                {s.accent === a.color && <Check size={16} className="text-white" />}
              </span>
              <span className="text-[11px] text-fg-dim">{a.name}</span>
            </button>
          ))}
        </Card>
      </div>
      <div>
        <SectionTitle>Tapeta</SectionTitle>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {WALLPAPERS.map((w) => (
            <button key={w.id} onClick={() => setSettings({ wallpaper: w.id })} className="group text-left">
              <div
                className={cn(
                  "relative aspect-video overflow-hidden rounded-xl ring-2 transition-all duration-300 group-hover:scale-[1.03]",
                  s.wallpaper === w.id ? "ring-accent" : "ring-transparent"
                )}
              >
                <Wallpaper id={w.id} still blur={14} vignette={false} />
                {s.wallpaper === w.id && (
                  <span className="absolute right-1.5 top-1.5 grid h-5 w-5 place-items-center rounded-full bg-accent text-white">
                    <Check size={12} />
                  </span>
                )}
              </div>
              <div className="mt-1.5 text-xs font-medium">{w.name}</div>
            </button>
          ))}
        </div>
      </div>
      <div>
        <SectionTitle>Dock</SectionTitle>
        <Card>
          <Row title="Powiększanie ikon" desc="Płynne powiększanie ikon po najechaniu kursorem">
            <Toggle checked={s.magnify} onChange={(v) => setSettings({ magnify: v })} />
          </Row>
        </Card>
      </div>
    </div>
  );
}

function Display() {
  const s = settings.use((x) => x);
  return (
    <div className="space-y-6">
      <Card>
        <Row title="Jasność" desc={`${s.brightness}%`}>
          <div className="w-52"><Slider value={s.brightness} min={25} onChange={(v) => setSettings({ brightness: v })} /></div>
        </Row>
        <div className="h-px bg-glass-border" />
        <Row title="Głośność systemu" desc={`${s.volume}%`}>
          <div className="flex w-52 items-center gap-2">
            <Volume2 size={15} className="text-fg-dim" />
            <Slider value={s.volume} onChange={(v) => setSettings({ volume: v })} />
          </div>
        </Row>
        <div className="h-px bg-glass-border" />
        <Row title="Nie przeszkadzaj" desc="Powiadomienia trafiają tylko do centrum powiadomień">
          <Toggle checked={s.dnd} onChange={(v) => setSettings({ dnd: v })} />
        </Row>
      </Card>
    </div>
  );
}

const NETWORKS = [
  { name: "Lumen-5G", bars: 4, secure: true },
  { name: "Kawiarnia_Free", bars: 3, secure: false },
  { name: "Orange_8841", bars: 2, secure: true },
  { name: "Dom-2.4G", bars: 1, secure: true },
];

function Network() {
  const s = settings.use((x) => x);
  return (
    <div className="space-y-6">
      <Card>
        <Row title="Wi‑Fi" desc={s.wifi ? "Połączono z Lumen-5G" : "Wyłączone"}>
          <Toggle checked={s.wifi} onChange={(v) => setSettings({ wifi: v })} />
        </Row>
      </Card>
      {s.wifi && (
        <div>
          <SectionTitle>Dostępne sieci</SectionTitle>
          <Card className="!p-1.5">
            {NETWORKS.map((n, i) => (
              <div key={n.name} className="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-surface-2">
                <Signal size={16} className={i === 0 ? "text-accent" : "text-fg-dim"} />
                <span className="flex-1 text-[13px] font-medium">{n.name}</span>
                {n.secure && <LockIcon size={13} className="text-fg-faint" />}
                <span className="flex items-end gap-0.5">
                  {[1, 2, 3, 4].map((b) => (
                    <span key={b} className={cn("w-1 rounded-sm", b <= n.bars ? "bg-fg" : "bg-surface-3")} style={{ height: 4 + b * 3 }} />
                  ))}
                </span>
                {i === 0 && <Check size={15} className="text-accent" />}
              </div>
            ))}
          </Card>
        </div>
      )}
      <Card>
        <Row title="Bluetooth" desc={s.bluetooth ? "Wykrywalny jako „Lumen”" : "Wyłączony"}>
          <div className="flex items-center gap-3">
            <Bluetooth size={16} className={s.bluetooth ? "text-accent" : "text-fg-faint"} />
            <Toggle checked={s.bluetooth} onChange={(v) => setSettings({ bluetooth: v })} />
          </div>
        </Row>
      </Card>
    </div>
  );
}

function Account() {
  const name = settings.use((s) => s.userName);
  return (
    <div className="space-y-6">
      <Card className="flex items-center gap-5">
        <div className="grid h-20 w-20 shrink-0 place-items-center rounded-full bg-accent-grad text-3xl font-semibold text-white shadow-lg">
          {name.charAt(0).toUpperCase()}
        </div>
        <div className="flex-1">
          <div className="mb-1 text-xs text-fg-dim">Nazwa użytkownika</div>
          <input
            value={name}
            maxLength={24}
            onChange={(e) => setSettings({ userName: e.target.value || "Użytkownik" })}
            className="w-full rounded-xl border border-glass-border bg-surface-2 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-accent"
          />
        </div>
      </Card>
      <Card>
        <Row title="Zablokuj ekran" desc="Wróć do ekranu logowania">
          <button onClick={lock} className="rounded-xl bg-surface-3 px-4 py-1.5 text-[13px] font-medium transition hover:brightness-125">
            Zablokuj
          </button>
        </Row>
      </Card>
    </div>
  );
}

function fmtUptime(ms: number) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h > 0 ? h + " godz. " : ""}${m} min ${s % 60} s`;
}

function About() {
  const nodes = useNodes();
  const [, tick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => tick((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, []);
  const nav = navigator as Navigator & { deviceMemory?: number };
  const rows: [string, string][] = [
    ["System", "Lumen OS 1.0 „Aurora”"],
    ["Silnik", /Firefox/.test(nav.userAgent) ? "Gecko" : /Safari/.test(nav.userAgent) && !/Chrome/.test(nav.userAgent) ? "WebKit" : "Blink"],
    ["Rozdzielczość", `${window.innerWidth} × ${window.innerHeight}`],
    ["Rdzenie CPU", String(nav.hardwareConcurrency ?? "—")],
    ["Pamięć RAM", nav.deviceMemory ? `${nav.deviceMemory} GB` : "—"],
    ["Wirtualny dysk", formatBytes(fsBytes(nodes))],
    ["Czas działania", fmtUptime(Date.now() - sys.get().bootedAt)],
  ];
  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center py-4 text-center">
        <LumenLogo size={92} spin />
        <div className="mt-5 text-3xl font-light tracking-[0.3em]">LUMEN</div>
        <div className="mt-1 text-sm text-fg-dim">Wersja 1.0 „Aurora”</div>
      </div>
      <Card className="!py-1">
        {rows.map(([k, v], i) => (
          <div key={k} className={cn("flex justify-between py-2.5 text-[13px]", i > 0 && "border-t border-glass-border")}>
            <span className="text-fg-dim">{k}</span>
            <span className="font-medium">{v}</span>
          </div>
        ))}
      </Card>
      <Card>
        <Row title="Przywróć ustawienia fabryczne" desc="Usuwa pliki, notatki, wydarzenia i ustawienia">
          <button
            onClick={async () => {
              if (await askConfirm("Zresetować system?", "Wszystkie Twoje dane zostaną usunięte, a system uruchomi się ponownie.", "Zresetuj", true)) {
                Object.keys(localStorage)
                  .filter((k) => k.startsWith("lumen."))
                  .forEach((k) => localStorage.removeItem(k));
                window.location.reload();
              }
            }}
            className="rounded-xl bg-rose-500/20 px-4 py-1.5 text-[13px] font-medium text-rose-400 transition hover:bg-rose-500/30"
          >
            Zresetuj
          </button>
        </Row>
      </Card>
    </div>
  );
}

export function SettingsApp({ props }: AppProps) {
  const [section, setSection] = useState<Section>((props.section as Section) ?? "appearance");
  useEffect(() => {
    if (props.section) setSection(props.section as Section);
  }, [props.section]);
  const title = SECTIONS.find((s) => s.id === section)?.label;

  return (
    <div className="flex h-full w-full">
      <aside className="w-52 shrink-0 space-y-0.5 border-r border-glass-border bg-surface p-2.5">
        {SECTIONS.map((s) => (
          <button
            key={s.id}
            onClick={() => setSection(s.id)}
            className={cn(
              "flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-[13px] transition-colors",
              section === s.id ? "bg-surface-3 font-medium" : "hover:bg-surface-2"
            )}
          >
            <span className="grid h-7 w-7 place-items-center rounded-lg text-white shadow" style={{ background: s.color }}>
              <s.icon size={15} />
            </span>
            {s.label}
          </button>
        ))}
      </aside>
      <div className="min-w-0 flex-1 overflow-y-auto p-6">
        <h2 className="mb-5 text-2xl font-semibold tracking-tight">{title}</h2>
        <motion.div key={section} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }}>
          {section === "appearance" && <Appearance />}
          {section === "display" && <Display />}
          {section === "network" && <Network />}
          {section === "account" && <Account />}
          {section === "about" && <About />}
        </motion.div>
      </div>
    </div>
  );
}
