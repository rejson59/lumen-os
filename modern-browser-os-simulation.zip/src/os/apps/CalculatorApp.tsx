import { useEffect, useState } from "react";
import { Delete } from "lucide-react";
import type { AppProps } from "../types";
import { cn } from "../../utils/cn";

type Op = "+" | "−" | "×" | "÷";

const compute = (a: number, b: number, o: Op) => (o === "+" ? a + b : o === "−" ? a - b : o === "×" ? a * b : b === 0 ? NaN : a / b);
const fmt = (n: number) => (Number.isFinite(n) ? String(parseFloat(n.toPrecision(12))) : "Błąd");
const show = (s: string) => {
  if (s === "Błąd") return s;
  const [i, d] = s.split(".");
  const neg = i.startsWith("-");
  const int = (neg ? i.slice(1) : i).replace(/\B(?=(\d{3})+(?!\d))/g, "\u202f");
  return (neg ? "-" : "") + int + (d !== undefined ? "," + d : "");
};

export function CalculatorApp({ active }: AppProps) {
  const [cur, setCur] = useState("0");
  const [acc, setAcc] = useState<number | null>(null);
  const [op, setOp] = useState<Op | null>(null);
  const [fresh, setFresh] = useState(true);
  const [expr, setExpr] = useState("");

  const digit = (d: string) => {
    if (cur === "Błąd") return reset(d === "." ? "0." : d);
    if (fresh) {
      setCur(d === "." ? "0." : d);
      setFresh(false);
      return;
    }
    if (d === "." && cur.includes(".")) return;
    if (cur.replace(/[-.]/g, "").length >= 12) return;
    setCur(cur === "0" && d !== "." ? d : cur + d);
  };
  const reset = (v = "0") => {
    setCur(v);
    setAcc(null);
    setOp(null);
    setFresh(v === "0");
    setExpr("");
  };
  const operate = (o: Op) => {
    if (cur === "Błąd") return;
    const v = parseFloat(cur);
    if (acc !== null && op && !fresh) {
      const r = compute(acc, v, op);
      setAcc(r);
      setCur(fmt(r));
      setExpr(`${fmt(r)} ${o}`);
    } else {
      setAcc(v);
      setExpr(`${fmt(v)} ${o}`);
    }
    setOp(o);
    setFresh(true);
  };
  const equals = () => {
    if (acc === null || !op || cur === "Błąd") return;
    const v = parseFloat(cur);
    const r = compute(acc, v, op);
    setExpr(`${fmt(acc)} ${op} ${fmt(v)} =`);
    setCur(fmt(r));
    setAcc(null);
    setOp(null);
    setFresh(true);
  };
  const negate = () => cur !== "0" && cur !== "Błąd" && setCur(cur.startsWith("-") ? cur.slice(1) : "-" + cur);
  const percent = () => cur !== "Błąd" && setCur(fmt(parseFloat(cur) / 100));
  const back = () => {
    if (fresh || cur === "Błąd") return;
    setCur(cur.length <= 1 || (cur.length === 2 && cur.startsWith("-")) ? "0" : cur.slice(0, -1));
  };

  useEffect(() => {
    if (!active) return;
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === "INPUT") return;
      if (/^[0-9]$/.test(e.key)) digit(e.key);
      else if (e.key === "." || e.key === ",") digit(".");
      else if (e.key === "+") operate("+");
      else if (e.key === "-") operate("−");
      else if (e.key === "*") operate("×");
      else if (e.key === "/") {
        e.preventDefault();
        operate("÷");
      } else if (e.key === "Enter" || e.key === "=") equals();
      else if (e.key === "Backspace") back();
      else if (e.key === "Escape") reset();
      else if (e.key === "%") percent();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  const text = show(cur);
  const size = text.length > 12 ? "text-3xl" : text.length > 9 ? "text-4xl" : text.length > 7 ? "text-5xl" : "text-6xl";

  const base = "grid place-items-center rounded-2xl text-xl font-medium transition-all duration-150 active:scale-90 select-none";
  const num = cn(base, "bg-surface-2 hover:bg-surface-3");
  const fn = cn(base, "bg-surface-3 hover:brightness-125");
  const oper = (o: Op) =>
    cn(base, "text-2xl text-white shadow-lg hover:brightness-110", op === o && fresh ? "bg-white !text-[var(--accent)]" : "bg-accent-grad");

  return (
    <div className="flex h-full w-full flex-col p-3">
      <div className="flex min-h-[110px] flex-1 flex-col items-end justify-end px-3 pb-2">
        <div className="h-5 text-sm text-fg-dim">{expr.replace(/\./g, ",")}</div>
        <div className={cn("w-full truncate text-right font-extralight tabular-nums tracking-tight transition-all", size)}>{text}</div>
      </div>
      <div className="grid flex-[2.4] grid-cols-4 grid-rows-5 gap-2">
        <button className={fn} onClick={() => (cur === "0" && acc === null ? reset() : reset())}>{cur === "0" && acc === null ? "AC" : "C"}</button>
        <button className={fn} onClick={negate}>±</button>
        <button className={fn} onClick={percent}>%</button>
        <button className={oper("÷")} onClick={() => operate("÷")}>÷</button>
        {["7", "8", "9"].map((d) => (
          <button key={d} className={num} onClick={() => digit(d)}>{d}</button>
        ))}
        <button className={oper("×")} onClick={() => operate("×")}>×</button>
        {["4", "5", "6"].map((d) => (
          <button key={d} className={num} onClick={() => digit(d)}>{d}</button>
        ))}
        <button className={oper("−")} onClick={() => operate("−")}>−</button>
        {["1", "2", "3"].map((d) => (
          <button key={d} className={num} onClick={() => digit(d)}>{d}</button>
        ))}
        <button className={oper("+")} onClick={() => operate("+")}>+</button>
        <button className={cn(num, "")} onClick={back} aria-label="Usuń"><Delete size={20} /></button>
        <button className={num} onClick={() => digit("0")}>0</button>
        <button className={num} onClick={() => digit(".")}>,</button>
        <button className={cn(base, "bg-gradient-to-br from-amber-400 to-orange-500 text-2xl text-white shadow-lg hover:brightness-110")} onClick={equals}>=</button>
      </div>
    </div>
  );
}
