import { useEffect, useRef, useState, type ReactNode } from "react";
import type { AppProps } from "../types";
import { APP_LIST, APP_META, type AppId } from "../appMeta";
import {
  ROOT,
  childrenOf,
  createNode,
  deleteNode,
  fsStore,
  inferKind,
  pathString,
  renameNode,
  resolvePath,
  trashNode,
  writeNode,
} from "../fs";
import { settings, setSettings, ACCENTS } from "../settings";
import { WALLPAPERS } from "../wallpapers";
import { closeWindow, lock, notify, openApp, restart, shutdown, sys } from "../system";
import { openNode } from "../fileActions";

interface Line {
  id: number;
  content: ReactNode;
}

const COMMANDS = [
  "help", "clear", "ls", "cd", "pwd", "cat", "mkdir", "touch", "rm", "mv", "echo", "date", "whoami", "uname",
  "neofetch", "open", "apps", "ps", "kill", "theme", "accent", "wallpaper", "notify", "history", "matrix",
  "lock", "reboot", "shutdown", "cowsay", "lolcat", "calc", "fortune", "sudo",
];

const FORTUNES = [
  "Najlepszy czas na zasadzenie drzewa był 20 lat temu. Drugi najlepszy jest teraz.",
  "Kod jest poezją, tylko z większą liczbą nawiasów.",
  "Zawsze jest jeszcze jeden bug.",
  "Prostota jest szczytem wyrafinowania.",
  "Dziś jest dobry dzień na refaktoryzację.",
  "Kolory są uśmiechem natury.",
];

function tokenize(s: string): string[] {
  return [...s.matchAll(/"([^"]*)"|'([^']*)'|(\S+)/g)].map((m) => m[1] ?? m[2] ?? m[3]);
}

function MatrixRain() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!;
    const ctx = c.getContext("2d")!;
    let raf = 0;
    let drops: number[] = [];
    const size = 16;
    const resize = () => {
      c.width = c.clientWidth;
      c.height = c.clientHeight;
      drops = Array.from({ length: Math.ceil(c.width / size) }, () => Math.random() * -50);
    };
    resize();
    const chars = "アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789ABCDEF";
    let last = 0;
    const draw = (t: number) => {
      raf = requestAnimationFrame(draw);
      if (t - last < 50) return;
      last = t;
      ctx.fillStyle = "rgba(0,0,0,0.12)";
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = "#34d399";
      ctx.font = `${size}px monospace`;
      drops.forEach((y, i) => {
        ctx.fillText(chars[Math.floor(Math.random() * chars.length)], i * size, y * size);
        drops[i] = y * size > c.height && Math.random() > 0.975 ? 0 : y + 1;
      });
    };
    raf = requestAnimationFrame(draw);
    window.addEventListener("resize", resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);
  return <canvas ref={ref} className="absolute inset-0 h-full w-full opacity-40" />;
}

const LOGO = [
  ["#a78bfa", "      .-\"\"\"\"\"-.      "],
  ["#818cf8", "    .'  .---.  '.    "],
  ["#38bdf8", "   /   /     \\   \\   "],
  ["#2dd4bf", "   |   |     |   |   "],
  ["#fbbf24", "   \\   \\     /   /   "],
  ["#fb7185", "    '.  '---'  .'    "],
  ["#f472b6", "      '-.....-'      "],
];

export function TerminalApp({ winId }: AppProps) {
  const userName = settings.use((s) => s.userName);
  const user =
    userName.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ł/g, "l").replace(/[^a-z0-9]/g, "") || "user";

  const nextId = useRef(1);
  const mk = (content: ReactNode): Line => ({ id: nextId.current++, content });
  const [lines, setLines] = useState<Line[]>(() => [
    { id: 0, content: <span className="text-fg-faint">Lumen Terminal 1.0 — wpisz <b className="text-emerald-400">help</b>, aby zobaczyć polecenia.</span> },
  ]);
  const [input, setInput] = useState("");
  const [cwd, setCwd] = useState(ROOT);
  const [hist, setHist] = useState<string[]>([]);
  const [hi, setHi] = useState(-1);
  const [matrix, setMatrix] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [lines]);

  const promptEl = (dir: string) => (
    <span>
      <span className="font-bold text-emerald-400">{user}@lumen</span>
      <span className="text-zinc-400">:</span>
      <span className="font-bold text-sky-400">{dir}</span>
      <span className="text-zinc-400">$ </span>
    </span>
  );

  const exec = (raw: string): ReactNode[] | "clear" => {
    const nodes = fsStore.get().nodes;
    const args = tokenize(raw);
    const cmd = (args.shift() ?? "").toLowerCase();
    const out: ReactNode[] = [];
    const say = (t: ReactNode) => out.push(t);
    const err = (t: string) => out.push(<span className="text-rose-400">{t}</span>);
    const find = (p: string) => resolvePath(nodes, cwd, p);

    switch (cmd) {
      case "":
        break;
      case "help":
        say(<span className="text-amber-300">Dostępne polecenia:</span>);
        [
          ["ls [-l] [ścieżka]", "wyświetl zawartość folderu"],
          ["cd <ścieżka>", "zmień katalog"],
          ["pwd", "bieżąca ścieżka"],
          ["cat <plik>", "pokaż zawartość pliku"],
          ["mkdir <nazwa>", "utwórz folder"],
          ["touch <nazwa>", "utwórz pusty plik"],
          ["rm [-f] <nazwa>", "do kosza (-f usuwa na stałe)"],
          ["mv <stara> <nowa>", "zmień nazwę"],
          ["echo <tekst> [> plik]", "wypisz tekst lub zapisz do pliku"],
          ["open <aplikacja|plik>", "uruchom aplikację lub otwórz plik"],
          ["apps · ps · kill <id>", "aplikacje i procesy"],
          ["theme dark|light", "zmień motyw"],
          ["accent <nazwa|#hex>", "zmień kolor akcentu"],
          ["wallpaper <nazwa>", "zmień tapetę"],
          ["notify <tekst>", "wyślij powiadomienie"],
          ["neofetch · date · whoami · uname", "informacje o systemie"],
          ["calc <wyrażenie>", "kalkulator"],
          ["matrix · cowsay · lolcat · fortune", "zabawy"],
          ["lock · reboot · shutdown", "zarządzanie sesją"],
        ].forEach(([c, d]) =>
          say(
            <div className="flex gap-3">
              <span className="w-[230px] shrink-0 text-emerald-300">{c}</span>
              <span className="text-zinc-400">{d}</span>
            </div>
          )
        );
        break;
      case "clear":
        return "clear";
      case "pwd":
        say(pathString(nodes, cwd));
        break;
      case "ls": {
        const long = args.includes("-l");
        const target = args.find((a) => !a.startsWith("-"));
        const id = target ? find(target) : cwd;
        if (!id || !nodes[id]) return [<span className="text-rose-400">ls: nie znaleziono „{target}”</span>];
        if (nodes[id].kind !== "folder") return [nodes[id].name];
        const items = childrenOf(nodes, id);
        if (items.length === 0) break;
        const col = (n: (typeof items)[number]) =>
          n.kind === "folder" ? "text-sky-400 font-bold" : n.kind === "image" ? "text-fuchsia-400" : "text-zinc-100";
        if (long)
          items.forEach((n) =>
            say(
              <div className="flex gap-4">
                <span className="w-16 text-zinc-500">{n.kind === "folder" ? "drwxr-xr-x" : "-rw-r--r--"}</span>
                <span className="w-16 text-right text-zinc-400">{n.kind === "folder" ? "—" : (n.content?.length ?? 0) + " B"}</span>
                <span className={col(n)}>{n.name}</span>
              </div>
            )
          );
        else
          say(
            <div className="flex flex-wrap gap-x-5 gap-y-0.5">
              {items.map((n) => (
                <span key={n.id} className={col(n)}>{n.name}</span>
              ))}
            </div>
          );
        break;
      }
      case "cd": {
        if (!args[0]) {
          setCwd(ROOT);
          break;
        }
        const id = find(args[0]);
        if (!id || !nodes[id]) err(`cd: nie ma takiego katalogu: ${args[0]}`);
        else if (nodes[id].kind !== "folder") err(`cd: to nie jest katalog: ${args[0]}`);
        else setCwd(id);
        break;
      }
      case "cat": {
        if (!args[0]) return [<span className="text-rose-400">cat: podaj nazwę pliku</span>];
        const id = find(args[0]);
        const n = id ? nodes[id] : null;
        if (!n) err(`cat: ${args[0]}: nie znaleziono pliku`);
        else if (n.kind === "folder") err(`cat: ${args[0]}: to jest katalog`);
        else if (n.kind === "image") say(<span className="text-fuchsia-400">[plik graficzny — użyj: open {n.name}]</span>);
        else say(<span className="selectable whitespace-pre-wrap">{n.content || ""}</span>);
        break;
      }
      case "mkdir":
        if (!args[0]) err("mkdir: podaj nazwę");
        else args.forEach((a) => createNode(cwd, a, "folder"));
        break;
      case "touch":
        if (!args[0]) err("touch: podaj nazwę");
        else args.forEach((a) => createNode(cwd, a, inferKind(a) === "image" ? "text" : "text", ""));
        break;
      case "rm": {
        const force = args.includes("-f") || args.includes("-rf");
        const names = args.filter((a) => !a.startsWith("-"));
        if (!names.length) err("rm: podaj nazwę");
        names.forEach((a) => {
          const id = find(a);
          if (!id || !nodes[id] || id === ROOT) return err(`rm: ${a}: nie znaleziono`);
          if (["desktop", "docs", "pics", "music", "downloads", "trash"].includes(id)) return err(`rm: ${a}: katalog systemowy`);
          force ? deleteNode(id) : trashNode(id);
        });
        break;
      }
      case "mv": {
        if (args.length < 2) {
          err("mv: użycie: mv <stara> <nowa>");
          break;
        }
        const id = find(args[0]);
        if (!id || !nodes[id]) err(`mv: ${args[0]}: nie znaleziono`);
        else renameNode(id, args[1]);
        break;
      }
      case "echo": {
        const gt = args.indexOf(">");
        if (gt >= 0 && args[gt + 1]) {
          const text = args.slice(0, gt).join(" ");
          const id = find(args[gt + 1]);
          if (id && nodes[id]?.kind === "text") writeNode(id, text);
          else if (!id) createNode(cwd, args[gt + 1], "text", text);
          else err("echo: nie można zapisać do tego pliku");
        } else say(args.join(" "));
        break;
      }
      case "date":
        say(new Date().toLocaleString("pl-PL", { dateStyle: "full", timeStyle: "medium" }));
        break;
      case "whoami":
        say(user);
        break;
      case "uname":
        say("Lumen 1.0-aurora web-kernel (JS) x86_64 przeglądarka");
        break;
      case "neofetch": {
        const s = settings.get();
        const info: [string, string][] = [
          ["OS", "Lumen OS 1.0 „Aurora”"],
          ["Host", "Przeglądarka internetowa"],
          ["Jądro", "JavaScript (V8/SpiderMonkey/JSC)"],
          ["Czas pracy", `${Math.floor((Date.now() - sys.get().bootedAt) / 60000)} min`],
          ["Powłoka", "lsh 1.0"],
          ["Ekran", `${window.innerWidth}×${window.innerHeight}`],
          ["Motyw", s.theme === "dark" ? "Ciemny" : "Jasny"],
          ["Okna", String(sys.get().windows.length)],
          ["CPU", `${navigator.hardwareConcurrency ?? "?"} rdzeni`],
        ];
        say(
          <div className="my-1 flex gap-4">
            <pre className="leading-[1.15]">
              {LOGO.map(([c, t], i) => (
                <div key={i} style={{ color: c }}>{t}</div>
              ))}
            </pre>
            <div className="leading-[1.35]">
              <div>
                <b className="text-emerald-400">{user}</b>@<b className="text-emerald-400">lumen</b>
              </div>
              <div className="text-zinc-500">────────────────</div>
              {info.map(([k, v]) => (
                <div key={k}>
                  <b className="text-violet-400">{k}</b>: {v}
                </div>
              ))}
              <div className="mt-1 flex gap-1">
                {["#a78bfa", "#38bdf8", "#34d399", "#fbbf24", "#fb7185", "#f472b6"].map((c) => (
                  <span key={c} className="h-3 w-5 rounded-sm" style={{ background: c }} />
                ))}
              </div>
            </div>
          </div>
        );
        break;
      }
      case "apps":
        say(
          <div className="flex flex-wrap gap-x-5">
            {APP_LIST.map((a) => (
              <span key={a.id}>
                <span className="text-emerald-300">{a.id}</span> <span className="text-zinc-500">({a.name})</span>
              </span>
            ))}
          </div>
        );
        break;
      case "open": {
        const q = args.join(" ").toLowerCase();
        if (!q) {
          err("open: podaj aplikację lub plik (np. open music)");
          break;
        }
        const app = APP_LIST.find((a) => a.id === q || a.name.toLowerCase() === q);
        if (app) {
          openApp(app.id);
          say(<span className="text-zinc-400">Uruchamianie: {app.name}…</span>);
          break;
        }
        const id = find(args.join(" "));
        if (id && nodes[id]) {
          openNode(nodes[id]);
          say(<span className="text-zinc-400">Otwieranie: {nodes[id].name}…</span>);
        } else err(`open: nie znaleziono „${args.join(" ")}”`);
        break;
      }
      case "ps":
        say(<span className="text-zinc-500">  PID   APLIKACJA</span>);
        if (!sys.get().windows.length) say("  (brak uruchomionych okien)");
        sys.get().windows.forEach((w) =>
          say(
            <div>
              <span className="inline-block w-[60px] text-amber-300">{w.id}</span>
              {APP_META[w.appId].name} {w.minimized && <span className="text-zinc-500">[zminimalizowane]</span>}
            </div>
          )
        );
        break;
      case "kill": {
        if (!args[0]) {
          err("kill: podaj PID (np. kill w3) lub id aplikacji");
          break;
        }
        const ws = sys.get().windows.filter((w) => w.id === args[0] || w.appId === (args[0] as AppId));
        if (!ws.length) err(`kill: ${args[0]}: nie znaleziono procesu`);
        else ws.forEach((w) => (w.id === winId ? err("kill: nie można zakończyć własnego procesu — zamknij okno ręcznie") : closeWindow(w.id)));
        break;
      }
      case "theme":
        if (args[0] === "dark" || args[0] === "light") {
          setSettings({ theme: args[0] });
          say(`Motyw: ${args[0] === "dark" ? "ciemny" : "jasny"}`);
        } else err("theme: użycie: theme dark|light");
        break;
      case "accent": {
        const q = (args[0] ?? "").toLowerCase();
        const a = ACCENTS.find((x) => x.name.toLowerCase() === q);
        if (a) setSettings({ accent: a.color });
        else if (/^#[0-9a-f]{6}$/i.test(q)) setSettings({ accent: q });
        else err(`accent: dostępne: ${ACCENTS.map((x) => x.name.toLowerCase()).join(", ")} lub #rrggbb`);
        break;
      }
      case "wallpaper": {
        const q = (args[0] ?? "").toLowerCase();
        const w = WALLPAPERS.find((x) => x.id === q || x.name.toLowerCase() === q);
        if (w) setSettings({ wallpaper: w.id });
        else err(`wallpaper: dostępne: ${WALLPAPERS.map((x) => x.id).join(", ")}`);
        break;
      }
      case "notify":
        notify({ title: "Terminal", body: args.join(" ") || "Cześć!", appId: "terminal" });
        break;
      case "history":
        hist.forEach((h, i) => say(`${String(i + 1).padStart(4)}  ${h}`));
        break;
      case "matrix":
        setMatrix((m) => !m);
        say(<span className="text-emerald-400">Wake up, {userName}…</span>);
        break;
      case "lock":
        lock();
        break;
      case "reboot":
        say("Uruchamianie ponowne…");
        setTimeout(restart, 600);
        break;
      case "shutdown":
        say("Wyłączanie systemu…");
        setTimeout(shutdown, 600);
        break;
      case "cowsay": {
        const t = args.join(" ") || "Muuu!";
        say(
          <pre className="selectable">{` ${"_".repeat(t.length + 2)}\n< ${t} >\n ${"-".repeat(t.length + 2)}\n        \\   ^__^\n         \\  (oo)\\_______\n            (__)\\       )\\/\\\n                ||----w |\n                ||     ||`}</pre>
        );
        break;
      }
      case "lolcat": {
        const t = args.join(" ") || "Kolory! Kolory! Kolory!";
        say(
          <span>
            {[...t].map((ch, i) => (
              <span key={i} style={{ color: `hsl(${(i * 28) % 360} 90% 65%)` }}>{ch}</span>
            ))}
          </span>
        );
        break;
      }
      case "calc": {
        const e = args.join(" ").replace(/,/g, ".").replace(/\^/g, "**");
        if (!/^[0-9+\-*/%().\s*]+$/.test(e) || !e.trim()) err("calc: nieprawidłowe wyrażenie");
        else {
          try {
            say(String(parseFloat(Number(Function(`"use strict"; return (${e})`)()).toPrecision(12))));
          } catch {
            err("calc: błąd w wyrażeniu");
          }
        }
        break;
      }
      case "fortune":
        say(<span className="italic text-amber-200">{FORTUNES[Math.floor(Math.random() * FORTUNES.length)]}</span>);
        break;
      case "sudo":
        say("Nice try 😉 — tu wszyscy jesteśmy rootami.");
        break;
      default:
        err(`${cmd}: nie znaleziono polecenia (wpisz help)`);
    }
    return out;
  };

  const submit = () => {
    const raw = input;
    const dir = pathString(fsStore.get().nodes, cwd);
    const echo = mk(
      <div>
        {promptEl(dir)}
        <span>{raw}</span>
      </div>
    );
    const res = exec(raw.trim());
    if (raw.trim()) setHist((h) => [...h, raw.trim()]);
    setHi(-1);
    setInput("");
    if (res === "clear") setLines([]);
    else setLines((l) => [...l, echo, ...res.map((r) => mk(r))]);
  };

  const complete = () => {
    const nodes = fsStore.get().nodes;
    const parts = input.split(/\s+/);
    const last = parts[parts.length - 1];
    let cands: string[] = [];
    let base = "";
    if (parts.length === 1) cands = COMMANDS.filter((c) => c.startsWith(last.toLowerCase()));
    else {
      const slash = last.lastIndexOf("/");
      base = slash >= 0 ? last.slice(0, slash + 1) : "";
      const prefix = slash >= 0 ? last.slice(slash + 1) : last;
      const dirId = resolvePath(nodes, cwd, base || ".");
      if (dirId) {
        cands = childrenOf(nodes, dirId)
          .filter((n) => n.name.toLowerCase().startsWith(prefix.toLowerCase()))
          .map((n) => (n.name.includes(" ") ? `"${n.name}"` : n.name) + (n.kind === "folder" ? "/" : ""));
      }
    }
    if (cands.length === 1) setInput([...parts.slice(0, -1), base + cands[0]].join(" "));
    else if (cands.length > 1)
      setLines((l) => [...l, mk(<div className="flex flex-wrap gap-x-4 text-zinc-400">{cands.map((c) => <span key={c}>{c}</span>)}</div>)]);
  };

  return (
    <div
      className="relative flex h-full w-full flex-col bg-[#07060f]/70 font-mono text-[13px] leading-relaxed text-zinc-100"
      onClick={() => {
        if (!window.getSelection()?.toString()) inputRef.current?.focus();
      }}
    >
      {matrix && <MatrixRain />}
      <div ref={scrollRef} className="selectable relative flex-1 overflow-y-auto p-3.5">
        {lines.map((l) => (
          <div key={l.id} className="whitespace-pre-wrap break-words">{l.content}</div>
        ))}
        <div className="flex items-center">
          {promptEl(pathString(fsStore.get().nodes, cwd))}
          <input
            ref={inputRef}
            autoFocus
            value={input}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") submit();
              else if (e.key === "Tab") {
                e.preventDefault();
                complete();
              } else if (e.key === "ArrowUp") {
                e.preventDefault();
                const n = Math.min(hist.length - 1, hi + 1);
                if (n >= 0) {
                  setHi(n);
                  setInput(hist[hist.length - 1 - n]);
                }
              } else if (e.key === "ArrowDown") {
                e.preventDefault();
                const n = hi - 1;
                setHi(n);
                setInput(n >= 0 ? hist[hist.length - 1 - n] : "");
              } else if (e.key === "l" && e.ctrlKey) {
                e.preventDefault();
                setLines([]);
              }
            }}
            className="min-w-0 flex-1 bg-transparent font-mono text-zinc-100 caret-emerald-400 outline-none"
          />
        </div>
      </div>
    </div>
  );
}
