import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Music2, Pause, Play, SkipBack, SkipForward, Volume1, Volume2 } from "lucide-react";
import { TRACKS, getAnalyser, getAudio, isPlaying, play, setVolume, stop } from "../audio";
import { settings, setSettings } from "../settings";
import { Slider } from "../ui";
import { cn } from "../../utils/cn";

const mmss = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

function Eq({ on }: { on: boolean }) {
  return (
    <span className="flex h-4 items-end gap-[2px]">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="w-[3px] rounded-full bg-current"
          animate={on ? { height: [4, 14, 6, 12, 4] } : { height: 4 }}
          transition={on ? { duration: 0.9 + i * 0.15, repeat: Infinity, ease: "easeInOut" } : { duration: 0.2 }}
        />
      ))}
    </span>
  );
}

export function MusicApp() {
  const [ti, setTi] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const volume = settings.use((s) => s.volume);
  const track = TRACKS[ti];
  const artRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const colorsRef = useRef(track.colors);
  colorsRef.current = track.colors;

  useEffect(() => setVolume(volume), [volume]);
  useEffect(() => () => stop(), []);

  useEffect(() => {
    if (playing) play(track);
    else stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, ti]);

  const select = (i: number) => {
    getAudio();
    setTi((i + TRACKS.length) % TRACKS.length);
    setElapsed(0);
    setPlaying(true);
  };

  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setElapsed((e) => e + 0.25), 250);
    return () => clearInterval(t);
  }, [playing, ti]);

  useEffect(() => {
    if (playing && elapsed >= track.duration) select(ti + 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [elapsed]);

  // wizualizator
  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const g = c.getContext("2d")!;
    const data = new Uint8Array(64);
    let raf = 0;
    let smooth = 0;
    const draw = (t: number) => {
      raf = requestAnimationFrame(draw);
      const dpr = window.devicePixelRatio || 1;
      const w = c.clientWidth;
      const h = c.clientHeight;
      if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) {
        c.width = Math.round(w * dpr);
        c.height = Math.round(h * dpr);
      }
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, w, h);
      const an = getAnalyser();
      const live = an && isPlaying();
      if (live) an.getByteFrequencyData(data);
      const N = 36;
      const gap = 4;
      const bw = (w - gap * (N - 1)) / N;
      const grad = g.createLinearGradient(0, 0, w, 0);
      const [c0, c1, c2] = colorsRef.current;
      grad.addColorStop(0, c0);
      grad.addColorStop(0.5, c1);
      grad.addColorStop(1, c2);
      g.fillStyle = grad;
      for (let i = 0; i < N; i++) {
        const v = live ? data[Math.floor(Math.pow(i / N, 1.4) * 52) + 1] / 255 : 0.06 + 0.04 * Math.sin(t / 700 + i * 0.5);
        const bh = Math.max(4, v * h * 0.95);
        g.beginPath();
        if (g.roundRect) g.roundRect(i * (bw + gap), h - bh, bw, bh, 3);
        else g.rect(i * (bw + gap), h - bh, bw, bh);
        g.fill();
      }
      const bass = live ? (data[1] + data[2] + data[3] + data[4]) / 4 / 255 : 0;
      smooth += (bass - smooth) * 0.15;
      if (artRef.current) {
        artRef.current.style.transform = `scale(${1 + smooth * 0.07})`;
        artRef.current.style.boxShadow = `0 ${20 + smooth * 30}px ${50 + smooth * 60}px -12px ${colorsRef.current[0]}aa`;
      }
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  const [c0, c1, c2] = track.colors;
  const VolIcon = volume < 40 ? Volume1 : Volume2;

  return (
    <div className="relative flex h-full w-full overflow-hidden">
      <motion.div
        key={track.id}
        className="pointer-events-none absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.38 }}
        transition={{ duration: 1 }}
        style={{
          background: `radial-gradient(circle at 15% 15%, ${c0}, transparent 55%), radial-gradient(circle at 95% 85%, ${c1}, transparent 55%), radial-gradient(circle at 65% 5%, ${c2}, transparent 50%)`,
        }}
      />

      <div className="relative flex w-[290px] shrink-0 flex-col p-6">
        <div ref={artRef} className="relative aspect-square w-full overflow-hidden rounded-[28px] transition-shadow" style={{ background: c0 }}>
          <div
            className="spin-slow absolute -inset-1/2"
            style={{
              background: `conic-gradient(from 0deg, ${c0}, ${c1}, ${c2}, ${c0})`,
              animationPlayState: playing ? "running" : "paused",
              filter: "blur(18px)",
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-br from-white/25 to-transparent" />
          <div className="absolute inset-[22%] grid place-items-center rounded-full bg-black/25 backdrop-blur-md ring-1 ring-white/30">
            <Music2 className="text-white drop-shadow" size={44} />
          </div>
        </div>

        <div className="mt-5 min-w-0">
          <motion.div key={track.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="truncate text-xl font-semibold tracking-tight">
            {track.title}
          </motion.div>
          <div className="truncate text-sm text-fg-dim">{track.artist}</div>
        </div>

        <div className="mt-4">
          <div className="h-1.5 overflow-hidden rounded-full bg-surface-3">
            <div className="h-full rounded-full bg-accent-grad transition-[width] duration-300 ease-linear" style={{ width: `${(elapsed / track.duration) * 100}%` }} />
          </div>
          <div className="mt-1 flex justify-between text-[11px] tabular-nums text-fg-dim">
            <span>{mmss(elapsed)}</span>
            <span>{mmss(track.duration)}</span>
          </div>
        </div>

        <div className="mt-2 flex items-center justify-center gap-5">
          <button onClick={() => select(ti - 1)} className="grid h-10 w-10 place-items-center rounded-full text-fg transition hover:bg-surface-3 active:scale-90">
            <SkipBack size={20} fill="currentColor" />
          </button>
          <button
            onClick={() => {
              getAudio();
              setPlaying((p) => !p);
            }}
            className="grid h-14 w-14 place-items-center rounded-full bg-accent-grad text-white shadow-lg transition hover:brightness-110 active:scale-90"
          >
            {playing ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="translate-x-0.5" />}
          </button>
          <button onClick={() => select(ti + 1)} className="grid h-10 w-10 place-items-center rounded-full text-fg transition hover:bg-surface-3 active:scale-90">
            <SkipForward size={20} fill="currentColor" />
          </button>
        </div>

        <div className="mt-auto flex items-center gap-3 pt-4">
          <VolIcon size={16} className="text-fg-dim" />
          <Slider value={volume} onChange={(v) => setSettings({ volume: v })} />
        </div>
      </div>

      <div className="relative flex min-w-0 flex-1 flex-col border-l border-glass-border bg-surface">
        <div className="px-5 pb-2 pt-5 text-xs font-semibold uppercase tracking-wider text-fg-faint">Biblioteka · muzyka generowana na żywo</div>
        <div className="space-y-1 px-3">
          {TRACKS.map((t, i) => (
            <button
              key={t.id}
              onClick={() => (i === ti ? setPlaying((p) => !p) : select(i))}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors",
                i === ti ? "bg-surface-3" : "hover:bg-surface-2"
              )}
            >
              <span
                className="grid h-10 w-10 shrink-0 place-items-center rounded-lg text-white"
                style={{ background: `linear-gradient(135deg, ${t.colors[0]}, ${t.colors[1]})` }}
              >
                {i === ti ? <Eq on={playing} /> : <Play size={14} fill="currentColor" />}
              </span>
              <span className="min-w-0 flex-1">
                <span className={cn("block truncate text-[13px] font-medium", i === ti && "text-accent")}>{t.title}</span>
                <span className="block truncate text-xs text-fg-dim">
                  {t.artist} · {t.bpm} BPM
                </span>
              </span>
              <span className="text-xs tabular-nums text-fg-faint">{mmss(t.duration)}</span>
            </button>
          ))}
        </div>
        <div className="mt-auto h-36 px-5 pb-5">
          <canvas ref={canvasRef} className="h-full w-full" />
        </div>
      </div>
    </div>
  );
}
