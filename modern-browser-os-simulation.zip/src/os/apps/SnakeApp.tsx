import { useCallback, useEffect, useRef, useState } from "react";
import { Pause, Play, Trophy } from "lucide-react";
import type { AppProps } from "../types";

const N = 20;
type P = { x: number; y: number };
type Status = "idle" | "running" | "paused" | "over";

const BEST_KEY = "lumen.snake.best";

export function SnakeApp({ active }: AppProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [side, setSide] = useState(400);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(() => Number(localStorage.getItem(BEST_KEY) ?? 0));
  const [status, setStatus] = useState<Status>("idle");

  const g = useRef({
    snake: [{ x: 9, y: 10 }, { x: 8, y: 10 }, { x: 7, y: 10 }] as P[],
    dir: { x: 1, y: 0 },
    queue: [] as P[],
    food: { x: 14, y: 10 } as P,
    score: 0,
    status: "idle" as Status,
    acc: 0,
    last: 0,
    eatFx: 0,
  });

  const placeFood = () => {
    const s = g.current;
    for (let i = 0; i < 500; i++) {
      const f = { x: Math.floor(Math.random() * N), y: Math.floor(Math.random() * N) };
      if (!s.snake.some((p) => p.x === f.x && p.y === f.y)) {
        s.food = f;
        return;
      }
    }
  };

  const setSt = (st: Status) => {
    g.current.status = st;
    setStatus(st);
  };

  const reset = useCallback(() => {
    const s = g.current;
    s.snake = [{ x: 9, y: 10 }, { x: 8, y: 10 }, { x: 7, y: 10 }];
    s.dir = { x: 1, y: 0 };
    s.queue = [];
    s.score = 0;
    s.acc = 0;
    setScore(0);
    placeFood();
  }, []);

  const start = () => {
    if (g.current.status === "over" || g.current.status === "idle") reset();
    setSt("running");
  };

  const turn = useCallback((dx: number, dy: number) => {
    const s = g.current;
    if (s.status === "idle" || s.status === "over") {
      reset();
      setSt("running");
    }
    const ref = s.queue.length ? s.queue[s.queue.length - 1] : s.dir;
    if (ref.x === -dx && ref.y === -dy) return;
    if (ref.x === dx && ref.y === dy) return;
    if (s.queue.length < 3) s.queue.push({ x: dx, y: dy });
  }, [reset]);

  useEffect(() => {
    if (!active) return;
    const k = (e: KeyboardEvent) => {
      const map: Record<string, [number, number]> = {
        ArrowUp: [0, -1], w: [0, -1], W: [0, -1],
        ArrowDown: [0, 1], s: [0, 1], S: [0, 1],
        ArrowLeft: [-1, 0], a: [-1, 0], A: [-1, 0],
        ArrowRight: [1, 0], d: [1, 0], D: [1, 0],
      };
      if (map[e.key]) {
        e.preventDefault();
        turn(...map[e.key]);
      } else if (e.key === " ") {
        e.preventDefault();
        const st = g.current.status;
        if (st === "running") setSt("paused");
        else start();
      }
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, turn]);

  useEffect(() => {
    const el = wrapRef.current!;
    const ro = new ResizeObserver(() => setSide(Math.max(200, Math.floor(Math.min(el.clientWidth - 32, el.clientHeight - 32)))));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // pętla gry + render
  useEffect(() => {
    const c = canvasRef.current!;
    const ctx = c.getContext("2d")!;
    let raf = 0;

    const step = () => {
      const s = g.current;
      if (s.queue.length) s.dir = s.queue.shift()!;
      const head = { x: s.snake[0].x + s.dir.x, y: s.snake[0].y + s.dir.y };
      const hitWall = head.x < 0 || head.y < 0 || head.x >= N || head.y >= N;
      const ate = head.x === s.food.x && head.y === s.food.y;
      const body = ate ? s.snake : s.snake.slice(0, -1);
      if (hitWall || body.some((p) => p.x === head.x && p.y === head.y)) {
        s.status = "over";
        setStatus("over");
        setBest((b) => {
          const nb = Math.max(b, s.score);
          localStorage.setItem(BEST_KEY, String(nb));
          return nb;
        });
        return;
      }
      s.snake.unshift(head);
      if (ate) {
        s.score += 10;
        s.eatFx = 1;
        setScore(s.score);
        placeFood();
      } else s.snake.pop();
    };

    const draw = (t: number) => {
      raf = requestAnimationFrame(draw);
      const s = g.current;
      const dpr = window.devicePixelRatio || 1;
      const size = c.clientWidth;
      if (c.width !== Math.round(size * dpr)) {
        c.width = Math.round(size * dpr);
        c.height = Math.round(size * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const cell = size / N;

      if (s.status === "running") {
        const dt = s.last ? Math.min(60, t - s.last) : 0;
        s.acc += dt;
        const stepMs = Math.max(65, 135 - s.score * 0.6);
        while (s.acc >= stepMs && s.status === "running") {
          s.acc -= stepMs;
          step();
        }
      }
      s.last = t;
      s.eatFx = Math.max(0, s.eatFx - 0.05);

      // tło
      ctx.clearRect(0, 0, size, size);
      ctx.fillStyle = "#0b0919";
      ctx.fillRect(0, 0, size, size);
      for (let y = 0; y < N; y++)
        for (let x = 0; x < N; x++) {
          if ((x + y) % 2 === 0) {
            ctx.fillStyle = "rgba(255,255,255,0.025)";
            ctx.fillRect(x * cell, y * cell, cell, cell);
          }
        }

      // jedzenie
      const pulse = 0.5 + 0.5 * Math.sin(t / 220);
      const fx = s.food.x * cell + cell / 2;
      const fy = s.food.y * cell + cell / 2;
      ctx.save();
      ctx.shadowColor = "#f43f5e";
      ctx.shadowBlur = 14 + pulse * 10;
      const grd = ctx.createRadialGradient(fx - 2, fy - 2, 1, fx, fy, cell * 0.45);
      grd.addColorStop(0, "#fda4af");
      grd.addColorStop(1, "#f43f5e");
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.arc(fx, fy, cell * (0.3 + pulse * 0.06), 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // wąż
      const len = s.snake.length;
      s.snake.forEach((p, i) => {
        const hue = (175 + i * 6) % 360;
        ctx.save();
        if (i === 0) {
          ctx.shadowColor = `hsl(${hue} 90% 60%)`;
          ctx.shadowBlur = 12 + s.eatFx * 20;
        }
        ctx.fillStyle = `hsl(${hue} 85% ${i === 0 ? 62 : 56 - Math.min(14, (i / len) * 14)}%)`;
        const pad = i === 0 ? 1 : 1.8;
        ctx.beginPath();
        ctx.roundRect(p.x * cell + pad, p.y * cell + pad, cell - pad * 2, cell - pad * 2, cell * 0.3);
        ctx.fill();
        ctx.restore();
      });
      // oczy
      const h = s.snake[0];
      ctx.fillStyle = "#0b0919";
      const ex = s.dir.x,
        ey = s.dir.y;
      [-1, 1].forEach((side) => {
        const ox = h.x * cell + cell / 2 + ex * cell * 0.18 + (ey !== 0 ? side * cell * 0.2 : 0);
        const oy = h.y * cell + cell / 2 + ey * cell * 0.18 + (ex !== 0 ? side * cell * 0.2 : 0);
        ctx.beginPath();
        ctx.arc(ox, oy, cell * 0.08, 0, Math.PI * 2);
        ctx.fill();
      });
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  // gest przeciągnięcia (dotyk)
  const touch = useRef<P | null>(null);

  return (
    <div className="flex h-full w-full flex-col">
      <div className="flex items-center justify-between px-5 pt-3">
        <div className="flex gap-6">
          <div>
            <div className="text-[10px] font-semibold uppercase tracking-wider text-fg-faint">Wynik</div>
            <div className="text-2xl font-semibold tabular-nums">{score}</div>
          </div>
          <div>
            <div className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider text-fg-faint">
              <Trophy size={10} /> Rekord
            </div>
            <div className="text-2xl font-semibold tabular-nums text-amber-400">{best}</div>
          </div>
        </div>
        <button
          onClick={() => (status === "running" ? setSt("paused") : start())}
          className="flex items-center gap-1.5 rounded-xl bg-accent-grad px-4 py-2 text-xs font-medium text-white shadow transition hover:brightness-110 active:scale-95"
        >
          {status === "running" ? <><Pause size={13} fill="currentColor" /> Pauza</> : <><Play size={13} fill="currentColor" /> {status === "over" ? "Jeszcze raz" : status === "paused" ? "Wznów" : "Start"}</>}
        </button>
      </div>
      <div ref={wrapRef} className="grid min-h-0 flex-1 place-items-center p-4">
        <div className="relative" style={{ width: side, height: side }}>
          <canvas
            ref={canvasRef}
            className="h-full w-full touch-none rounded-2xl shadow-[0_20px_60px_-10px_rgba(0,0,0,.6)] ring-1 ring-white/15"
            onPointerDown={(e) => {
              touch.current = { x: e.clientX, y: e.clientY };
              if (g.current.status !== "running") start();
            }}
            onPointerMove={(e) => {
              if (!touch.current) return;
              const dx = e.clientX - touch.current.x;
              const dy = e.clientY - touch.current.y;
              if (Math.abs(dx) > 24 || Math.abs(dy) > 24) {
                if (Math.abs(dx) > Math.abs(dy)) turn(dx > 0 ? 1 : -1, 0);
                else turn(0, dy > 0 ? 1 : -1);
                touch.current = { x: e.clientX, y: e.clientY };
              }
            }}
            onPointerUp={() => (touch.current = null)}
          />
          {status !== "running" && (
            <div className="pointer-events-none absolute inset-0 grid place-items-center rounded-2xl bg-black/45 backdrop-blur-[2px]">
              <div className="text-center text-white">
                <div className="text-2xl font-semibold">
                  {status === "over" ? "Koniec gry" : status === "paused" ? "Pauza" : "Wąż"}
                </div>
                <div className="mt-1 text-sm text-white/70">
                  {status === "over" ? `Twój wynik: ${score}` : "Strzałki / WASD · Spacja — start i pauza"}
                </div>
                <div className="mt-3 text-xs text-white/50">Kliknij, aby {status === "paused" ? "wznowić" : "zagrać"}</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
