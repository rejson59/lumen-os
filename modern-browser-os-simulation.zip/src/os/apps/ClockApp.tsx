import { useEffect, useRef, useState } from "react";
import { Flag, Pause, Play, RotateCcw } from "lucide-react";
import type { AppProps } from "../types";
import { Segmented } from "../ui";
import { chime } from "../audio";
import { notify } from "../system";
import { useNow } from "../hooks";
import { cn } from "../../utils/cn";

type Tab = "world" | "stopwatch" | "timer";

const ZONES = [
  { city: "Warszawa", tz: "Europe/Warsaw" },
  { city: "Londyn", tz: "Europe/London" },
  { city: "Nowy Jork", tz: "America/New_York" },
  { city: "Los Angeles", tz: "America/Los_Angeles" },
  { city: "Dubaj", tz: "Asia/Dubai" },
  { city: "Tokio", tz: "Asia/Tokyo" },
  { city: "Sydney", tz: "Australia/Sydney" },
];

function AnalogClock({ size = 220 }: { size?: number }) {
  const now = useNow(40);
  const ms = now.getMilliseconds();
  const s = now.getSeconds() + ms / 1000;
  const m = now.getMinutes() + s / 60;
  const h = (now.getHours() % 12) + m / 60;
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" className="drop-shadow-[0_10px_30px_rgba(0,0,0,.35)]">
      <defs>
        <linearGradient id="clock-face" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--surface-3)" />
          <stop offset="1" stopColor="var(--surface-2)" />
        </linearGradient>
        <linearGradient id="clock-ring" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8b5cf6" />
          <stop offset="0.5" stopColor="#06b6d4" />
          <stop offset="1" stopColor="#f43f5e" />
        </linearGradient>
      </defs>
      <circle cx="100" cy="100" r="96" fill="url(#clock-face)" stroke="url(#clock-ring)" strokeWidth="3" />
      {Array.from({ length: 60 }, (_, i) => {
        const major = i % 5 === 0;
        const a = (i * 6 * Math.PI) / 180;
        const r1 = major ? 80 : 86;
        return (
          <line
            key={i}
            x1={100 + Math.sin(a) * r1}
            y1={100 - Math.cos(a) * r1}
            x2={100 + Math.sin(a) * 91}
            y2={100 - Math.cos(a) * 91}
            stroke="currentColor"
            strokeOpacity={major ? 0.85 : 0.3}
            strokeWidth={major ? 2.4 : 1}
            strokeLinecap="round"
          />
        );
      })}
      <g style={{ transformOrigin: "100px 100px", transform: `rotate(${h * 30}deg)` }}>
        <line x1="100" y1="106" x2="100" y2="58" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
      </g>
      <g style={{ transformOrigin: "100px 100px", transform: `rotate(${m * 6}deg)` }}>
        <line x1="100" y1="108" x2="100" y2="38" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
      </g>
      <g style={{ transformOrigin: "100px 100px", transform: `rotate(${s * 6}deg)` }}>
        <line x1="100" y1="118" x2="100" y2="24" stroke="#f43f5e" strokeWidth="1.6" strokeLinecap="round" />
        <circle cx="100" cy="100" r="4.5" fill="#f43f5e" />
      </g>
      <circle cx="100" cy="100" r="1.8" fill="var(--panel)" />
    </svg>
  );
}

function World() {
  const now = useNow(1000);
  const localDay = now.toDateString();
  return (
    <div className="flex h-full flex-col items-center gap-5 overflow-y-auto p-5">
      <AnalogClock />
      <div className="w-full max-w-md space-y-1.5">
        {ZONES.map((z) => {
          const t = new Intl.DateTimeFormat("pl-PL", { timeZone: z.tz, hour: "2-digit", minute: "2-digit" }).format(now);
          const there = new Date(now.toLocaleString("en-US", { timeZone: z.tz }));
          const diff = Math.round((new Date(there.toDateString()).getTime() - new Date(localDay).getTime()) / 86400000);
          return (
            <div key={z.tz} className="flex items-center justify-between rounded-2xl bg-surface-2 px-4 py-2.5">
              <div>
                <div className="text-sm font-medium">{z.city}</div>
                <div className="text-xs text-fg-dim">{diff === 0 ? "Dziś" : diff > 0 ? "Jutro" : "Wczoraj"}</div>
              </div>
              <div className="text-2xl font-extralight tabular-nums">{t}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

const fmtSW = (ms: number) => {
  const cs = Math.floor(ms / 10) % 100;
  const s = Math.floor(ms / 1000) % 60;
  const m = Math.floor(ms / 60000);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
};

function Stopwatch() {
  const [running, setRunning] = useState(false);
  const [ms, setMs] = useState(0);
  const [laps, setLaps] = useState<number[]>([]);
  const base = useRef(0);

  useEffect(() => {
    if (!running) return;
    const start = performance.now() - base.current;
    const t = setInterval(() => {
      base.current = performance.now() - start;
      setMs(base.current);
    }, 30);
    return () => clearInterval(t);
  }, [running]);

  return (
    <div className="flex h-full flex-col items-center gap-5 p-5">
      <div className="mt-6 text-[64px] font-extralight leading-none tabular-nums tracking-tight">{fmtSW(ms)}</div>
      <div className="flex gap-4">
        <button
          onClick={() => {
            if (running) setLaps((l) => [ms, ...l]);
            else {
              base.current = 0;
              setMs(0);
              setLaps([]);
            }
          }}
          disabled={!running && ms === 0}
          className="grid h-16 w-16 place-items-center rounded-full bg-surface-3 transition hover:brightness-125 active:scale-90 disabled:opacity-40"
          title={running ? "Runda" : "Zeruj"}
        >
          {running ? <Flag size={20} /> : <RotateCcw size={20} />}
        </button>
        <button
          onClick={() => setRunning((r) => !r)}
          className={cn("grid h-16 w-16 place-items-center rounded-full text-white shadow-lg transition hover:brightness-110 active:scale-90", running ? "bg-rose-500" : "bg-accent-grad")}
        >
          {running ? <Pause size={22} fill="currentColor" /> : <Play size={22} fill="currentColor" className="translate-x-0.5" />}
        </button>
      </div>
      <div className="w-full max-w-sm flex-1 space-y-1 overflow-y-auto">
        {laps.map((l, i) => (
          <div key={laps.length - i} className="flex justify-between rounded-xl bg-surface-2 px-4 py-2 text-sm tabular-nums">
            <span className="text-fg-dim">Runda {laps.length - i}</span>
            <span>{fmtSW(l)}</span>
            <span className="text-fg-faint">+{fmtSW(l - (laps[i + 1] ?? 0))}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Timer() {
  const [total, setTotal] = useState(5 * 60_000);
  const [left, setLeft] = useState(5 * 60_000);
  const [running, setRunning] = useState(false);
  const end = useRef(0);

  useEffect(() => {
    if (!running) return;
    end.current = Date.now() + left;
    const t = setInterval(() => {
      const r = end.current - Date.now();
      if (r <= 0) {
        clearInterval(t);
        setLeft(0);
        setRunning(false);
        chime();
        notify({ title: "Minutnik", body: "Czas minął!", appId: "clock" });
      } else setLeft(r);
    }, 100);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);

  const set = (ms: number) => {
    setRunning(false);
    setTotal(ms);
    setLeft(ms);
  };
  const secs = Math.ceil(left / 1000);
  const R = 88;
  const C = 2 * Math.PI * R;
  const pct = total ? left / total : 0;

  return (
    <div className="flex h-full flex-col items-center gap-5 p-5">
      <div className="relative mt-2 grid place-items-center">
        <svg width="220" height="220" viewBox="0 0 200 200" className="-rotate-90">
          <defs>
            <linearGradient id="timer-grad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="var(--accent)" />
              <stop offset="1" stopColor="#22d3ee" />
            </linearGradient>
          </defs>
          <circle cx="100" cy="100" r={R} fill="none" stroke="var(--surface-3)" strokeWidth="8" />
          <circle cx="100" cy="100" r={R} fill="none" stroke="url(#timer-grad)" strokeWidth="8" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - pct)} style={{ transition: running ? "stroke-dashoffset .1s linear" : "stroke-dashoffset .4s" }} />
        </svg>
        <div className="absolute text-center">
          <div className="text-5xl font-extralight tabular-nums">
            {String(Math.floor(secs / 60)).padStart(2, "0")}:{String(secs % 60).padStart(2, "0")}
          </div>
          <div className="text-xs text-fg-dim">{running ? "Odliczanie…" : left === 0 ? "Koniec!" : "Gotowy"}</div>
        </div>
      </div>
      <div className="flex flex-wrap justify-center gap-2">
        {[1, 3, 5, 10, 15, 25].map((m) => (
          <button
            key={m}
            onClick={() => set(m * 60_000)}
            className={cn("rounded-full px-3.5 py-1.5 text-xs font-medium transition", total === m * 60_000 ? "bg-accent text-white" : "bg-surface-2 hover:bg-surface-3")}
          >
            {m} min
          </button>
        ))}
      </div>
      <div className="flex gap-4">
        <button onClick={() => set(total)} className="grid h-14 w-14 place-items-center rounded-full bg-surface-3 transition hover:brightness-125 active:scale-90" title="Zeruj">
          <RotateCcw size={19} />
        </button>
        <button
          onClick={() => {
            if (left === 0) setLeft(total);
            setRunning((r) => !r);
          }}
          className={cn("grid h-14 w-14 place-items-center rounded-full text-white shadow-lg transition hover:brightness-110 active:scale-90", running ? "bg-rose-500" : "bg-accent-grad")}
        >
          {running ? <Pause size={21} fill="currentColor" /> : <Play size={21} fill="currentColor" className="translate-x-0.5" />}
        </button>
      </div>
    </div>
  );
}

export function ClockApp(_: AppProps) {
  void _;
  const [tab, setTab] = useState<Tab>("world");
  return (
    <div className="flex h-full w-full flex-col">
      <div className="flex justify-center px-5 pt-3">
        <Segmented<Tab>
          className="w-full max-w-sm"
          value={tab}
          onChange={setTab}
          options={[
            { value: "world", label: "Zegar" },
            { value: "stopwatch", label: "Stoper" },
            { value: "timer", label: "Minutnik" },
          ]}
        />
      </div>
      <div className="relative min-h-0 flex-1">
        <div className={cn("absolute inset-0", tab !== "world" && "hidden")}><World /></div>
        <div className={cn("absolute inset-0", tab !== "stopwatch" && "hidden")}><Stopwatch /></div>
        <div className={cn("absolute inset-0", tab !== "timer" && "hidden")}><Timer /></div>
      </div>
    </div>
  );
}
