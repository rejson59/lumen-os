import { useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ChevronRight,
  Download,
  FilePlus,
  FileText,
  FolderOpen,
  FolderPlus,
  House,
  Image as ImageIcon,
  LayoutGrid,
  List,
  Monitor,
  Music,
  Pencil,
  RotateCcw,
  Trash2,
  type LucideIcon,
} from "lucide-react";
import type { AppProps } from "../types";
import {
  ROOT,
  TRASH,
  childrenOf,
  createNode,
  deleteNode,
  emptyTrash,
  formatBytes,
  isProtected,
  pathNodes,
  renameNode,
  restoreNode,
  trashNode,
  useNodes,
  type FSNode,
} from "../fs";
import { askConfirm, askText, showMenu } from "../overlayStore";
import { NodeIcon } from "../NodeIcon";
import { openNode } from "../fileActions";
import { cn } from "../../utils/cn";

const PLACES: { id: string; label: string; icon: LucideIcon; color: string }[] = [
  { id: ROOT, label: "Katalog domowy", icon: House, color: "#f59e0b" },
  { id: "desktop", label: "Pulpit", icon: Monitor, color: "#8b5cf6" },
  { id: "docs", label: "Dokumenty", icon: FileText, color: "#3b82f6" },
  { id: "pics", label: "Obrazy", icon: ImageIcon, color: "#f43f5e" },
  { id: "music", label: "Muzyka", icon: Music, color: "#d946ef" },
  { id: "downloads", label: "Pobrane", icon: Download, color: "#10b981" },
  { id: TRASH, label: "Kosz", icon: Trash2, color: "#64748b" },
];

const fmtDate = (t: number) =>
  new Date(t).toLocaleDateString("pl-PL", { day: "numeric", month: "short", year: "numeric" });

const kindLabel = (n: FSNode) => (n.kind === "folder" ? "Folder" : n.kind === "image" ? "Obraz" : "Dokument");

export function FilesApp({ props }: AppProps) {
  const nodes = useNodes();
  const [hist, setHist] = useState<string[]>([props.folderId ?? ROOT]);
  const [idx, setIdx] = useState(0);
  const [view, setView] = useState<"grid" | "list">("grid");
  const [sel, setSel] = useState<string | null>(null);

  const cwd = nodes[hist[idx]] ? hist[idx] : ROOT;
  const inTrashDir = cwd === TRASH;
  const items = childrenOf(nodes, cwd);
  const crumbs = pathNodes(nodes, cwd);

  const go = (id: string) => {
    if (id === cwd) return;
    const h = [...hist.slice(0, idx + 1), id];
    setHist(h);
    setIdx(h.length - 1);
    setSel(null);
  };

  const open = (n: FSNode) => (n.kind === "folder" ? go(n.id) : openNode(n));

  const newFolder = async () => {
    const n = await askText("Nowy folder", "Nowy folder");
    if (n) createNode(cwd, n, "folder");
  };
  const newFile = async () => {
    const n = await askText("Nowy plik tekstowy", "Nowy plik.txt");
    if (n) createNode(cwd, /\.[a-z0-9]+$/i.test(n) ? n : n + ".txt", "text", "");
  };
  const rename = async (n: FSNode) => {
    const v = await askText("Zmień nazwę", n.name);
    if (v) renameNode(n.id, v);
  };
  const del = async (n: FSNode) => {
    if (await askConfirm("Usunąć na stałe?", `„${n.name}” zostanie bezpowrotnie usunięty.`, "Usuń", true)) deleteNode(n.id);
  };

  const itemMenu = (e: React.MouseEvent, n: FSNode) => {
    setSel(n.id);
    showMenu(
      e,
      inTrashDir
        ? [
            { label: "Przywróć", icon: RotateCcw, onClick: () => restoreNode(n.id) },
            { label: "Usuń na stałe", icon: Trash2, danger: true, onClick: () => del(n) },
          ]
        : [
            { label: "Otwórz", icon: FolderOpen, onClick: () => open(n) },
            { label: "Zmień nazwę", icon: Pencil, disabled: isProtected(n.id), onClick: () => rename(n) },
            { separator: true },
            { label: "Przenieś do kosza", icon: Trash2, danger: true, disabled: isProtected(n.id), onClick: () => trashNode(n.id) },
          ]
    );
  };

  const bgMenu = (e: React.MouseEvent) =>
    showMenu(
      e,
      inTrashDir
        ? [{ label: "Opróżnij kosz", icon: Trash2, danger: true, disabled: items.length === 0, onClick: emptyTrash }]
        : [
            { label: "Nowy folder", icon: FolderPlus, onClick: newFolder },
            { label: "Nowy plik tekstowy", icon: FilePlus, onClick: newFile },
          ]
    );

  const tool = "grid h-8 w-8 place-items-center rounded-lg text-fg-dim transition hover:bg-surface-3 hover:text-fg disabled:opacity-30 disabled:hover:bg-transparent";

  return (
    <div className="flex h-full w-full">
      <aside className="hidden w-48 shrink-0 flex-col gap-0.5 border-r border-glass-border bg-surface p-2.5 sm:flex">
        <div className="px-2.5 pb-1.5 pt-1 text-[11px] font-semibold uppercase tracking-wider text-fg-faint">Miejsca</div>
        {PLACES.map((p) => {
          const active = cwd === p.id;
          return (
            <button
              key={p.id}
              onClick={() => go(p.id)}
              className={cn(
                "flex items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-[13px] transition-colors",
                active ? "bg-surface-3 font-medium" : "hover:bg-surface-2"
              )}
            >
              <p.icon size={16} style={{ color: p.color }} />
              {p.label}
              {p.id === TRASH && childrenOf(nodes, TRASH).length > 0 && (
                <span className="ml-auto text-[11px] text-fg-faint">{childrenOf(nodes, TRASH).length}</span>
              )}
            </button>
          );
        })}
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-center gap-1 border-b border-glass-border px-3 py-2">
          <button className={tool} disabled={idx === 0} onClick={() => { setIdx(idx - 1); setSel(null); }} aria-label="Wstecz">
            <ArrowLeft size={16} />
          </button>
          <button className={tool} disabled={idx >= hist.length - 1} onClick={() => { setIdx(idx + 1); setSel(null); }} aria-label="Dalej">
            <ArrowRight size={16} />
          </button>
          <div className="mx-2 flex min-w-0 flex-1 items-center gap-0.5 overflow-hidden text-[13px]">
            {crumbs.map((c, i) => (
              <div key={c.id} className="flex items-center gap-0.5">
                {i > 0 && <ChevronRight size={13} className="text-fg-faint" />}
                <button
                  onClick={() => go(c.id)}
                  className={cn("truncate rounded-md px-1.5 py-0.5 transition hover:bg-surface-3", i === crumbs.length - 1 ? "font-semibold" : "text-fg-dim")}
                >
                  {c.id === ROOT ? "Katalog domowy" : c.name}
                </button>
              </div>
            ))}
          </div>
          {inTrashDir ? (
            <button
              onClick={emptyTrash}
              disabled={items.length === 0}
              className="mr-1 rounded-lg bg-rose-500/20 px-3 py-1.5 text-xs font-medium text-rose-400 transition hover:bg-rose-500/30 disabled:opacity-40"
            >
              Opróżnij kosz
            </button>
          ) : (
            <>
              <button className={tool} onClick={newFolder} aria-label="Nowy folder" title="Nowy folder">
                <FolderPlus size={16} />
              </button>
              <button className={tool} onClick={newFile} aria-label="Nowy plik" title="Nowy plik">
                <FilePlus size={16} />
              </button>
            </>
          )}
          <div className="ml-1 flex rounded-lg bg-surface-2 p-0.5">
            {([["grid", LayoutGrid], ["list", List]] as const).map(([v, Icon]) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={cn("grid h-7 w-7 place-items-center rounded-md transition", view === v ? "bg-surface-3 text-fg" : "text-fg-dim")}
              >
                <Icon size={14} />
              </button>
            ))}
          </div>
        </div>

        <div className="relative min-h-0 flex-1 overflow-y-auto" onContextMenu={bgMenu} onPointerDown={() => setSel(null)}>
          {items.length === 0 ? (
            <div className="grid h-full place-items-center text-center text-sm text-fg-faint">
              <div>
                <FolderOpen size={36} className="mx-auto mb-2 opacity-50" />
                {inTrashDir ? "Kosz jest pusty" : "Ten folder jest pusty"}
              </div>
            </div>
          ) : view === "grid" ? (
            <div className="grid grid-cols-[repeat(auto-fill,minmax(110px,1fr))] gap-1.5 p-4">
              {items.map((n) => (
                <button
                  key={n.id}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSel(n.id);
                  }}
                  onDoubleClick={() => open(n)}
                  onContextMenu={(e) => itemMenu(e, n)}
                  className={cn(
                    "flex flex-col items-center gap-2 rounded-xl px-2 py-3 transition-all duration-150",
                    sel === n.id ? "bg-accent/25 ring-1 ring-accent/60" : "hover:bg-surface-2"
                  )}
                >
                  <div className="grid h-[60px] place-items-center">
                    <NodeIcon node={n} size={56} />
                  </div>
                  <span className="line-clamp-2 w-full break-words text-center text-[12px] leading-tight">{n.name}</span>
                </button>
              ))}
            </div>
          ) : (
            <div className="p-2">
              <div className="grid grid-cols-[1fr_90px_120px] gap-3 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-fg-faint">
                <span>Nazwa</span>
                <span>Rodzaj</span>
                <span>Zmodyfikowano</span>
              </div>
              {items.map((n) => (
                <button
                  key={n.id}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSel(n.id);
                  }}
                  onDoubleClick={() => open(n)}
                  onContextMenu={(e) => itemMenu(e, n)}
                  className={cn(
                    "grid w-full grid-cols-[1fr_90px_120px] items-center gap-3 rounded-lg px-3 py-1.5 text-left text-[13px] transition-colors",
                    sel === n.id ? "bg-accent/25" : "hover:bg-surface-2"
                  )}
                >
                  <span className="flex min-w-0 items-center gap-2.5">
                    <span className="grid w-7 shrink-0 place-items-center">
                      <NodeIcon node={n} size={22} />
                    </span>
                    <span className="truncate">{n.name}</span>
                  </span>
                  <span className="text-fg-dim">{kindLabel(n)}</span>
                  <span className="text-fg-dim">{fmtDate(n.modified)}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between border-t border-glass-border px-4 py-1.5 text-[11px] text-fg-dim">
          <span>
            {items.length} {items.length === 1 ? "element" : "elementów"}
            {sel && nodes[sel] && nodes[sel].parent === cwd ? ` · zaznaczono „${nodes[sel].name}”` : ""}
          </span>
          <span>{formatBytes(items.reduce((a, n) => a + (n.content?.length ?? 0), 0))}</span>
        </div>
      </div>
    </div>
  );
}
