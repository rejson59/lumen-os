import { useEffect, useMemo, useState } from "react";
import { Plus, Search, StickyNote, Trash2 } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import type { AppProps } from "../types";
import { createNode, extOf, inTrash, renameNode, trashNode, useNodes, writeNode } from "../fs";
import { setWinTitle } from "../system";
import { cn } from "../../utils/cn";

const DOTS = ["#f59e0b", "#ec4899", "#8b5cf6", "#06b6d4", "#10b981", "#f43f5e", "#3b82f6"];
const dotFor = (id: string) => DOTS[[...id].reduce((a, c) => a + c.charCodeAt(0), 0) % DOTS.length];
const stripExt = (n: string) => (extOf(n) ? n.slice(0, -extOf(n).length) : n);

export function NotesApp({ winId, props }: AppProps) {
  const nodes = useNodes();
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<string | null>(props.fileId ?? null);
  const [title, setTitle] = useState("");

  useEffect(() => {
    if (props.fileId) setSel(props.fileId);
  }, [props.fileId]);

  const notes = useMemo(
    () =>
      Object.values(nodes)
        .filter((n) => n.kind === "text" && !inTrash(nodes, n))
        .sort((a, b) => b.modified - a.modified),
    [nodes]
  );
  const filtered = notes.filter((n) => (n.name + (n.content ?? "")).toLowerCase().includes(q.toLowerCase()));
  const cur = sel && nodes[sel] && nodes[sel].kind === "text" && !inTrash(nodes, nodes[sel]) ? nodes[sel] : null;

  useEffect(() => {
    setTitle(cur ? stripExt(cur.name) : "");
    setWinTitle(winId, cur ? `Notatki — ${cur.name}` : "Notatki");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cur?.id, cur?.name]);

  const commitTitle = () => {
    if (!cur) return;
    const t = title.trim();
    if (t && t !== stripExt(cur.name)) renameNode(cur.id, t + (extOf(cur.name) || ".txt"));
    else setTitle(stripExt(cur.name));
  };

  const words = cur?.content?.trim() ? cur.content.trim().split(/\s+/).length : 0;

  return (
    <div className="flex h-full w-full">
      <aside className="flex w-[250px] shrink-0 flex-col border-r border-glass-border bg-surface">
        <div className="flex items-center gap-2 p-3">
          <div className="flex flex-1 items-center gap-2 rounded-lg bg-surface-2 px-2.5 py-1.5">
            <Search size={13} className="text-fg-faint" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Szukaj"
              className="w-full bg-transparent text-[13px] outline-none placeholder:text-fg-faint"
            />
          </div>
          <button
            onClick={() => setSel(createNode("docs", "Nowa notatka.txt", "text", ""))}
            className="grid h-8 w-8 place-items-center rounded-lg bg-accent-grad text-white shadow transition hover:brightness-110 active:scale-90"
            title="Nowa notatka"
          >
            <Plus size={16} />
          </button>
        </div>
        <div className="flex-1 space-y-1 overflow-y-auto px-2 pb-2">
          <AnimatePresence initial={false}>
            {filtered.map((n) => (
              <motion.button
                layout
                key={n.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onClick={() => setSel(n.id)}
                className={cn(
                  "w-full rounded-xl px-3 py-2.5 text-left transition-colors",
                  cur?.id === n.id ? "bg-accent/25 ring-1 ring-accent/50" : "hover:bg-surface-2"
                )}
              >
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: dotFor(n.id) }} />
                  <span className="truncate text-[13px] font-semibold">{stripExt(n.name) || "Bez tytułu"}</span>
                </div>
                <div className="mt-0.5 line-clamp-2 pl-4 text-xs leading-snug text-fg-dim">
                  {n.content?.trim().slice(0, 90) || "Pusta notatka"}
                </div>
              </motion.button>
            ))}
          </AnimatePresence>
          {filtered.length === 0 && <div className="py-8 text-center text-xs text-fg-faint">Brak notatek</div>}
        </div>
      </aside>

      <section className="flex min-w-0 flex-1 flex-col">
        {cur ? (
          <>
            <div className="flex items-center gap-2 px-6 pt-5">
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                onBlur={commitTitle}
                onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
                placeholder="Tytuł"
                className="min-w-0 flex-1 bg-transparent text-2xl font-semibold tracking-tight outline-none placeholder:text-fg-faint"
              />
              <button
                onClick={() => {
                  trashNode(cur.id);
                  setSel(null);
                }}
                className="grid h-8 w-8 place-items-center rounded-lg text-fg-dim transition hover:bg-rose-500/20 hover:text-rose-400"
                title="Przenieś do kosza"
              >
                <Trash2 size={16} />
              </button>
            </div>
            <textarea
              key={cur.id}
              value={cur.content ?? ""}
              onChange={(e) => writeNode(cur.id, e.target.value)}
              placeholder="Zacznij pisać…"
              spellCheck={false}
              className="selectable mt-2 min-h-0 flex-1 resize-none bg-transparent px-6 pb-4 text-[15px] leading-relaxed outline-none placeholder:text-fg-faint"
            />
            <div className="flex justify-between border-t border-glass-border px-6 py-1.5 text-[11px] text-fg-faint">
              <span>
                {words} słów · {cur.content?.length ?? 0} znaków
              </span>
              <span>Zapisano automatycznie · {new Date(cur.modified).toLocaleTimeString("pl-PL", { hour: "2-digit", minute: "2-digit" })}</span>
            </div>
          </>
        ) : (
          <div className="grid flex-1 place-items-center text-center text-fg-faint">
            <div>
              <StickyNote size={44} className="mx-auto mb-3 opacity-50" />
              <div className="text-sm">Wybierz notatkę lub utwórz nową</div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
