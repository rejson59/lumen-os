import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight, ExternalLink, Globe, House, Info, Lock, MapPin, RotateCw, Search, Sparkles, X, BookOpen, Image as ImageIcon } from "lucide-react";
import type { AppProps } from "../types";
import { settings } from "../settings";
import { LumenLogo } from "../ui";
import { cn } from "../../utils/cn";

const START = "lumen://start";

const normalize = (v: string): string => {
  const t = v.trim();
  if (!t) return START;
  if (t.startsWith("lumen://")) return t;
  if (/^https?:\/\//i.test(t)) return t;
  if (/^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(t)) return "https://" + t;
  return `https://pl.wikipedia.org/w/index.php?search=${encodeURIComponent(t)}`;
};

const TILES = [
  { name: "Wikipedia", url: "https://pl.wikipedia.org", icon: BookOpen, from: "#94a3b8", to: "#334155" },
  { name: "Mapa Polski", url: "https://www.openstreetmap.org/export/embed.html?bbox=14.0,49.0,24.2,54.9&layer=mapnik", icon: MapPin, from: "#34d399", to: "#0d9488" },
  { name: "Wikimedia", url: "https://commons.wikimedia.org", icon: ImageIcon, from: "#60a5fa", to: "#4f46e5" },
  { name: "Example", url: "https://example.com", icon: Globe, from: "#fbbf24", to: "#ea580c" },
  { name: "O Lumen OS", url: "lumen://about", icon: Sparkles, from: "#c084fc", to: "#db2777" },
];

function StartPage({ onGo }: { onGo: (v: string) => void }) {
  const [q, setQ] = useState("");
  const name = settings.use((s) => s.userName);
  return (
    <div className="relative flex h-full flex-col items-center justify-center overflow-y-auto px-6 py-10">
      <div className="pointer-events-none absolute -left-20 top-0 h-72 w-72 rounded-full bg-violet-500/30 blur-[90px]" />
      <div className="pointer-events-none absolute -right-10 bottom-0 h-72 w-72 rounded-full bg-cyan-400/25 blur-[90px]" />
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative flex flex-col items-center">
        <LumenLogo size={64} spin />
        <h1 className="mt-5 text-4xl font-extralight tracking-tight">Cześć, <span className="text-accent-grad font-medium">{name}</span></h1>
        <p className="mt-1 text-sm text-fg-dim">Wpisz adres lub hasło do wyszukania w Wikipedii</p>
        <form
          className="mt-7 flex w-[min(520px,86vw)] items-center gap-3 rounded-full border border-glass-border bg-surface-2 px-5 py-3 shadow-lg backdrop-blur transition focus-within:ring-2 focus-within:ring-accent"
          onSubmit={(e) => {
            e.preventDefault();
            onGo(q);
          }}
        >
          <Search size={18} className="text-fg-dim" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Szukaj lub wpisz adres" className="w-full bg-transparent outline-none placeholder:text-fg-faint" autoFocus />
        </form>
        <div className="mt-10 flex flex-wrap justify-center gap-6">
          {TILES.map((t, i) => (
            <motion.button
              key={t.name}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 + i * 0.06 }}
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.93 }}
              onClick={() => onGo(t.url)}
              className="flex w-20 flex-col items-center gap-2"
            >
              <span
                className="grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg"
                style={{ background: `linear-gradient(150deg, ${t.from}, ${t.to})` }}
              >
                <t.icon size={24} />
              </span>
              <span className="text-xs text-fg-dim">{t.name}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

function AboutPage() {
  return (
    <div className="h-full overflow-y-auto p-10">
      <div className="mx-auto max-w-xl">
        <LumenLogo size={56} spin />
        <h1 className="mt-4 text-3xl font-light">Lumen OS</h1>
        <p className="mt-3 leading-relaxed text-fg-dim">
          Lumen to minimalistyczny, kolorowy system operacyjny działający w całości w przeglądarce. Wszystkie aplikacje, system plików
          i efekty zostały napisane od zera w React i Tailwind CSS. Twoje pliki, notatki i ustawienia zapisują się lokalnie w tej przeglądarce.
        </p>
        <div className="mt-6 grid grid-cols-2 gap-3">
          {["Płynne animacje", "Szklany interfejs", "Wirtualny system plików", "14 aplikacji"].map((t) => (
            <div key={t} className="rounded-2xl bg-surface-2 p-4 text-sm font-medium">{t}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function BrowserApp({ props }: AppProps) {
  const initial = props.url ? normalize(String(props.url)) : START;
  const [hist, setHist] = useState<string[]>([initial]);
  const [idx, setIdx] = useState(0);
  const [input, setInput] = useState(initial === START ? "" : initial);
  const [loading, setLoading] = useState(initial.startsWith("http"));
  const [reload, setReload] = useState(0);
  const [hint, setHint] = useState(true);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const url = hist[idx];
  const internal = url.startsWith("lumen://");

  useEffect(() => {
    setInput(internal && url === START ? "" : url);
    if (!internal) {
      setLoading(true);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setLoading(false), 8000);
    } else setLoading(false);
    return () => clearTimeout(timer.current);
  }, [url, internal, reload]);

  const go = (v: string) => {
    const u = normalize(v);
    if (u === url) return setReload((r) => r + 1);
    const h = [...hist.slice(0, idx + 1), u];
    setHist(h);
    setIdx(h.length - 1);
  };

  const btn = "grid h-8 w-8 place-items-center rounded-lg text-fg-dim transition hover:bg-surface-3 hover:text-fg disabled:opacity-30 disabled:hover:bg-transparent";

  return (
    <div className="flex h-full w-full flex-col">
      <div className="relative flex items-center gap-1 border-b border-glass-border px-2.5 py-2">
        <button className={btn} disabled={idx === 0} onClick={() => setIdx(idx - 1)} aria-label="Wstecz"><ArrowLeft size={16} /></button>
        <button className={btn} disabled={idx >= hist.length - 1} onClick={() => setIdx(idx + 1)} aria-label="Dalej"><ArrowRight size={16} /></button>
        <button className={btn} onClick={() => setReload((r) => r + 1)} aria-label="Odśwież"><RotateCw size={15} className={cn(loading && "animate-spin")} /></button>
        <button className={btn} onClick={() => go(START)} aria-label="Strona główna"><House size={16} /></button>
        <form
          className="mx-1 flex min-w-0 flex-1 items-center gap-2 rounded-full bg-surface-2 px-3.5 py-1.5 transition focus-within:ring-2 focus-within:ring-accent"
          onSubmit={(e) => {
            e.preventDefault();
            go(input);
          }}
        >
          {internal ? <Sparkles size={13} className="text-accent" /> : <Lock size={13} className="text-emerald-400" />}
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onFocus={(e) => e.target.select()}
            placeholder="Szukaj lub wpisz adres"
            className="w-full min-w-0 bg-transparent text-[13px] outline-none placeholder:text-fg-faint"
          />
        </form>
        <button
          className={btn}
          disabled={internal}
          onClick={() => window.open(url, "_blank", "noopener,noreferrer")}
          title="Otwórz w nowej karcie"
          aria-label="Otwórz w nowej karcie"
        >
          <ExternalLink size={15} />
        </button>
        {loading && (
          <motion.div
            className="absolute inset-x-0 bottom-[-1px] h-0.5 origin-left bg-accent-grad"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 0.9 }}
            transition={{ duration: 6, ease: "easeOut" }}
          />
        )}
      </div>

      {!internal && hint && (
        <div className="flex items-center gap-2 border-b border-glass-border bg-accent/15 px-4 py-1.5 text-xs">
          <Info size={13} className="shrink-0 text-accent" />
          <span className="flex-1 text-fg-dim">Niektóre strony blokują wyświetlanie w ramkach. Jeśli strona jest pusta — otwórz ją w nowej karcie.</span>
          <button onClick={() => window.open(url, "_blank", "noopener,noreferrer")} className="rounded-md bg-accent px-2 py-0.5 font-medium text-white">Otwórz</button>
          <button onClick={() => setHint(false)} className="rounded-md p-0.5 text-fg-dim hover:bg-surface-3"><X size={13} /></button>
        </div>
      )}

      <div className="relative min-h-0 flex-1">
        {url === START ? (
          <StartPage onGo={go} />
        ) : url === "lumen://about" ? (
          <AboutPage />
        ) : (
          <iframe
            key={url + reload}
            src={url}
            title="Przeglądarka"
            className="h-full w-full bg-white"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
            referrerPolicy="no-referrer"
            onLoad={() => setLoading(false)}
          />
        )}
      </div>
    </div>
  );
}
