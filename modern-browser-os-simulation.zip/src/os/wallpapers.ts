export interface Blob {
  c: string; // kolor
  s: number; // rozmiar (% szerokości)
  x: number; // środek X (%)
  y: number; // środek Y (%)
  a: "a" | "b" | "c";
  d: number; // czas animacji (s)
}

export interface WallpaperDef {
  id: string;
  name: string;
  base: string;
  blobs: Blob[];
}

export const WALLPAPERS: WallpaperDef[] = [
  {
    id: "aurora",
    name: "Zorza",
    base: "#0b0820",
    blobs: [
      { c: "#7c3aed", s: 55, x: 15, y: 20, a: "a", d: 26 },
      { c: "#06b6d4", s: 50, x: 80, y: 70, a: "b", d: 32 },
      { c: "#ec4899", s: 38, x: 70, y: 10, a: "c", d: 28 },
      { c: "#2563eb", s: 40, x: 25, y: 85, a: "a", d: 36 },
    ],
  },
  {
    id: "sunset",
    name: "Zachód",
    base: "#1a0b2e",
    blobs: [
      { c: "#ff7a18", s: 52, x: 20, y: 85, a: "a", d: 28 },
      { c: "#ff3d81", s: 50, x: 75, y: 65, a: "b", d: 30 },
      { c: "#7b2ff7", s: 55, x: 60, y: 5, a: "c", d: 34 },
      { c: "#ffd166", s: 28, x: 90, y: 90, a: "a", d: 24 },
    ],
  },
  {
    id: "lagoon",
    name: "Laguna",
    base: "#031d2a",
    blobs: [
      { c: "#00d2ff", s: 50, x: 12, y: 25, a: "b", d: 30 },
      { c: "#3a7bd5", s: 55, x: 80, y: 30, a: "a", d: 34 },
      { c: "#00f5a0", s: 42, x: 55, y: 90, a: "c", d: 27 },
      { c: "#7f00ff", s: 32, x: 92, y: 85, a: "b", d: 38 },
    ],
  },
  {
    id: "neon",
    name: "Neon",
    base: "#07020f",
    blobs: [
      { c: "#ff00c8", s: 46, x: 18, y: 30, a: "a", d: 24 },
      { c: "#00fff0", s: 42, x: 82, y: 70, a: "b", d: 29 },
      { c: "#7000ff", s: 50, x: 55, y: 15, a: "c", d: 33 },
      { c: "#ff6a00", s: 26, x: 30, y: 95, a: "a", d: 26 },
    ],
  },
  {
    id: "mint",
    name: "Mięta",
    base: "#06251d",
    blobs: [
      { c: "#34d399", s: 52, x: 15, y: 70, a: "a", d: 31 },
      { c: "#a3e635", s: 38, x: 75, y: 20, a: "b", d: 28 },
      { c: "#0ea5e9", s: 46, x: 85, y: 85, a: "c", d: 35 },
      { c: "#14b8a6", s: 40, x: 40, y: 10, a: "a", d: 25 },
    ],
  },
  {
    id: "candy",
    name: "Wata",
    base: "#ffe8f4",
    blobs: [
      { c: "#ff9ac1", s: 52, x: 15, y: 25, a: "a", d: 28 },
      { c: "#a78bfa", s: 50, x: 82, y: 25, a: "b", d: 32 },
      { c: "#7dd3fc", s: 48, x: 70, y: 90, a: "c", d: 30 },
      { c: "#fde68a", s: 40, x: 20, y: 90, a: "a", d: 36 },
    ],
  },
  {
    id: "midnight",
    name: "Północ",
    base: "#04050d",
    blobs: [
      { c: "#1e3a8a", s: 55, x: 20, y: 30, a: "a", d: 36 },
      { c: "#6d28d9", s: 42, x: 80, y: 60, a: "b", d: 40 },
      { c: "#0f766e", s: 38, x: 50, y: 100, a: "c", d: 34 },
    ],
  },
];

export const getWallpaper = (id: string) => WALLPAPERS.find((w) => w.id === id) ?? WALLPAPERS[0];
