/** Generatywny silnik muzyczny oparty na Web Audio API. Nic tu nie jest nagraniem. */

export interface Track {
  id: string;
  title: string;
  artist: string;
  bpm: number;
  chords: number[][];
  arp: number[]; // indeksy w [akord, akord + oktawa]
  arpWave: OscillatorType;
  padWave: OscillatorType;
  colors: [string, string, string];
  duration: number; // sekundy
}

export const TRACKS: Track[] = [
  {
    id: "aurora",
    title: "Aurora",
    artist: "Lumen Ensemble",
    bpm: 72,
    chords: [
      [60, 64, 67, 71],
      [57, 60, 64, 67],
      [53, 57, 60, 64],
      [55, 59, 62, 67],
    ],
    arp: [0, 2, 4, 6, 7, 5, 3, 1],
    arpWave: "triangle",
    padWave: "sine",
    colors: ["#8b5cf6", "#06b6d4", "#ec4899"],
    duration: 160,
  },
  {
    id: "dusk",
    title: "Neon Dusk",
    artist: "Synth Garden",
    bpm: 96,
    chords: [
      [57, 60, 64, 67],
      [53, 57, 60, 64],
      [60, 64, 67, 71],
      [52, 55, 59, 62],
    ],
    arp: [0, 3, 1, 4, 2, 5, 3, 6],
    arpWave: "sawtooth",
    padWave: "triangle",
    colors: ["#ff00c8", "#7000ff", "#00fff0"],
    duration: 140,
  },
  {
    id: "blue",
    title: "Deep Blue",
    artist: "Ocean Drift",
    bpm: 58,
    chords: [
      [62, 65, 69, 72],
      [58, 62, 65, 69],
      [53, 57, 60, 64],
      [60, 64, 67, 69],
    ],
    arp: [0, 1, 2, 3, 4, 3, 2, 1],
    arpWave: "sine",
    padWave: "sine",
    colors: ["#2563eb", "#22d3ee", "#34d399"],
    duration: 180,
  },
  {
    id: "sunrise",
    title: "Złoty poranek",
    artist: "Morning Light",
    bpm: 104,
    chords: [
      [55, 59, 62, 66],
      [57, 62, 66, 69],
      [52, 55, 59, 62],
      [60, 64, 67, 71],
    ],
    arp: [0, 2, 3, 2, 4, 2, 3, 1],
    arpWave: "triangle",
    padWave: "triangle",
    colors: ["#f59e0b", "#f43f5e", "#fde047"],
    duration: 130,
  },
];

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let analyser: AnalyserNode | null = null;
let bus: GainNode | null = null;
let timer: ReturnType<typeof setInterval> | undefined;
let playing = false;
let volume = 0.6;

const mtof = (n: number) => 440 * Math.pow(2, (n - 69) / 12);

export function getAudio() {
  if (!ctx) {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = volume * 0.7;
    analyser = ctx.createAnalyser();
    analyser.fftSize = 128;
    analyser.smoothingTimeConstant = 0.82;
    master.connect(analyser);
    analyser.connect(ctx.destination);
  }
  return { ctx, master: master!, analyser: analyser! };
}

export function setVolume(v: number) {
  volume = v / 100;
  if (ctx && master) master.gain.setTargetAtTime(volume * 0.7, ctx.currentTime, 0.05);
}

export const isPlaying = () => playing;
export const getAnalyser = () => analyser;

function voice(
  c: AudioContext,
  out: AudioNode,
  freq: number,
  t: number,
  dur: number,
  type: OscillatorType,
  vol: number,
  attack: number,
  release: number,
  cutoff: number,
  detune = 0
) {
  const osc = c.createOscillator();
  const g = c.createGain();
  const f = c.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = cutoff;
  osc.type = type;
  osc.frequency.value = freq;
  osc.detune.value = detune;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(vol, t + attack);
  g.gain.linearRampToValueAtTime(0.0001, t + dur + release);
  osc.connect(f);
  f.connect(g);
  g.connect(out);
  osc.start(t);
  osc.stop(t + dur + release + 0.05);
}

function scheduleBar(c: AudioContext, out: AudioNode, tr: Track, bar: number, t: number) {
  const beat = 60 / tr.bpm;
  const barDur = beat * 4;
  const chord = tr.chords[bar % tr.chords.length];
  chord.forEach((n) => {
    voice(c, out, mtof(n), t, barDur, tr.padWave, 0.045, 0.7, 1.0, 1400, -8);
    voice(c, out, mtof(n), t, barDur, tr.padWave, 0.045, 0.7, 1.0, 1400, 8);
  });
  voice(c, out, mtof(Math.min(...chord) - 24), t, barDur * 0.95, "sine", 0.24, 0.04, 0.5, 400);
  const pool = [...chord, ...chord.map((n) => n + 12)];
  tr.arp.forEach((idx, i) => {
    const note = pool[idx % pool.length];
    voice(c, out, mtof(note + 12), t + (i * beat) / 2, 0.22, tr.arpWave, tr.arpWave === "sawtooth" ? 0.05 : 0.085, 0.012, 0.5, tr.arpWave === "sawtooth" ? 1800 : 3500);
  });
}

export function stop() {
  clearInterval(timer);
  timer = undefined;
  playing = false;
  if (ctx && bus) {
    const b = bus;
    b.gain.setTargetAtTime(0, ctx.currentTime, 0.06);
    setTimeout(() => b.disconnect(), 600);
    bus = null;
  }
}

export function play(tr: Track) {
  stop();
  const { ctx: c, master: m } = getAudio();
  if (c.state === "suspended") void c.resume();
  bus = c.createGain();
  bus.gain.value = 1;
  bus.connect(m);
  const out = bus;
  let bar = 0;
  let next = c.currentTime + 0.1;
  const barDur = (60 / tr.bpm) * 4;
  const tick = () => {
    while (next < c.currentTime + 0.7) {
      scheduleBar(c, out, tr, bar++, next);
      next += barDur;
    }
  };
  tick();
  timer = setInterval(tick, 150);
  playing = true;
}

/** Krótki dzwonek (np. minutnik). */
export function chime() {
  const { ctx: c, master: m } = getAudio();
  if (c.state === "suspended") void c.resume();
  [76, 81, 84, 88].forEach((n, i) => voice(c, m, mtof(n), c.currentTime + i * 0.18, 0.3, "sine", 0.18, 0.01, 0.9, 5000));
}
