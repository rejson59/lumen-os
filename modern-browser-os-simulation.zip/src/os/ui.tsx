import { useRef, useState, type CSSProperties, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "../utils/cn";
import { APP_META, type AppId } from "./appMeta";
import type { CtxItem } from "./overlayStore";
import { useClickOutside } from "./hooks";

export function AppIcon({ id, size, className }: { id: AppId; size?: number; className?: string }) {
  const m = APP_META[id];
  const Icon = m.icon;
  return (
    <div
      className={cn("relative grid shrink-0 place-items-center overflow-hidden", className)}
      style={{
        width: size ?? "100%",
        height: size ?? "100%",
        borderRadius: "26%",
        background: `linear-gradient(150deg, ${m.from}, ${m.to})`,
        boxShadow:
          "inset 0 1px 0 rgba(255,255,255,.5), inset 0 -3px 8px rgba(0,0,0,.18), 0 6px 18px rgba(0,0,0,.28)",
      }}
    >
      <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/30 to-transparent" />
      <Icon className="relative h-[52%] w-[52%] text-white drop-shadow-md" strokeWidth={2} />
    </div>
  );
}

export function LumenLogo({ size = 24, spin = false, className }: { size?: number; spin?: boolean; className?: string }) {
  const mask = "radial-gradient(circle, transparent 36%, #000 39%)";
  return (
    <div className={cn("relative shrink-0", className)} style={{ width: size, height: size }}>
      <div
        className={cn("absolute inset-0 rounded-full", spin && "spin-medium")}
        style={{
          background: "conic-gradient(from 0deg, #8b5cf6, #06b6d4, #34d399, #fbbf24, #f43f5e, #8b5cf6)",
          WebkitMask: mask,
          mask,
        }}
      />
    </div>
  );
}

export function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300", checked ? "bg-accent" : "bg-surface-3")}
    >
      <span
        className={cn(
          "absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow-md transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)]",
          checked && "translate-x-5"
        )}
      />
    </button>
  );
}

export function Slider({
  value,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  className,
}: {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
  className?: string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className={cn("slider w-full cursor-pointer", className)}
      style={{ "--val": `${pct}%` } as CSSProperties}
    />
  );
}

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  className,
}: {
  value: T;
  options: { value: T; label: ReactNode }[];
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn("relative flex rounded-xl bg-surface-2 p-1", className)}>
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "relative z-10 flex-1 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
            value === o.value ? "text-white" : "text-fg-dim hover:text-fg"
          )}
        >
          {value === o.value && (
            <motion.span layoutId={`seg-${options.map((x) => x.value).join("")}`} className="absolute inset-0 -z-10 rounded-lg bg-accent-grad shadow" transition={{ type: "spring", stiffness: 420, damping: 34 }} />
          )}
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function MenuList({ items, onDone }: { items: CtxItem[]; onDone: () => void }) {
  return (
    <div className="glass-strong min-w-[200px] rounded-xl p-1.5 text-[13px] shadow-[0_20px_50px_-10px_rgba(0,0,0,.5)]">
      {items.map((it, i) => {
        if (it.separator) return <div key={i} className="my-1 h-px bg-glass-border" />;
        const Icon = it.icon;
        return (
          <button
            key={i}
            disabled={it.disabled}
            onClick={() => {
              it.onClick?.();
              onDone();
            }}
            className={cn(
              "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-left transition-colors",
              it.danger ? "text-rose-400 hover:bg-rose-500/20" : "hover:bg-accent hover:text-white",
              it.disabled && "pointer-events-none opacity-40"
            )}
          >
            {Icon && <Icon size={15} />}
            <span className="flex-1">{it.label}</span>
            {it.hint && <span className="text-xs opacity-50">{it.hint}</span>}
          </button>
        );
      })}
    </div>
  );
}

export function Dropdown({
  trigger,
  items,
  align = "left",
  className,
}: {
  trigger: (open: boolean) => ReactNode;
  items: CtxItem[];
  align?: "left" | "right";
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useClickOutside(ref, () => setOpen(false), open);
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((o) => !o)} className={className}>
        {trigger(open)}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.98 }}
            transition={{ duration: 0.14 }}
            className={cn("absolute top-full z-50 mt-1.5", align === "right" ? "right-0" : "left-0")}
          >
            <MenuList items={items} onDone={() => setOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function SectionTitle({ children }: { children: ReactNode }) {
  return <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-fg-faint">{children}</div>;
}
