import type { ComponentType } from "react";
import type { AppId } from "./appMeta";
import type { AppProps } from "./types";
import { FilesApp } from "./apps/FilesApp";
import { BrowserApp } from "./apps/BrowserApp";
import { NotesApp } from "./apps/NotesApp";
import { MusicApp } from "./apps/MusicApp";
import { PhotosApp } from "./apps/PhotosApp";
import { PaintApp } from "./apps/PaintApp";
import { CalendarApp } from "./apps/CalendarApp";
import { WeatherApp } from "./apps/WeatherApp";
import { TerminalApp } from "./apps/TerminalApp";
import { SettingsApp } from "./apps/SettingsApp";
import { CalculatorApp } from "./apps/CalculatorApp";
import { ClockApp } from "./apps/ClockApp";
import { SnakeApp } from "./apps/SnakeApp";
import { MonitorApp } from "./apps/MonitorApp";

export const APPS: Record<AppId, ComponentType<AppProps>> = {
  files: FilesApp,
  browser: BrowserApp,
  notes: NotesApp,
  music: MusicApp,
  photos: PhotosApp,
  paint: PaintApp,
  calendar: CalendarApp,
  weather: WeatherApp,
  terminal: TerminalApp,
  settings: SettingsApp,
  calculator: CalculatorApp,
  clock: ClockApp,
  snake: SnakeApp,
  monitor: MonitorApp,
};
