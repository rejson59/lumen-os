import { useSyncExternalStore } from "react";

type Patch<T> = Partial<T> | ((s: T) => Partial<T>);

/** Minimalny magazyn stanu z opcjonalnym (opóźnionym) zapisem do localStorage. */
export function createStore<T extends object>(initial: T, persistKey?: string) {
  let state: T = initial;
  if (persistKey) {
    try {
      const raw = localStorage.getItem(persistKey);
      if (raw) state = { ...initial, ...JSON.parse(raw) };
    } catch {
      /* ignore */
    }
  }
  const listeners = new Set<() => void>();
  let timer: ReturnType<typeof setTimeout> | undefined;

  const flush = () => {
    if (!persistKey) return;
    try {
      localStorage.setItem(persistKey, JSON.stringify(state));
    } catch {
      /* ignore */
    }
  };
  if (persistKey && typeof window !== "undefined") {
    window.addEventListener("beforeunload", flush);
  }

  const subscribe = (l: () => void) => {
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  };
  const get = () => state;
  const set = (patch: Patch<T>) => {
    const p = typeof patch === "function" ? patch(state) : patch;
    state = { ...state, ...p };
    if (persistKey) {
      clearTimeout(timer);
      timer = setTimeout(flush, 250);
    }
    listeners.forEach((l) => l());
  };
  function use<S>(selector: (s: T) => S): S {
    return useSyncExternalStore(subscribe, () => selector(state));
  }
  return { get, set, use, subscribe };
}
