import { useEffect, useState, type RefObject } from "react";

export function useNow(ms = 1000) {
  const [n, setN] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setN(new Date()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return n;
}

export function useViewport() {
  const [v, setV] = useState({ w: window.innerWidth, h: window.innerHeight });
  useEffect(() => {
    const f = () => setV({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []);
  return v;
}

interface BatteryManagerLike extends EventTarget {
  level: number;
  charging: boolean;
}

export function useBattery() {
  const [b, setB] = useState({ level: 0.87, charging: true });
  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<BatteryManagerLike> };
    if (!nav.getBattery) return;
    let bat: BatteryManagerLike | undefined;
    let dead = false;
    const upd = () => bat && !dead && setB({ level: bat.level, charging: bat.charging });
    nav
      .getBattery()
      .then((x) => {
        bat = x;
        upd();
        x.addEventListener("levelchange", upd);
        x.addEventListener("chargingchange", upd);
      })
      .catch(() => {});
    return () => {
      dead = true;
      bat?.removeEventListener("levelchange", upd);
      bat?.removeEventListener("chargingchange", upd);
    };
  }, []);
  return b;
}

export function useClickOutside(ref: RefObject<HTMLElement | null>, handler: () => void, enabled = true) {
  useEffect(() => {
    if (!enabled) return;
    const f = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) handler();
    };
    window.addEventListener("pointerdown", f);
    return () => window.removeEventListener("pointerdown", f);
  }, [ref, handler, enabled]);
}

export const fmtTime = (d: Date, seconds = false) =>
  d.toLocaleTimeString("pl-PL", { hour: "2-digit", minute: "2-digit", ...(seconds ? { second: "2-digit" } : {}) });

export const fmtDateLong = (d: Date) =>
  d.toLocaleDateString("pl-PL", { weekday: "long", day: "numeric", month: "long" });

export const fmtDateShort = (d: Date) =>
  d.toLocaleDateString("pl-PL", { weekday: "short", day: "numeric", month: "short" });
